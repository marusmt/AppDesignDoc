# IIS バージョンアップ非互換情報（Windows Server 2019 → 2022 / 2025）

<aside>
📌

**対象:** 現行 **Windows Server 2019（IIS 10.0 version 1809 / build 10.0.17763）** から **Server 2022（build 10.0.20348）** / **Server 2025（build 10.0.26100）** への移行
**前提:** APサーバとして IIS でホストする **WCF（SOAP）サービス** をクライアント（[VB.NET](http://VB.NET) WinForms .NET Framework 4.7.2）が呼び出す3層構成。Oracle 19c は別サーバ。
**関連ページ:** [開発環境バージョンアップ調査メモ（[VB.NET](http://VB.NET) / IIS / Oracle）](https://www.notion.so/VB-NET-IIS-Oracle-e0652fefa8f446a8adc357927d0a71b8?pvs=21)・[VS2017からのアップグレード非互換情報（VS2019 / VS2022 / VS2026）](https://www.notion.so/VS2017-VS2019-VS2022-VS2026-4cbceffed22c499ea7ef7f328cc0b9d8?pvs=21)・[Spread for Windows Forms 12 SP10 からのアップグレード非互換情報](https://www.notion.so/Spread-for-Windows-Forms-12-SP10-c8f98cda6bc240b0bab9b4d5127caa00?pvs=21)

</aside>

## 0. 結論サマリ

<aside>
✅

**IIS のメジャー番号は 10.0 のまま固定**だが、**OS のビルドにバンドルされる実体は別物**。Server 2019（17763）→ 2022（20348）→ 2025（26100）でビルド番号が大きく変わり、**TLS 既定値・既定で有効な役割サービス・削除コンポーネント** に非互換が発生する。本件 SOAP 構成での要対応ポイントは主に①TLS強制、②WCF Activation 役割の明示追加、③役割サービス一覧の差分移植 の3点。

</aside>

### 0-1. Windows Server と IIS の対応関係（早見表）

| Server OS | IIS バージョン表記 | OS / IIS ビルド | HTTP/3 | TLS 1.0/1.1 既定 | OS Extended End |
| --- | --- | --- | --- | --- | --- |
| **Server 2016** | IIS 10.0 | 10.0.14393 | × | 有効 | 2027-01-12 |
| **Server 2019**（現行） | IIS 10.0 version 1809 | 10.0.17763 | × | 有効 | 2029-01-09 |
| **Server 2022** | IIS 10.0 | 10.0.20348 | ○ (opt-in) | **事実上無効** | 2031-10-14 |
| **Server 2025** | IIS 10.0 | 10.0.26100 | ○ | **事実上無効** | 2035-10-11 |

出典: [IIS Lifecycle (Microsoft Learn)](https://learn.microsoft.com/en-us/lifecycle/products/internet-information-services-iis)・[Internet Information Services (Wikipedia)](https://en.wikipedia.org/wiki/Internet_Information_Services)・[New Features in IIS 10.0 v1809](https://learn.microsoft.com/en-us/iis/get-started/whats-new-in-iis-10-version-1809/new-features-introduced-in-iis-10-1809)

<aside>
💡

**重要前提:** IIS は Windows Server に組み込まれており **単体アップグレードは不可能**。IIS バージョンを変えるには **OS をアップグレードする以外の方法がない**（`aspnet_regiis` などはあくまでも [ASP.NET](http://ASP.NET) ランタイムの登録ツールであり、IIS 本体の差し替えではない）。

</aside>

---

## 1. Server 2019 → 2022 の主要な非互換ポイント

### 1-1. TLS 既定値の厳格化 ⚠️ 最重要

#### 何が変わるか

- **Server 2022 では TLS 1.0 / 1.1 が事実上無効化**。Schannel の Cipher Suite 既定セットから古い暗号スイートが除外され、TLS 1.0/1.1 を有効化しても**ネゴシエーションが失敗する**ケースが多発。
- Microsoft は 2022-09 以降「Server 2022 では TLS 1.2 を前提とした構成」を明言。
- 出典: [Unable to enable TLS 1.1 on WS2022 (ServerFault)](https://serverfault.com/questions/1198424/unable-to-enable-tls-1-1-on-windows-server-2022-datacenter-azure-edition)・[TLS Cipher Suites in WS2022 (Microsoft Learn)](https://learn.microsoft.com/en-us/windows/win32/secauthn/tls-cipher-suites-in-windows-server-2022)

#### 本件構成での影響

| 箇所 | 影響 | 確認方法 |
| --- | --- | --- |
| WinForms クライアントの SOAP 呼び出し | **接続不能リスク** | `ServicePointManager.SecurityProtocol` の明示有無を grep |
| .NET Framework 4.7.2 / 4.8 の既定 TLS | 4.7+ は OS 既定（Schannel）に従う → 4.7.2 + Server 2022 なら TLS 1.2 が選ばれる | `SchUseStrongCrypto` レジストリ確認 |
| 4.5.x / 4.6.x クライアントが残っている場合 | **TLS 1.0 を選びに行く** → Server 2022 で接続失敗 | クライアント機の .NET FW バージョン棚卸し |
| Oracle Client (Net Listener) の TLS 設定 | 本件は AP-DB 間のみなので Oracle 側 TLS は別途確認 | `sqlnet.ora` の `SQLNET.ENCRYPTION_*` |

#### 対策

```vbnet
' クライアント起動時（Sub Main や AppDomain 初期化箇所）に明示
System.Net.ServicePointManager.SecurityProtocol = _
    System.Net.SecurityProtocolType.Tls12 Or _
    System.Net.SecurityProtocolType.Tls13
```

またはレジストリで .NET FW 全体を強制:

```
HKLM\SOFTWARE\Microsoft\.NETFramework\v4.0.30319
  SchUseStrongCrypto = 1 (DWORD)
HKLM\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319
  SchUseStrongCrypto = 1 (DWORD)
```

#### 検出 grep（PowerShell）

```powershell
# クライアント側で TLS バージョン明示しているか
Select-String -Path *.vb -Pattern "SecurityProtocol|ServicePointManager"
# Web リファレンス・SOAP プロキシ生成コード
Select-String -Path *.vb -Pattern "SoapHttpClientProtocol|BasicHttpBinding|WSHttpBinding"
```

### 1-2. WCF Activation 役割が既定で外れる ⚠️ 本件直撃

#### 事象

- Server 2022 にクリーンインストール + IIS 役割追加だけ行うと、**WCF サービスの `.svc` ファイルが 404 を返す**:
    - `Web Host failed to process a request. Exception System.Web.WebHttpException .svc does not exist.`
- 原因: 「**HTTP Activation**」役割サービスが既定で未選択。
- 出典: [SO 76790329 - IIS 10 issues upgrade WS2013→WS2022](https://stackoverflow.com/questions/76790329/iis-10-0-issues-while-upgrade-from-wind-2013-to-windows-server-2022)
- 同様に **Net.Tcp Listener Adapter** サービスも `WCF-NonHttp-Activation` を明示有効化しないと存在しない。
- 出典: [MS Q&A: We have a .NET 4.8 WCF application on WS2022](https://learn.microsoft.com/en-us/answers/questions/2193206/)

#### 必要な役割サービス一覧（WCF SOAP 受け）

| Windows 機能パス | 役割サービス名 | 本件必要性 |
| --- | --- | --- |
| .NET Framework 4.x Features | WCF Services > **HTTP Activation** | **必須**（.svc を動かすため） |
| .NET Framework 4.x Features | WCF Services > TCP Activation | Net.Tcp 使う場合のみ |
| .NET Framework 4.x Features | WCF Services > Named Pipe Activation | 通常不要 |
| .NET Framework 4.x Features | WCF Services > Message Queuing Activation | MSMQ 使う場合のみ |
| Web Server (IIS) > Application Development | [**ASP.NET](http://ASP.NET) 4.x** | **必須** |
| Web Server (IIS) > Application Development | **ISAPI Extensions / ISAPI Filters** | **必須** |
| Web Server (IIS) > Application Development | **.NET Extensibility 4.x** | **必須** |
| Web Server (IIS) > Common HTTP Features | **Static Content / Default Document / HTTP Errors** | 必須 |
| Web Server (IIS) > Security | **Windows Authentication / Request Filtering** | 認証方式に応じて |
| Web Server (IIS) > Performance | Static / Dynamic Content Compression | 推奨 |
| Web Server (IIS) > Management Tools | IIS Management Console | 運用上必須 |

#### 旧サーバから役割一覧を移植する PowerShell 手順

```powershell
# 1) 旧サーバ（Server 2019）でロール一覧を出力
Get-WindowsFeature | Where-Object { $_.Installed -and ($_.Name -like 'Web-*' -or $_.Name -like 'NET-*' -or $_.Name -like 'WAS-*') } |
    Select-Object Name, DisplayName |
    Export-Csv -Path C:\temp\iis-roles-2019.csv -NoTypeInformation -Encoding UTF8

# 2) 新サーバ（Server 2022）で同じロールを一括導入
Import-Csv C:\temp\iis-roles-2019.csv | ForEach-Object {
    Install-WindowsFeature -Name $_.Name -IncludeManagementTools
}

# 3) 確認: 新旧で diff を取る
$old = Import-Csv C:\temp\iis-roles-2019.csv | Select-Object -ExpandProperty Name
$new = Get-WindowsFeature | Where-Object { $_.Installed } | Select-Object -ExpandProperty Name
Compare-Object $old $new
```

### 1-3. [ASP.NET](http://ASP.NET) 4.8 / web.config 関連の挙動差

#### 報告されている事象

- **HTTP Error 403.14 - Forbidden** で web.config が読めない
- **`.svc`** ハンドラマッピングが未登録
- 出典: [SO 77933072 -](https://stackoverflow.com/questions/77933072/asp-net-web-application-net-framework-4-8-not-running-within-iis-10-on-windo) [ASP.NET](http://ASP.NET) [4.8 not running in IIS 10 on WS2022](https://stackoverflow.com/questions/77933072/asp-net-web-application-net-framework-4-8-not-running-within-iis-10-on-windo)

#### 対策

```powershell
# .NET Framework 4.8 の ASP.NET ハンドラを再登録
# （x64 版）
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\aspnet_regiis.exe -i
# （x86 版）
C:\Windows\Microsoft.NET\Framework\v4.0.30319\aspnet_regiis.exe -i

# WCF サービスファイル拡張子の登録（.svc）
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\ServiceModelReg.exe -r
```

### 1-4. HTTP/3 / QUIC の追加（既定では無効）

- Server 2022 で HTTP/3 がネイティブ対応（要 TLS 1.3 + UDP 443）
- **既定では無効**（`EnableHttp3` レジストリで明示）。SOAP/WCF を HTTP/3 化する用途は本件では想定外なので**スルーで OK**。
- 出典: [Enabling HTTP/3 support on Windows Server 2022](https://techcommunity.microsoft.com/blog/networkingblog/enabling-http3-support-on-windows-server-2022/2676880)

### 1-5. その他の注意点

- **SMB AES-256 暗号化** が既定有効化
- **DNS over HTTPS (DoH)** クライアント対応
- **SMB over QUIC**（Azure Edition のみ）
- いずれも本件 IIS+SOAP 構成への直接影響はほぼなし

---

## 2. Server 2022 → 2025 の主要な非互換ポイント

### 2-1. 削除されたコンポーネント ⚠️

| 削除項目 | 本件影響 | 対処 |
| --- | --- | --- |
| **IIS 6 Management Console** (`Web-Lgcy-Mgmt-Console`) | IIS 6 メタベース互換 API を使う**古い管理スクリプト**が動かない | `Microsoft.Web.Administration` (IIS 7+ ネイティブ API) または PowerShell `WebAdministration` モジュールへ書き直し |
| **SMTP Server 役割** | IIS SMTP に依存したメール送信機能が**完全停止** | 外部 SMTP リレー（Exchange / SendGrid / Postfix 等）へ移行 |
| **NTLMv1** | 古い Windows 認証クライアントが NG | NTLMv2 / Kerberos へ移行 |
| **WordPad** | — | — |
| **PowerShell 2.0 Engine** | 古い保守スクリプトで `-Version 2.0` を指定しているもの | PowerShell 5.1 / 7 系で再検証 |

出典: [Features removed in WS2025 (Microsoft Learn)](https://learn.microsoft.com/en-us/windows-server/get-started/removed-deprecated-features-windows-server)・[Features removed starting with WS2025 (](https://blog.markic.org/2025/01/30/features-removed-or-no-longer-developed-starting-with-windows-server-2025/)[markic.org](http://markic.org)[)](https://blog.markic.org/2025/01/30/features-removed-or-no-longer-developed-starting-with-windows-server-2025/)

### 2-2. ハードウェア要件の引き上げ

- TPM 2.0 / UEFI Secure Boot が事実上必須
- 仮想化基盤（Hyper-V / VMware）側のホスト要件も再確認

### 2-3. Hotpatching が有償サブスクリプション化

- Server 2025 では **Hotpatching が有償サブスク**（Azure Arc 経由）に変更。再起動レスのセキュリティパッチ適用を続けるなら追加費用が発生。

---

## 3. 直接アップグレードの可否マトリクス

| 移行 | 直接可否 | 必要な再構成（IIS） | 必要な再構成（OS） | 主な検証ポイント |
| --- | --- | --- | --- | --- |
| WS2019 → **WS2022** | **○ 直接可**（in-place / 新規構築どちらも） | 役割一覧の diff 移植・WCF Activation 明示・aspnet_regiis 再登録 | TLS 1.2 強制への各種クライアント対応 | SOAP 接続テスト（クライアント TLS 設定） |
| WS2019 → **WS2025** | ○（in-place は 2 段階推奨） | 同上 + IIS 6 互換 API / SMTP 役割の代替確認 | TPM 2.0 / UEFI / Hotpatching 方針 | 古い管理スクリプトの動作確認 |
| WS2022 → **WS2025** | **○ 直接可** | SMTP / IIS 6 互換 API / NTLMv1 の依存有無 | Hotpatching サブスク要否 | 削除コンポーネントへの依存洗い出し |

<aside>
💡

**段階移行 vs 直行:** WS2019 はサポートが 2029-01 まで残るため、**当面は WS2022 へ移行 → 数年後に WS2025（または次期 LTSC）へ二段階移行**が現実的。WS2025 を直行ターゲットにするなら、SMTP・IIS 6 互換 API 依存の事前棚卸しが必要。

</aside>

---

## 4. 本件構成（[VB.NET](http://VB.NET) WinForms ⇄ IIS SOAP ⇄ Oracle）への影響まとめ

| 観点 | WS2019（現行） | WS2022 | WS2025 |
| --- | --- | --- | --- |
| IIS バージョン | 10.0.17763 | 10.0.20348 | 10.0.26100 |
| WCF SOAP（HTTP/HTTPS） | 動作 | **HTTP Activation 明示要** | 同左 |
| WCF Net.Tcp | 動作 | **WCF-NonHttp-Activation 明示要** | 同左 |
| TLS 1.2 強制（クライアント側） | 任意 | **事実上必須** | 必須 |
| [ODP.NET](http://ODP.NET) Unmanaged 19c | ○ | △ 公式サポート要確認 | ×（21.4+ または 23ai 必要） |
| [ODP.NET](http://ODP.NET) Unmanaged 21c (21.4+) | — | ○ | △ |
| [ODP.NET](http://ODP.NET) 23ai/26ai | — | ○ | **○（公式対応）** |
| .NET Framework 4.8 | ○ | ○ | ○ |
| IIS 6 互換管理 API | ○ | ○ | **削除** |
| SMTP Server（IIS 内蔵） | ○ | ○ | **削除** |

---

## 5. 移行前チェックリスト

### 5-1. 旧サーバ（WS2019）側で実施

- [ ]  **役割サービス一覧の取得**（§1-2 の PowerShell スクリプト）
- [ ]  **`applicationHost.config` のバックアップ**: `%windir%\System32\inetsrv\config\applicationHost.config`
- [ ]  **サイト・アプリプール設定のエクスポート**:
    
    ```powershell
    %windir%\System32\inetsrv\appcmd.exe list site /config /xml > C:\temp\sites.xml
    %windir%\System32\inetsrv\appcmd.exe list apppool /config /xml > C:\temp\apppools.xml
    ```
    
- [ ]  **TLS バインディング・証明書一覧の確認**
- [ ]  **WCF サービスの SOAP エンドポイント URL リスト化**
- [ ]  **IIS SMTP 使用有無**（→ WS2025 移行時のみ重要）

### 5-2. クライアント（WinForms）側で実施

- [ ]  `ServicePointManager.SecurityProtocol` 明示有無を grep（§1-1）
- [ ]  Web リファレンス・SOAP プロキシのエンドポイント URL 確認
- [ ]  `app.config` の `<system.serviceModel>` バインディング確認（`security mode`、`transport clientCredentialType`）
- [ ]  [ODP.NET](http://ODP.NET) Client（ORACLE_HOME）のバージョン確認

### 5-3. 新サーバ（WS2022 / WS2025）側で実施

- [ ]  §1-2 の PowerShell で役割を一括導入
- [ ]  `aspnet_regiis -i` 実行
- [ ]  `ServiceModelReg.exe -r` 実行（WCF）
- [ ]  TLS 1.2/1.3 の有効化確認（IIS Crypto 推奨）
- [ ]  サーバ証明書の再インポートと SNI バインディング設定
- [ ]  `applicationHost.config` の差分マージ（直接コピーは非推奨）
- [ ]  WS2025 のみ: SMTP 代替・IIS 6 互換 API 代替の確認

### 5-4. 移行後の検証

- [ ]  スモークテスト（最小限の SOAP 呼び出し）
- [ ]  TLS バージョン確認: `openssl s_client -connect <host>:443 -tls1_2`
- [ ]  エラーログ: `C:\Windows\System32\LogFiles\HTTPERR\` と IIS ログ `C:\inetpub\logs\LogFiles\`
- [ ]  パフォーマンス比較（応答時間・メモリ使用量）
- [ ]  WCF トレースを一時的に有効化して詳細診断

---

## 6. 推奨アクション

1. **当面の延命:** WS2019 のサポート期限（2029-01-09）まではそのまま運用可能。ただし **TLS 1.0/1.1 は段階的に無効化**してクライアント側を Tls12 に揃える準備を先行。
2. **第1段階:** **WS2022 への移行**を 2027〜2028 を目処に計画。WCF Activation 役割の明示追加と aspnet_regiis 再登録の手順を**スクリプト化**しておく。
3. **第2段階:** WS2025（または次期 LTSC）への移行を 2030 前後で検討。**IIS SMTP / IIS 6 互換管理 API 依存の早期棚卸し**が分かれ目。
4. **VS / Spread / Oracle のバージョンアップと歩調を合わせる:**
    - VS2022 / VS2026 は OS 側の制約と独立（[VS2017からのアップグレード非互換情報（VS2019 / VS2022 / VS2026）](https://www.notion.so/VS2017-VS2019-VS2022-VS2026-4cbceffed22c499ea7ef7f328cc0b9d8?pvs=21)）
    - Spread v19 は WS2022/2025 どちらでも動作（[Spread for Windows Forms 12 SP10 からのアップグレード非互換情報](https://www.notion.so/Spread-for-Windows-Forms-12-SP10-c8f98cda6bc240b0bab9b4d5127caa00?pvs=21)）
    - [ODP.NET](http://ODP.NET) は WS2025 では 21.4+ 以上必須（[開発環境バージョンアップ調査メモ（[VB.NET](http://VB.NET) / IIS / Oracle）](https://www.notion.so/VB-NET-IIS-Oracle-e0652fefa8f446a8adc357927d0a71b8?pvs=21)）
5. **作業見積もり:** IIS 役割移植・WCF Activation 設定・TLS 強制化対応で **AP サーバ 1 台あたり 1〜2 人日**が目安（事前検証込みで初回は 3〜5 人日）。

---

## 8. 現行構成から TLS 使用状況を読み取る方法（基盤がブラックボックスの場合）

<aside>
🔍

**前提:** SOAP 通信処理を社内基盤層（フレームワーク）で抽象化しており、基盤のバージョン・TLS 対応有無が不明。コードに手を入れずに**静的な設定ファイル・レジストリ・ログ**だけで現状の TLS 使用状況を確定したいケース。
**結論:** "クライアントが http で呼んでいるか https で呼んでいるか" と "OS / .NET FW の Schannel 設定" を組み合わせれば、**TLS 使用有無と最低バージョンの推定はほぼ可能**。実通信のキャプチャは最終確認用。

</aside>

### 8-1. 調査の優先順位（早見）

| 順 | 調査箇所 | 分かること | 難易度 |
| --- | --- | --- | --- |
| ① | クライアント `app.config` / Web リファレンス URL | **そもそも http か https か** | ★ 簡単 |
| ② | サーバ `web.config` の `<system.serviceModel>` | WCF バインディングの `security mode` / `transport` | ★ 簡単 |
| ③ | IIS サイトバインディング（`applicationHost.config` / `appcmd list site`） | https バインディング・証明書・sslFlags | ★ 簡単 |
| ④ | `netsh http show sslcert` | ポートにバインドされた証明書ハッシュ | ★★ |
| ⑤ | Schannel レジストリ | OS が**許可**している TLS バージョン範囲 | ★★ |
| ⑥ | .NET Framework `SchUseStrongCrypto` / `SystemDefaultTlsVersions` | .NET FW アプリが**選びに行く** TLS | ★★ |
| ⑦ | Schannel イベントログ（要事前有効化） | **実際にネゴったプロトコル番号** | ★★★ |
| ⑧ | `openssl s_client` / `nmap` / Wireshark | サーバが受け付ける TLS バージョン・Cipher 一覧 | ★★★ |

### 8-2. クライアント側 — まず http/https を確定する

#### app.config / *.exe.config を grep

```powershell
# エンドポイント URL の抽出
Select-String -Path *.config -Pattern 'address\s*=\s*"[^"]+"' -AllMatches
Select-String -Path *.config -Pattern 'http(s)?://' -AllMatches
```

- `address="http://..."` のみ → **TLS 不使用（平文 SOAP）**
- `address="https://..."` → **TLS 使用**（バージョンは別途 §8-5 で判定）
- 両方混在 → エンドポイントごとに棚卸し必要

#### `<system.serviceModel>` のバインディング

```xml
<!-- 例: basicHttpBinding の場合 -->
<basicHttpBinding>
  <binding name="X">
    <security mode="None" />          <!-- ← 平文（TLS不使用） -->
    <security mode="Transport" />     <!-- ← TLS必須（https） -->
    <security mode="TransportWithMessageCredential" />  <!-- TLS + メッセージ認証 -->
    <security mode="Message" />       <!-- メッセージレベル暗号化（http上でも可） -->
  </binding>
</basicHttpBinding>
```

| `security mode` | TLS 使用 | 備考 |
| --- | --- | --- |
| `None` | **しない** | 平文 SOAP |
| `Transport` | **必須** | https バインディング必須 |
| `TransportWithMessageCredential` | **必須** | 同上 |
| `Message` | 任意 | メッセージ暗号化のみ。TLS は別軸 |
| 未指定（既定） | バインディング種別による | `basicHttpBinding` 既定は `None`、`wsHttpBinding` 既定は `Message` |

#### 旧 ASMX（古い Web リファレンス）の場合

`Reference.vb` / `Reference.cs` 内で `URL = "http://..."` または `"https://..."` をハードコード or `Settings.settings` で持つ。ここで http/https を確認。

```powershell
Select-String -Path Reference.vb,Reference.cs,*.settings -Pattern 'http(s)?://'
```

### 8-3. サーバ側 — IIS バインディング・web.config の確認

#### IIS サイトバインディングの確認

```powershell
# 全サイトのバインディング一覧（http/https の判別が一目）
%windir%\System32\inetsrv\appcmd.exe list site /text:bindings

# applicationHost.config の bindings 部分
Select-String -Path "$env:windir\System32\inetsrv\config\applicationHost.config" `
    -Pattern '<binding\s' -Context 0,1
```

出力例:

```
http/*:80:                         ← TLS なし
https/*:443:hostname.example.com   ← TLS あり
```

#### `applicationHost.config` の sslFlags（クライアント証明書要求等）

```powershell
Select-String -Path "$env:windir\System32\inetsrv\config\applicationHost.config" `
    -Pattern 'sslFlags|<access' -Context 1,1
```

- `sslFlags="Ssl"` → HTTPS 必須
- `sslFlags="SslNegotiateCert"` → クライアント証明書要求（双方向 TLS）
- `sslFlags="SslRequireCert"` → クライアント証明書必須
- 未設定 → http 許可

#### web.config（サーバ側 WCF サービス）

基本は §8-2 と同じ `<system.serviceModel>` 構造を**サーバ側でも**確認:

```powershell
Get-ChildItem -Path C:\inetpub\wwwroot -Recurse -Filter web.config |
    ForEach-Object {
        Write-Host "=== $($_.FullName) ==="
        Select-String -Path $_.FullName -Pattern 'security mode|httpsTransport|httpTransport|<binding ' -Context 0,2
    }
```

#### URL Rewrite による HTTP→HTTPS 強制

```powershell
Select-String -Path C:\inetpub\wwwroot\**\web.config -Pattern 'HTTPS|{HTTPS}|redirect' -Context 1,1
```

#### HSTS 設定の有無（IIS 10+）

```powershell
Select-String -Path "$env:windir\System32\inetsrv\config\applicationHost.config" `
    -Pattern '<hsts'
```

HSTS が enabled なら https 強制が確定。

#### `netsh http show sslcert` で証明書バインディングを物証として残す

```powershell
netsh http show sslcert
# 各 IP:Port に対する Certificate Hash, Application ID, 証明書ストア名が出力される
# → このポートで HTTPS（TLS）が動いている物証
```

### 8-4. Schannel（OS）レベルでの TLS 許可状況

ここは「**OS が許可している TLS バージョン範囲**」。実際にどのバージョンでネゴるかは**クライアントとの交渉結果**だが、ここで `Disabled` になっていれば絶対に使われない。

#### レジストリの読み取りスクリプト（コピペ実行可）

```powershell
$base = 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols'
@('SSL 2.0','SSL 3.0','TLS 1.0','TLS 1.1','TLS 1.2','TLS 1.3') | ForEach-Object {
    $proto = $_
    foreach ($side in 'Client','Server') {
        $path = "$base\$proto\$side"
        if (Test-Path $path) {
            $v = Get-ItemProperty $path -ErrorAction SilentlyContinue
            [pscustomobject]@{
                Protocol         = $proto
                Side             = $side
                Enabled          = $v.Enabled
                DisabledByDefault= $v.DisabledByDefault
            }
        } else {
            [pscustomobject]@{
                Protocol = $proto; Side = $side
                Enabled  = '(キー無し→OS既定)'
                DisabledByDefault = '(キー無し→OS既定)'
            }
        }
    }
} | Format-Table -AutoSize
```

| `Enabled` | `DisabledByDefault` | 意味 |
| --- | --- | --- |
| 1 | 0 | **有効**（明示的に使える） |
| 0 | 1 | **無効**（明示的に禁止） |
| キー無し | キー無し | OS の既定に従う（WS2019 は TLS 1.0/1.1 既定有効、WS2022 は事実上 TLS 1.2 のみ） |

### 8-5. .NET Framework アプリ側の TLS 選択ロジック

#### `SchUseStrongCrypto` の確認

```powershell
# 64bit
Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319' `
    -Name SchUseStrongCrypto, SystemDefaultTlsVersions -ErrorAction SilentlyContinue
# 32bit
Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319' `
    -Name SchUseStrongCrypto, SystemDefaultTlsVersions -ErrorAction SilentlyContinue
```

| キー | 値 | 意味 |
| --- | --- | --- |
| `SchUseStrongCrypto` | 1 | SSL 3.0 / TLS 1.0 を使わず、**TLS 1.1 / 1.2** を選びに行く |
| `SystemDefaultTlsVersions` | 1 | **OS Schannel 既定**を使う（最も推奨。最新 TLS が自動で選ばれる） |
| 両方 0 / 未設定 | — | **.NET 4.5 系の古い既定**で動く（=TLS 1.0 を選びに行く可能性大） |

<aside>
⚠️

**.NET Framework のバージョン別既定:**
• **.NET 4.5 / 4.5.1**: 既定で TLS 1.0
• **.NET 4.6 / 4.6.1**: TLS 1.2 を含む（ただし `SchUseStrongCrypto` 推奨）
• **.NET 4.7+**: `SystemDefaultTlsVersions = 1` が事実上の推奨。**OS 側 Schannel に従うため Schannel が TLS 1.2/1.3 のみなら自動でそれが使われる**
• **.NET 4.8+**: 既定で `SystemDefaultTlsVersions` 相当の挙動
本件は **.NET Framework 4.7.2 が現行**なので、Schannel が TLS 1.2 を許可していれば事実上 TLS 1.2 が選ばれる可能性が高いが、レジストリ未設定だと「.NET 4.5 系のフォールバック動作」になるケースもあるため**明示設定推奨**。

</aside>

### 8-6. 「実際に流れている TLS バージョン」を観測する 3 つの手段

#### ① Schannel イベントログ（一時有効化、再起動不要）

```powershell
# Schannel イベントログを最大化
Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL' `
    -Name EventLogging -Value 7 -Type DWord
# 値の意味: 1=エラー, 2=警告, 4=情報, 7=全部
```

その後、SOAP 通信を 1 回流して **イベントビューアー → Windows ログ → システム** を確認:

- **Event ID 36880** "From client/server, an SSL XX/XX handshake completed successfully" に **TLS バージョン**が出る
- **Event ID 36874 / 36888** はネゴ失敗時のクライアント/サーバ拒否理由

調査終了後は元に戻す:

```powershell
Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL' `
    -Name EventLogging -Value 1 -Type DWord
```

#### ② サーバ側 IIS から外向きに `openssl s_client`（または `Test-NetConnection`）

```powershell
# サーバが受け付ける TLS バージョンを総当り
openssl s_client -connect <APサーバ>:443 -tls1     # TLS 1.0 で繋がるか
openssl s_client -connect <APサーバ>:443 -tls1_1   # TLS 1.1
openssl s_client -connect <APサーバ>:443 -tls1_2   # TLS 1.2
openssl s_client -connect <APサーバ>:443 -tls1_3   # TLS 1.3
# → 接続成立すれば「そのバージョンで受付可能」と判定
```

PowerShell だけで完結させたい場合:

```powershell
# .NET の SslStream で各バージョンを試す
$h = '<APサーバ>'; $p = 443
foreach ($v in 'Tls','Tls11','Tls12','Tls13') {
    try {
        $tcp = New-Object System.Net.Sockets.TcpClient($h, $p)
        $ssl = New-Object System.Net.Security.SslStream($tcp.GetStream(), $false, {$true})
        $ssl.AuthenticateAsClient($h, $null,
            [System.Security.Authentication.SslProtocols]::$v, $false)
        "$v : OK ($($ssl.SslProtocol))"
        $ssl.Close(); $tcp.Close()
    } catch { "$v : NG ($($_.Exception.Message))" }
}
```

#### ③ Wireshark / netsh trace（最終手段）

```powershell
# OS 標準キャプチャ（Wireshark なしで取れる）
netsh trace start scenario=internetclient_dbg capture=yes tracefile=C:\temp\soap.etl
# … SOAP 通信を 1 回流す …
netsh trace stop
```

生成された `.etl` を Wireshark や Microsoft Message Analyzer で開けば **TLS ClientHello / ServerHello のバージョン**が完全に見える。

### 8-7. 本件への当てはめ（推奨調査ステップ）

1. **クライアント `app.config` / Reference.vb の URL を grep** → http か https か即判定（10 分作業）
2. **サーバ `applicationHost.config` のバインディング確認** → https バインディングの有無、ポート、証明書（30 分作業）
3. **サーバ `web.config` の `<system.serviceModel>` 確認** → `security mode` から TLS 必須かどうかを物証化（30 分作業）
4. **サーバ・クライアント両方の Schannel レジストリと .NET FW レジストリをスナップショット**（§8-4 / §8-5 のスクリプトを流すだけ、5 分作業）
5. **Schannel イベントログを一時有効化して 1 回 SOAP 通信を流す**（§8-6①、15 分作業）
6. 結果を表にまとめて「現状 TLS x.x で動作中」を**物証付きで確定**

<aside>
💡

**ポイント:** ①〜④ までの静的調査だけで「http か https か」「OS が TLS 1.2 以上を許可しているか」「.NET FW が古いフォールバックに落ちる構成か」が判明します。基盤層のソースを覗かなくても、**設定ファイルとレジストリだけで TLS の実態は推定可能**。実通信観測（⑤以降）は補強材料として位置づけ、移行先の WS2022 で動くかの予測根拠にできます。

</aside>

### 8-8. 調査結果テンプレ（Notion で記録する用）

| 項目 | 値 | 調査方法 | 備考 |
| --- | --- | --- | --- |
| クライアント呼び出し URL | 例: `http://...` or `https://...` | app.config / Reference.vb grep |  |
| WCF `security mode` | 例: `None` / `Transport` | app.config / web.config |  |
| IIS バインディング | 例: `http:80` / `https:443` | `appcmd list site` |  |
| SSL 証明書 | 例: 有り（hash=...）/ 無し | `netsh http show sslcert` |  |
| Schannel TLS 1.0 (Server) | Enabled / Disabled / 既定 | レジストリ §8-4 |  |
| Schannel TLS 1.1 (Server) | 同上 | 同上 |  |
| Schannel TLS 1.2 (Server) | 同上 | 同上 |  |
| Schannel TLS 1.3 (Server) | 同上 | 同上 |  |
| .NET FW `SchUseStrongCrypto` | 0 / 1 / 未設定 | レジストリ §8-5 |  |
| .NET FW `SystemDefaultTlsVersions` | 0 / 1 / 未設定 | 同上 |  |
| 実ネゴ TLS バージョン | 例: TLS 1.2 | Schannel Event 36880 |  |
| 判定 | 例: 現状 TLS 1.2 / WS2022 移行で問題なし | — |  |

---

## 9. 国内専用サーバ（VPN+HTTP）と海外専用サーバ（インターネット+HTTPS）の分離構成での追加考慮事項

<aside>
🌐

**本件のサーバ論理構成:**
• **国内専用 AP サーバ（仮名 AP-DOM）:** 社内 LAN ・ VPN 接続クライアント専用。**HTTP（平文 SOAP）のみを公開**
• **海外専用 AP サーバ（仮名 AP-OVR）:** インターネット公開。**HTTPS（TLS）のみを公開**
• **2 台は独立サーバとして本体・サイト設定・web.config も分離**されている。同一サーバ内での混在はなし。

</aside>

### 9-1. 論理構成図

```mermaid
flowchart LR
  subgraph DOM["国内拠点"]
    DC["WinFormsクライアント<br>（国内）"]
  end
  subgraph VPN["VPNトンネル<br>（IPsec/SSL-VPN）"]
  end
  subgraph OVR["海外拠点"]
    OC["WinFormsクライアント<br>（海外）"]
  end
  subgraph INT["インターネット"]
  end
  subgraph DMZ["DMZ / 公開区画"]
    LB["LB / WAF / Reverse Proxy ？"]
  end
  subgraph DOMSV["AP-DOM（国内専用 IIS / WS2019）"]
    IIS80["http:80　のみ"]
  end
  subgraph OVRSV["AP-OVR（海外専用 IIS / WS2019）"]
    IIS443["https:443　のみ"]
  end
  DC --> VPN --> IIS80
  OC --> INT --> LB --> IIS443
```

### 9-2. サーバ分離で WS2022 移行リスクがサーバごとに完全分離される

| サーバ | 公開プロトコル | WS2022 へ移行した際の主リスク | リスクレベル |
| --- | --- | --- | --- |
| **AP-DOM（国内専用）** | http:80 のみ | **TLS 関連リスクは完全ゼロ**。WCF Activation 役割追加・aspnet_regiis 再登録のみ | **低** |
| **AP-OVR（海外専用）** | https:443 のみ | TLS 1.0/1.1 不可に伴う古い海外クライアントの接続不能 → 要事前棚卸し | **高** |

<aside>
✅

**サーバ分離で得られるメリット（3点）:**
② **移行をサーバごとにスケジュール可能**。 §9-7 の "国内先行パターン" を推奨。
③ **トラブル時の切り分けが明確**。 クライアントの接続先 IP/FQDN でどちらのサーバ側の問題か即判定。
④ **証明書・セキュリティ設定もサーバごとに独立**。 AP-DOM には SSL 証明書不要、AP-OVR のみ考慮すればよい。

</aside>

### 9-3. AP-DOM（国内専用サーバ）の WS2022 移行ポイント

#### 期待する設定

```powershell
# AP-DOM で appcmd を実行
%windir%\System32\inetsrv\appcmd.exe list site /text:bindings
# 期待出力例: bindings:"http/*:80:"  ← https バインディングはない

netsh http show sslcert
# 期待出力: （何も出力されない、または名前付きパイプ他サービスのみ）
```

#### web.config はシンプル

```xml
<service name="...">
  <endpoint address="" binding="basicHttpBinding"
            bindingConfiguration="BasicHttp" contract="..." />
</service>
<bindings>
  <basicHttpBinding>
    <binding name="BasicHttp">
      <security mode="None" />   <!-- これだけのはず -->
    </binding>
  </basicHttpBinding>
</bindings>
```

#### WS2022 移行でのチェック項目

- [ ]  WCF HTTP Activation 役割有効化（§1-2）
- [ ]  `aspnet_regiis -i` / `ServiceModelReg.exe -r`（§1-3）
- [ ]  役割サービス一覧の diff 移植（§1-2）
- [ ]  クライアント接続先ホスト名・DNS エントリの切り替え
- [ ]  **TLS 関連は一切不要**（http:80 のみなので Schannel も .NET FW SchUseStrongCrypto も無関係）

<aside>
💡

**AP-DOM は WS2022 移行の「ポスターチャイルド」にできる**。TLS レスにリスクを限定した状態で WCF Activation ・[ASP.NET](http://ASP.NET) ハンドラ再登録・役割一覧移植の手順をスクリプト化・検証し、そのノウハウを AP-OVR に踏襲させるのがリスク最小・効率最大のアプローチ。

</aside>

### 9-4. AP-OVR（海外専用サーバ）の WS2022 移行ポイント

#### 期待する設定

```powershell
# AP-OVR で appcmd を実行
%windir%\System32\inetsrv\appcmd.exe list site /text:bindings
# 期待出力例: bindings:"https/*:443:hostname.example.com"  ← https のみ

netsh http show sslcert
# 期待出力: 0.0.0.0:443 に証明書 hash がバインドされている
```

もし `netsh http show sslcert` に何も出ない場合は **サーバ手前の LB/WAF で TLS 終端しているパターン**。次の§9-5 参照。

#### web.config は https 専用

```xml
<service name="...">
  <endpoint address="" binding="basicHttpBinding"
            bindingConfiguration="BasicHttps" contract="..." />
</service>
<bindings>
  <basicHttpBinding>
    <binding name="BasicHttps">
      <security mode="Transport" />
      <!-- または TransportWithMessageCredential -->
    </binding>
  </basicHttpBinding>
</bindings>
```

#### WS2022 移行でのチェック項目

- [ ]  AP-DOM で作った手順をそのまま適用（スクリプトとして保管）
- [ ]  **追加で TLS 関連チェック**:
    - [ ]  Schannel TLS 1.0 / 1.1 を明示的に無効化（IIS Crypto の Best Practices 推奨）
    - [ ]  TLS 1.2 / 1.3 と Cipher Suite の推奨セット適用
    - [ ]  サーバ証明書の再インポートと SNI バインディング
    - [ ]  HSTS 設定の維持（現行有効のとき）
- [ ]  海外クライアントの接続可能性検証（§9-6 参照）

### 9-5. AP-OVR の TLS 終端位置を確認する

サーバが分離していても "AP-OVR 本体で TLS を受けているのか、手前の LB/WAF で受けて AP-OVR へは http で渡しているのか" は常に要確認。これで WS2022 移行で見るべき Schannel 設定の意味が変わる。

| パターン | TLS 終端位置 | AP-OVR へは何で届くか | WS2022 移行で考慮すべきもの |
| --- | --- | --- | --- |
| **A. エンドツーエンドで AP-OVR まで HTTPS** | AP-OVR 本体（IIS） | https:443 | **WS2022 の Schannel 設定が直接効く**。本ページの§1-1 そのまま |
| **B. LB/WAF/CDN で TLS 終端し、裏側は HTTP** | LB/WAF/CDN | http:80（イントラ LAN） | **AP-OVR 側の Schannel は無関係**。LB 側の TLS 設定がボトルネック |
| **C. 両方に TLS をかけている（二重暗号化）** | LB と AP-OVR 両方 | https:443 | 両方の TLS 設定を揃える |

<aside>
🔎

**見分け方:**

1. AP-OVR 上で `netsh http show sslcert` を実行 → **出力したら AP-OVR 本体で TLS 終端（パターン A or C）**、出力が空だと → AP-OVR より手前で TLS 終端（パターン B）
2. 海外公開ホスト名に外部から `openssl s_client -connect <公開 FQDN>:443` を実行 → 返ってくるサーバ証明書の Subject を見て、AP-OVR に設定された証明書と一致したらエンドツーエンド TLS、違うなら途中の LB/CDN 証明書。
</aside>

### 9-6. 海外クライアント側の調査ポイント

WS2022 の TLS 厳格化によって接続不能になるクライアント側要件:

| 要素 | 要件（WS2022 で接続可能とするため） | 棚卸し方法 |
| --- | --- | --- |
| クライアント OS | Windows 10 1709+ / Windows 11（TLS 1.2 サポート） | 海外拠点 PC の OS 棚卸し |
| .NET Framework | **4.7.2 以上推奨**（4.6 でも ***\\*`SchUseStrongCrypto`***  • 設定で可） | 各 PC のコントロールパネル > プログラムと機能 |
| クライアントレジストリ | `SchUseStrongCrypto = 1` or `SystemDefaultTlsVersions = 1` | GPO / キッティングスクリプトで一括設定 |
| 途中のプロキシ | 海外拠点のフォワードプロキシやセキュリティゲートウェイが古い TLS を強制していないか | 現地 IT 担当にヒアリング |
| クライアント証明書要求 | `sslFlags="SslRequireCert"` ならクライアント証明書の配布状況 | 証明書ストアと GPO |

#### 全クライアント一括棚卸しスクリプト（ログオンスクリプト等で配布して収集）

```powershell
# 1行で OS / .NET FW / TLS レジストリを取得してファイル出力
$out = [pscustomobject]@{
    PC               = $env:COMPUTERNAME
    User             = $env:USERNAME
    OS               = (Get-CimInstance Win32_OperatingSystem).Caption
    OSBuild          = (Get-CimInstance Win32_OperatingSystem).BuildNumber
    NetFw            = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -ErrorAction SilentlyContinue).Release
    SchUseStrong64   = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319' -Name SchUseStrongCrypto -ErrorAction SilentlyContinue).SchUseStrongCrypto
    SchUseStrong32   = (Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319' -Name SchUseStrongCrypto -ErrorAction SilentlyContinue).SchUseStrongCrypto
    SysDefaultTls64  = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319' -Name SystemDefaultTlsVersions -ErrorAction SilentlyContinue).SystemDefaultTlsVersions
    Tls12ClientEnabled = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -ErrorAction SilentlyContinue).Enabled
}
$out | Export-Csv -Path "\\fileserver\share\tls-survey\$($env:COMPUTERNAME).csv" `
    -NoTypeInformation -Encoding UTF8 -Append
```

.NET Framework の Release 番号 → バージョン対応表:

| Release 値 | .NET FW バージョン | TLS 1.2 既定接続可否 |
| --- | --- | --- |
| 378389 / 378675 / 378758 | 4.5 / 4.5.1 | 不可（明示設定必須） |
| 379893 | 4.5.2 | 不可（同上） |
| 393295 ~ 394806 | 4.6 ~ 4.6.2 | レジストリで `SchUseStrongCrypto = 1` 推奨 |
| 460798 ~ 461814 | 4.7 ~ 4.7.2 | 可（OS 既定に従う） |
| 528040 ~ 533320 | 4.8 / 4.8.1 | 可 |

### 9-7. AP-OVR 手前に LB/WAF/CDN がある場合の考慮

海外インターネット公開では LB/WAF/CDN が介在することが多い。その場合 **TLS 設定は以下3層で調査対象**:

| 層 | 確認項目 | 調査方法 |
| --- | --- | --- |
| **インターネット → LB/WAF/CDN** | 海外クライアントから見える TLS バージョン・Cipher Suite | 外部から `openssl s_client -connect <公開 FQDN>:443` を順番に試す |
| **LB/WAF/CDN → AP-OVR** | イントラ LAN 側のプロトコル（http or https）、SNI 設定 | LB の設定画面 / AP-OVR で `Get-NetTCPConnection -LocalPort 80,443` と `appcmd list site` |
| **AP-OVR 本体** | Schannel レジストリ、IIS Crypto 設定 | §8-4 のスクリプト |

<aside>
⚠️

**LB/CDN 介在時の落とし穴:**
**LB をパススルーしている場合 → WS2022 の Schannel より LB 側の TLS 終端能力がボトルネック**になる。よって「AP-OVR を WS2022 にしても LB が TLS 1.0 を受けていたら古いクライアントも接続できてしまう」という逆パターンもある。セキュリティ上**LB 側も合わせて TLS 1.2+ に揃える**べき。

</aside>

### 9-8. 本件による §5 チェックリストへの追加項目

#### 【AP-DOM（国内専用サーバ）】

- [ ]  **バインディングが http:80 のみであることを `appcmd list site` で物証化**
- [ ]  **`netsh http show sslcert` 出力が空であること確認**（TLS 終端不在の証拠）
- [ ]  **WCF エンドポイントが `security mode="None"` であること確認**
- [ ]  役割一覧の diff 移植・WCF Activation 明示・aspnet_regiis 再登録（§1-2 / §1-3）
- [ ]  クライアント接続先 IP/FQDN・DNS エントリの切り替え手順
- [ ]  VPN 装置側のサポート期限・暗号プロトコル棚卸し（別軸の業務として）

#### 【AP-OVR（海外専用サーバ）】

- [ ]  **バインディングが https:443 のみであることを `appcmd list site` で物証化**
- [ ]  **`netsh http show sslcert` 出力で TLS 終端位置を判定**（パターン A/B/C：§9-5）
- [ ]  中間 LB/WAF/CDN 装置の有無と TLS 終端位置をインフラ担当にヒアリング
- [ ]  **サーバ証明書の有効期限と SAN/SNI 設定**
- [ ]  WCF エンドポイントが `security mode="Transport"` または `TransportWithMessageCredential` であること確認
- [ ]  WS2022 移行後の Schannel 設定（TLS 1.0/1.1 明示無効化、TLS 1.2/1.3 有効化）
- [ ]  HSTS 設定の現状確認・移行後の保持

#### 【クライアント側】

- [ ]  国内クライアントと海外クライアントで `app.config` のエンドポイント URL をどう切り替えているか（拠点判定・起動オプション・設定ファイル差し替え等）
- [ ]  **海外拠点 PC のみ**、OS / .NET Framework / Schannel レジストリ棚卸し（§9-6 のスクリプトで一括収集）
- [ ]  **海外拠点 PC のみ**、GPO で `SchUseStrongCrypto = 1` / `SystemDefaultTlsVersions = 1` を実施済か
- [ ]  クライアントコードで `ServicePointManager.SecurityProtocol` を明示しているか grep（§1-1）。**コードは両クライアント共用のはずなので、対応すれば両方に効く（国内では意味を持たず、海外で効果発揮）**

### 9-9. 推奨アクション（本構成スペシフィック）

#### ステップ 1: AP-DOM を先行パイロットとして WS2022 化

- TLS リスクゼロの状態で IIS・WCF・役割サービス・.NET FW ターゲットパックの移植手順を確立
- aspnet_regiis / ServiceModelReg / WCF Activation の手順をスクリプト化
- 許容ダウンタイムも国内サーバの方が広いケースが多くリスク低

#### ステップ 2: AP-OVR 移行の PoC をクローズドで実施

- WS2022 + TLS 1.2 限定の評価 IIS サーバを仮で立てる
- 代表的な海外拠点 PC（古いスペックと新しいスペック両方）から実接続してログで確認
- LB/WAF 介在しているなら PoC にも同様の中継点を組み込む

#### ステップ 3: 海外クライアントの「TLS 1.2 上げ」を現行 WS2019 のうちに完了

- 海外拠点 PC に GPO で `SchUseStrongCrypto = 1` / `SystemDefaultTlsVersions = 1` を適用
- 要件を満たさない古い PC はキッティングスケジュールに乗せる
- これにより AP-OVR を WS2022 に上げたときの事実上のリスクをゼロ化

#### ステップ 4: AP-OVR を本番移行

- AP-DOM で確立した手順 + TLS 1.2 限定設定を適用
- LB/WAF 介在している場合は LB 側も合わせて TLS 1.2+ に揃える

#### その他

- **VPN トンネルとアプリ層 TLS を混同しない**ようドキュメントに明記。「VPN で暗号されている」はアプリ層 TLS 要件を満たさない。ただし社内ローカルトラストポリシーとしては VPN トンネルの暗号を根拠とする余地はある。
- **作業見積もり:** AP-DOM 1 人日、AP-OVR 2〜3 人日（TLS 検証・LB 調整含む）と**サーバごとに独立して見積可能**。

---

## 7. 参考リンク

- [Internet Information Services (IIS) Lifecycle (Microsoft Learn)](https://learn.microsoft.com/en-us/lifecycle/products/internet-information-services-iis)
- [Internet Information Services (Wikipedia)](https://en.wikipedia.org/wiki/Internet_Information_Services)
- [What's new in Windows Server 2022](https://learn.microsoft.com/en-us/windows-server/get-started/whats-new-in-windows-server-2022)
- [What's new in Windows Server 2025](https://learn.microsoft.com/en-us/windows-server/get-started/whats-new-windows-server-2025)
- [Features removed or no longer developed in Windows Server](https://learn.microsoft.com/en-us/windows-server/get-started/removed-deprecated-features-windows-server)
- [New Features Introduced in IIS 10.0, version 1809](https://learn.microsoft.com/en-us/iis/get-started/whats-new-in-iis-10-version-1809/new-features-introduced-in-iis-10-1809)
- [Enabling HTTP/3 support on Windows Server 2022 (Tech Community)](https://techcommunity.microsoft.com/blog/networkingblog/enabling-http3-support-on-windows-server-2022/2676880)
- [TLS Cipher Suites in Windows Server 2022 (Microsoft Learn)](https://learn.microsoft.com/en-us/windows/win32/secauthn/tls-cipher-suites-in-windows-server-2022)
- [SO: IIS 10.0 issues while upgrade from Win 2013 to WS2022](https://stackoverflow.com/questions/76790329/iis-10-0-issues-while-upgrade-from-wind-2013-to-windows-server-2022)
- [MS Q&A: We have a .NET 4.8 WCF application on WS2022](https://learn.microsoft.com/en-us/answers/questions/2193206/we-have-a-net-4-8-wcf-application-on-windows-serve)
- [MS Q&A: Windows Server 2022 support IIS Version](https://learn.microsoft.com/en-us/answers/questions/298770/windows-server-2022-support-iis-version)
- [Trusted Tech Team: WS2019 vs 2022 vs 2025 (2026)](https://www.trustedtechteam.com/blogs/windows-server/compare-windows-server-2019-2022-2025)