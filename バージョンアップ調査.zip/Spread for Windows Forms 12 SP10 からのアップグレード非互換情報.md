# Spread for Windows Forms 12 SP10 からのアップグレード非互換情報

<aside>
📌

**対象:** 現行 **Spread for Windows Forms 12.0 (SP10)** から v13 / v14 / v15 / v16 / v17 / v18 / v19 への移行
**前提:** ソースは原則無修正。必要な場合のみ参照アセンブリ差し替え／Designer 再生成／Binding Redirect で対応。Visual Studio バージョンとの組合せ制約も併記。
**関連ページ:** [VS2017からのアップグレード非互換情報（VS2019 / VS2022 / VS2026）](https://www.notion.so/VS2017-VS2019-VS2022-VS2026-4cbceffed22c499ea7ef7f328cc0b9d8?pvs=21)(VS本体の非互換) と必ずセットで読むこと。

</aside>

## 0. 現行構成と移行方針の早見表

| 移行先 Spread | 使える VS | 必要な .NET FW | 本件適用可否 |
| --- | --- | --- | --- |
| **v13** (2019) | VS2017 / VS2019 | 4.5.2+ | ○ 中継点として可 |
| **v14** (2020) | VS2017 / VS2019 | 4.5.2+ / .NET 5 / Core 3.1 | ○ |
| **v15** (2021) | VS2019 中心 (**VS2022 非対応**) | 4.5.2+ | △ VS2022 へ進むなら採用しない |
| **v16** (2022/11) | VS2019 / **VS2022** | 4.6.2+ / .NET 6 | ○ VS2022 移行の最低ライン |
| **v17** (2023〜2024) | VS2019 / VS2022 | 4.6.2+ / .NET 6 / 7 / 8 | ○ Breaking Changes あり (§3) |
| **v18** (2024/09) | VS2022 | 4.6.2+ / .NET 6 / 7 / 8 | ○ |
| **v19** (2026/01) ※最新 | VS2022 / **VS2026** | 4.6.2+ / .NET 6 / 8 / 9 | ◎ 最終目標 |

<aside>
💡

**結論先出し:** ① VS2017 維持で Spread だけ上げるなら **v13 / v14** が現実解。② **VS2022 へ移行するなら Spread は v16 以上**が必須（v15 は VS2022 で動かない）。③ **VS2026 を視野に入れるなら最終的に v19 まで上げる**のが安全。

</aside>

---

## 0-1. 現行構成の前提（コードビルド方式）

<aside>
🔧

**本件の特殊事情:** VS のフォームデザイナで `FpSpread` をフォーム上に**配置するだけ**にとどめ、列幅・CellType・内容設定などは **`.vb` 側のコード（`Form_Load` や独自 Setup メソッド）で動的に組み立てている**。Spread Designer（スタンドアロンの Spread 設定ツール）は**使用していない**前提。

</aside>

### 0-1-1. このスタイルのアップグレード上のメリット

| 観点 | Designer 方式 | **コードビルド方式（本件）** |
| --- | --- | --- |
| メジャー跨ぎでの `Form.Designer.vb` 自動書換え | あり（差分が膨大） | **ほぼ無し** |
| resx のバイナリ blob 互換問題 | あり | **無し** |
| 影響範囲の grep | 困難 | **容易**（API 名で検索可） |
| 規定値変更（v17 のヘッダ WrapText 等）の影響 | デザイナで固定値書込み済 → 影響小 | **影響あり**（規定値依存のコードは要確認） |

### 0-1-2. このスタイル特有の v17 注意ポイント（3パターン）

コードビルド方式で v17 アップ時に唯一刺さりやすいのは次の3つ。**該当が0件なら v17 への影響は事実上ゼロ**。

1. **`ColumnHeaderRenderer.WordWrap` を使った折返し制御**: v17 で無効化。`Cells.WrapText` への書替えが必要になる可能性。
2. **複数シート選択 → ループでセル操作するコード**: v17 で「全シートで同一セルがアクティブ」になるため、`Sheets(i).ActiveCell` 前提のロジックは挙動が変わる可能性。
3. **`ColumnHeaderRenderer` / `RowHeaderRenderer` のカスタムレンダラ**: 規定値変更で見た目が変わる。

### 0-1-3. 棚卸し用 grep（PowerShell）

事前に該当箇所を機械的に拾っておくと、影響範囲が確定して工数見積もり精度が上がる。

```powershell
# 列幅・行高
Select-String -Path *.vb -Pattern "\.Columns\(.+\)\.Width"
Select-String -Path *.vb -Pattern "\.Rows\(.+\)\.Height"

# CellType の生成
Select-String -Path *.vb -Pattern "New FarPoint\.Win\.Spread\.CellType\."

# ヘッダ折返し制御（v17 で規定値変更）⚠️最重要
Select-String -Path *.vb -Pattern "ColumnHeaderRenderer|WordWrap|WrapText"

# 複数シート選択・アクティブセル操作（v17 で挙動変化）⚠️
Select-String -Path *.vb -Pattern "ActiveSheetIndex|SetActiveCell|Sheets\(.+\)\.Active"

# データバインド
Select-String -Path *.vb -Pattern "\.DataSource\s*="

# 印刷・PDF（v18 で挙動変化）
Select-String -Path *.vb -Pattern "\.PrintInfo|\.PrintSheet|SavePdf|ExportPdf"

# Excel I/O
Select-String -Path *.vb -Pattern "OpenExcel|SaveExcel"
```

### 0-1-4. 工数感（コードビルド方式での想定）

| 作業 | 工数目安 |
| --- | --- |
| `*.vbproj` の参照差し替え（NuGet 化推奨） | 1プロジェクトあたり 5〜10分 |
| `licenses.licx` のバージョン文字列更新 | 全プロジェクト一括置換で完了 |
| `Form.Designer.vb` の `FpSpread1.New` 周辺の差分確認 | 画面あたり 5分 |
| **`*.vb` 側のセットアップコードのリグレッション** | **画面あたり 15〜30分（v17 の3パターンを目視＋実機確認）** |
| 印刷・PDF 出力の比較テスト（v18 に上げるとき） | 帳票数 × 5〜10分 |

<aside>
✅

Designer 方式の現場だと「`Form.Designer.vb` の自動再生成差分レビュー」だけで画面あたり1時間以上かかることもあるが、**本件のコードビルド方式は工数的に有利**。v17 の3パターンに該当する画面を**先行リグレッション対象**として抽出し、その他は smoke test（起動・主要操作）だけで割り切るのが現実的。

</aside>

---

## 1. 大前提：Spread の互換性レベル

### 1-1. アセンブリ・ファイルバージョンと Publisher Policy

- 現行 Spread 12 のアセンブリは `FarPoint.Win.Spread.dll` ほか。**バージョン番号がメジャーに連動**するため、12→13 以降は**強名アセンブリの参照差し替え**が必要（VS の参照を張り替えるかインストーラーで GAC 配置）。
- インストーラーでセットアップした場合、**Publisher Policy DLL** が GAC に入って旧バージョン参照を新バージョンへリダイレクトする仕組みは Spread 9 以降一貫しているが、**メジャー跨ぎでは効かない**（v9→v9.x など同メジャー系内のみ）。12→13 以降は **app.config の `<bindingRedirect>` か参照張替えが必要**。
- v14 以降は **NuGet パッケージ `GrapeCity.Spread.WinForms`** が公式提供されている（v14 から登場）。NuGet 化はしなくても良いが、**NuGet 化しておくと VS バージョンを変えても再セットアップが楽**になるため、移行と同時に NuGet 化しておくことを推奨。

### 1-2. ライセンスファイル (`licenses.licx`)

- 現行プロジェクトに `licenses.licx` があり、`FarPoint.Win.Spread.FpSpread, FarPoint.Win.Spread, Version=12.0.xxxx.x, ...` と固定バージョンが書かれているはず。
- **メジャーアップグレード時は `licenses.licx` を必ず編集**（または削除して Designer から再生成）する必要がある。VS のバージョンに関係なく必要な作業。

### 1-3. Designer (デザイナ) 連携

- Spread は **VS のフォームデザイナ上で `FpSpread` をドロップ→プロパティを設定→`InitializeComponent` に反映** という昔ながらのコード生成方式。
- メジャー跨ぎで**型のフルネームは変わらない**（`FarPoint.Win.Spread.FpSpread`）が、**プロパティ追加・廃止・規定値変更**が随所であり、Designer で開いた瞬間に `Resources.resx` / `Form.Designer.vb` が書き換わる。VS バージョンを上げる前に **Spread だけ先に上げて差分をコミット**しておくと事故が減る。

---

## 2. バージョン別の主な変更点（v12 SP10 → 各バージョン）

### 2-1. v12 → v13 (2019リリース)

- 主要変更:
    - 強化された Rich Copy / Paste（クリップボード経由で Excel と書式まで受け渡し）
    - **Slicers**（テーブルスライサ）追加。
    - バグ修正系（CellChanged 発火条件、列追加可否、TEXT 関数のカルチャ依存修正など）
- 非互換リスク:
    - 公式 Breaking Changes ドキュメントに **v13 単独の破壊的変更はほぼ記載なし**（軽微）。
    - ただし **"SP6 → SP13 が無修正で移行できる" と明言**されているのは v13 のリリースノート上のみで、**SP10 (v12) → v13** は**通常はコード無修正で動くがアセンブリ参照差し替えは必須**。
- VS との関係: **VS2017 / VS2019 で動作**。VS2022 はサポート対象外（v13 は VS2022 リリース前）。

### 2-2. v13 → v14 (2020-12)

- 主要変更:
    - **NuGet パッケージ `GrapeCity.Spread.WinForms` を初提供**。
    - **.NET 5 / .NET Core 3.1 用 WinForms コントロール**初対応（ただし当時はデザインタイム制限あり）。
    - 凍結行/列の表示制御（`FrozenTrailingStickToEdge`、`FrozenLineColor`）、`PasteSkipInvisibleRange`、`ShowOutline` 追加。
- 非互換リスク: 軽微。プロパティ追加が中心。
- VS との関係: VS2017 / VS2019 対応。

### 2-3. v14 → v15 (2021)

- 主要変更: 機能追加中心（PivotTable 強化、Charts、Designer UI）
- 非互換リスク: 中程度（Excel 互換挙動の調整あり）
- VS との関係: ⚠️ **VS2022 では正常に動作しない**（公式フォーラムで "v15 is not supported in VS 2022" と明言、Designer エラー報告多数）。**VS2022 移行を検討するなら v15 は採用しない**。

### 2-4. v15 → v16 (2022-11)

- 主要変更:
    - **Rich Text Editing**, **新組込関数 19 個**, **Worksheet Protection ダイアログ**, **Forecast Sheet / Goal Seek / DataTable / Text-to-Columns / Remove Duplicates ダイアログ**, **Form Controls 対応**, **Shapes の 3D 回転**, **Sheet を画像で保存**。
- 非互換リスク: 中（プロテクション周りの規定値変更、新ダイアログ表示位置、Form Controls 追加に伴う `IShape` 階層の整理）
- VS との関係:
    - **VS2022 が正式サポート対象になった最初のメジャー**（NuGet パッケージが .NET 6 と .NET FW 4.6.2 を併記）
    - ⚠️ **必要 .NET Framework が 4.5.2 → 4.6.2 に引き上げ**。VS2017 で 4.6.2 をターゲットにするには **.NET 4.6.2 Targeting Pack** が必要。
    - ⚠️ **VS2022 のツールボックス（VS 標準のコントロール一覧パネル）で FpSpread が グレーアウト する事象が複数報告**（Microsoft Q&A 2025-05、Spread v16.2 / v18.1 で再現）。詳細と影響、回避策は §3-1〜3-3 参照。

### 2-5. v16 → v17 (2023〜2024) — ⚠️ Breaking Changes あり

- 公式 Breaking Changes (`17.0.20231.0`):
    - **アクティブセルの一貫性**: 複数シート選択時に**全シートで同一セルが選択状態**になる（Excel 互換）。v16 までは違うセルだった。**自動計算・印刷範囲・選択状態に依存するロジックは要検証**。
    - **Column Header / Footer の WrapText**: `Cells.WrapText` が有効化、**`ColumnHeaderRenderer.WordWrap` プロパティは無効**になる（`WordWrap2 = null` の時のみ `WrapText` が効く）。**ヘッダ折返しを制御している画面は規定値変更で見た目が変わる**。
    - 規定で**Office 365 既定テーマ**に変更（旧バージョン互換のため、既存 Workbook には影響しない）
- v17.1 (2024-04): 画像セル機能、Group Footer の Column Style 追加など。
- v17.2 (2024-09): **GDI Text Rendering の On/Off** (`TextHelper.UseGDITextRendering`)。GDI レンダリング起因の文字描画ずれの回避策。
- VS との関係: VS2019 / VS2022 対応。.NET FW 4.6.2+ / .NET 6 / 7 / 8。

### 2-6. v17 → v18 (2024-09)

- 主要変更:
    - **PDF Export** （Sheet/Workbook を高解像度 PDF 化、Excel 互換印刷、リッチテキスト・透明シェイプ対応）
    - 印刷機能強化（ヘッダ/フッタ画像、Flat Style）
- 非互換リスク: 軽微〜中。印刷・PDF 出力の見た目が変わる可能性あり、業務帳票で利用している場合は**印刷物の比較テスト必須**。
- VS との関係: VS2022 中心。

### 2-7. v18 → v19 (2026-01) ※最新

- 主要変更:
    - **Pivot Table エンジン**（WinForms/WPF 両方）
    - **Formula Auto Indent**（複数行式の整形）
    - **行・列の Pin（スクロール中も固定）**
    - **TRIMRANGE / REGEX 系の新計算関数**
    - **Chart エンジン拡張**（データテーブル、ラベル方向、滑らか曲線）
    - **Sheet タブのアイコン・ホバー色・保護色カスタマイズ**
- 非互換リスク: 公開 Breaking Changes は限定的（リリースノート参照）。**新 Pivot エンジンを使わなければ既存コード影響は小**。
- VS との関係: **VS2022 / VS2026** で動作。NuGet パッケージは .NET FW 4.6.2 と .NET 6 を targets として宣言、実利用は .NET 6/8/9 まで OK。

---

## 3. Visual Studio バージョンとの組合せ制約

| Spread  VS | VS2017 | VS2019 | VS2022 | VS2026 |
| --- | --- | --- | --- | --- |
| v12 SP10 | ○ 現行 | △ 動くが非推奨 | ✕ Designer NG | ✕ |
| v13 / v14 | ○ | ○ | ✕ | ✕ |
| v15 | △ | ○ | ✕ 非対応 (公式) | ✕ |
| v16 | ✕ FW 4.6.2 必須 | ○ | ○ (VS Toolbox 要注意 §3-1) | △ |
| v17 / v18 | ✕ | ○ | ○ | △ |
| v19 | ✕ | ✕ | ◎ | ◎ |

<aside>
⚠️

**重要な落とし穴: VS2022 + Spread の VS Toolbox 問題**
※ ここで言う「Toolbox」は **VS 標準のツールボックス**（VS 左側に出るコントロール一覧パネル）を指す。**Spread Designer（独立ツール）とは別物**で、Spread Designer は使っていないためそちらは無関係。

</aside>

### 3-1. 報告されている具体的事象

- **事象 A: FpSpread のグレーアウト**（Microsoft Q&A 2025-05、Spread v16.2 / v18.1 + VS2022 + .NET 8 で再現）
    - VS2022 のツールボックスに「GrapeCity Spread」タブは表示される
    - 「すべて表示」をオンにすると `FpSpread` アイコンは見えるが、**深色・有効にならずドラッグ不可**
    - **実害: 新規フォームに FpSpread を貼れない**→ 新規機能追加で Spread を使う画面を作る際に直撃する
- **事象 B: アウトプロセス WinForms Designer がフォームを開けない**（Stack Overflow 79213035 / Microsoft Q&A 2150044、VS2022 17.12 系で多発）
    - Spread を貼った既存フォームを開くと「The designer could not be shown for this file because none of the classes within it can be designed」
    - VS2022 17.12 の WinForms Designer 不具合が大半。**17.11 へダウングレード** または **bin / obj / .vs フォルダ削除**で改善する事例多数
- **事象 C: 32bit 依存コンポーネント混在時のクラッシュ**
    - VS2022 は 64bit プロセス、WinForms Designer も同じプロセス内で動くため、**Spread 以外の 32bit COM/ActiveX** が同フォームに貼られているとデザイナがクラッシュ
    - ※ 本件の環境では 32bit 専用部品は無いため**該当なし**（[VS2017からのアップグレード非互換情報（VS2019 / VS2022 / VS2026）](https://www.notion.so/VS2017-VS2019-VS2022-VS2026-4cbceffed22c499ea7ef7f328cc0b9d8?pvs=21) §0-1 参照）

### 3-2. 新規機能追加への実害

| シナリオ | 実害 | 側面 |
| --- | --- | --- |
| 既存フォームの修正 | 実害なし | FpSpread は既に貼られているため Toolbox 不要。デザイナで開ければプロパティ編集可。 |
| **新規フォームの作成** | **直撃** | VS Toolbox から FpSpread をドロップできないとフォームに載せられない。**新規機能追加が止まる**ため、回避策の事前導入が必須。 |
| 既存フォームへの Spread 追加貼付 | 中 | Toolbox ドロップ不可の場合、コードビハインド記述または他フォームからのコピペで代替。 |

<aside>
🚨

**よって VS2022 へ移行する際は、§3-3 の回避策を必ず事前に検証・手順化しておくこと**。さもないと「移行たんに新規画面作成ができない」という状態に陥る。

</aside>

### 3-3. 回避策（優先順）

1. **VS の Toolbox キャッシュをリセット**（最初に試す・無償）
    - VS を閉じる
    - `%LOCALAPPDATA%\Microsoft\VisualStudio\17.0_xxxxxxxx\` 配下の `toolbox.tbd` / `toolbox_reset.tbd` / `toolboxIndex.tbd` / `toolboxIndex_reset.tbd` を削除
    - VS を起動 → ツールボックスが自動再構築される
    - これで直る事例が多い（Stack Overflow 73402437で 102 votes の公式回答）
2. **NuGet 参照への統一**
    - `GrapeCity.Spread.WinForms` を `<PackageReference>` で参照すると Toolbox 認識が安定するとの報告あり
    - インストーラ経由の GAC 配置から切り替え
3. **既存フォームの複製をテンプレート化**
    - 新規フォームを 0 から作らず、Spread を貼った既存フォームを「ベーステンプレート」としてコピーし、不要要素を削除する運用に切り替え
4. **コードビハインド配置**
    - `New FarPoint.Win.Spread.FpSpread()` を `Form_Load` またはコンストラクタで生成し `Me.Controls.Add(...)`
    - **コードビルド方式（§0-1）と相性が良い**ため、新規画面はこの方式を標準にしてもよい
5. **VS2022 のバージョン固定**
    - 17.12 系で不具合が多発。**VS2022 17.11 LTSC** または **17.14 LTSC** を使い、自動アップデートを停止する運用も選択肢

### 3-4. メジャー跨ぎ時の Form.Designer.vb 再生成

- Spread のメジャー跨ぎ（v12 → v16/17 など）で VS の Form Designer が `Form.Designer.vb` を**自動再生成**するタイミングが発生。
- **Spread を上げる前に必ず Git commit** し、再生成後の差分を**個別レビュー**できる状態にしておく。
- 本件のコードビルド方式（§0-1）であれば `Form.Designer.vb` 側の差分は最小限なので、レビュー負荷は低い想定。

### 3-5. v17 Breaking Changes の詳細（公式 17.0.20231.0）

#### 【変更1】アクティブセルの一貫性（Consistent Active Cell Across Sheets）

**変更前（v16 以前）**: シートごとに独立したアクティブセルを保持。Sheet1 で C5 を選択して Sheet2 に切替えると、Sheet2 のアクティブセルは前回の A1 のまま。

**変更後（v17 以降）**: 複数シート選択時に**全シートで同じセルがアクティブ**になる（Excel 互換）。

| ケース | v16 までの挙動 | v17 以降の挙動 |
| --- | --- | --- |
| 複数シート選択 → `Sheets(i).ActiveCell` で参照 | シートごとに違うセル | **全シート同じセル** |
| `SheetView.SetActiveCell(row, col)` を別シートで呼ぶ | そのシートだけアクティブ移動 | 選択中シート群全部に伝播する可能性 |
| 印刷範囲を「アクティブセル基準」で決めるロジック | シートごと別範囲 | **全シート同じ範囲**で想定外の出力 |
| マクロ的処理でループ回しながらシート切替＋編集 | 元の位置に戻れる | 編集位置が同期されて期待と違う動作 |

**要チェックなコード例**:

```vbnet
' これがあると挙動変化の可能性大
For i = 0 To FpSpread1.Sheets.Count - 1
    Dim cell = FpSpread1.Sheets(i).ActiveCell
    ...  ' cell.Row や cell.Column を使った処理
Next

' 複数シート選択前提のコードも要注意
FpSpread1.Sheets(0).Selected = True
FpSpread1.Sheets(1).Selected = True
FpSpread1.Sheets(0).SetActiveCell(5, 3, False)  ' v17以降は両シートに伝播
```

**検出 grep**:

```powershell
Select-String -Path *.vb -Pattern "ActiveCell|SetActiveCell|Sheets\(.+\)\.Selected"
```

#### 【変更2】ヘッダ／フッタの WrapText（Customizable WrapText）

**変更前（v16 以前）**: ヘッダ・フッタの折返し制御は **`ColumnHeaderRenderer.WordWrap`** で行う。`True`なら長文を折返し、`False`なら1行表示。

**変更後（v17 以降）**: 一般セルと同じ **`Cells.WrapText`** で制御。`ColumnHeaderRenderer.WordWrap` は**無効化**（`SpreadSkin.ColumnHeaderRenderer.WordWrap2` が `null` のときだけ `WrapText` が効く条件付き）。規定値: **1行目・1列目のヘッダは `WrapText = True`**、それ以外（多段ヘッダの2行目以降等）は `False`。

| ヘッダ構成 | v16 までの見た目 | v17 以降の見た目 |
| --- | --- | --- |
| 単一行ヘッダ・`WordWrap = False` で折返し抑止 | 折返しなし（1行） | 規定で `WrapText = True` → 折返して**ヘッダ高さが膨らむ** |
| 単一行ヘッダ・`WordWrap = True` で折返し | 折返しあり | `WrapText = True` で同じ動き（実害なし） |
| 多段ヘッダ（2段・3段ヘッダ） | `WordWrap` で全行制御 | **2行目以降は `WrapText = False` 規定** → 折返ずに列幅で**切れる可能** |
| カスタム `ColumnHeaderRenderer` 継承で `WordWrap` をオーバーライド | カスタム挙動が効く | **オーバーライドが無視**される（`WordWrap2 = null` 明示が必要） |

**要チェックなコード例**:

```vbnet
' v16 まで: これでヘッダ折返しを抑止していた
FpSpread1.Sheets(0).ColumnHeader.DefaultStyle.Renderer = _
    New FarPoint.Win.Spread.CellType.ColumnHeaderRenderer() With { _
        .WordWrap = False _
    }
' → v17 以降は無視されてヘッダが折返してしまう

' v17 以降での修正方法
FpSpread1.Sheets(0).ColumnHeader.Cells(0, -1).WrapText = False  ' Cell 単位
' または
FpSpread1.Sheets(0).ColumnHeader.Rows(0).WrapText = False  ' 行単位
```

**検出 grep**:

```powershell
Select-String -Path *.vb -Pattern "ColumnHeaderRenderer|RowHeaderRenderer|WordWrap|\.Cells\(.+\)\.WrapText"
Select-String -Path *.vb -Pattern "ColumnHeader\.RowCount|RowHeader\.ColumnCount"
```

#### 【変更3】規定テーマを Office 365 (2023) に変更

- **既存 Workbook を開き直しても見た目は変わらない**（後方互換保証）
- **新規作成時のヘッダ色・罫線色などの規定値が変わる**ため、新規画面と既存画面を並べたときに**配色が揃わない可能性**あり

#### コードビルド方式での実害見積もり

| 観点 | 影響度 | 確認方法 |
| --- | --- | --- |
| `ActiveCell` を複数シートにまたがって扱うコード | **要 grep** → 該当 0 件なら影響なし | 上記 grep |
| `ColumnHeaderRenderer.WordWrap` を使ったヘッダ折返し制御 | **要 grep** → 該当 0 件なら影響なし | 上記 grep |
| カスタム `ColumnHeaderRenderer` 継承 | **要目視** | IDE のクラス継承検索 |
| 規定テーマ変更 | 新規追加画面のみ影響、既存画面は不変 | 移行後の見た目比較 |

<aside>
✅

**現行コードを grep して該当 0 件なら、v17 アップでの実害はなしと判定できる**。該当があった場合は、上の修正コード例に沿って書替えれば対応完了。本件のコードビルド方式（§0-1）は Designer に規定値が高度に椟め込まれたコードよりも影響範囲を掴みやすい。

</aside>

---

## 4. 推奨アップグレードパス

### 4-1. ライセンス方針（移行案共通）

<aside>
🔑

**結論: [Spread.NET](http://Spread.NET) v19 ライセンス1本で足りる**。v14 / v16 / v17 を別々に購入する必要はない。中間バージョンが必要な場合は新規ライセンス購入時に提供元へ依頼する公式運用がある。

</aside>

#### [Spread.NET](http://Spread.NET) ライセンスの仕組み

- **永続ライセンス + 1 年保守（Annual Maintenance & Support）** が基本セット
    - 保守期間中はメジャーリリース＋全 SP/メンテナンスビルドにアクセス可
    - 保守切れ後も購入時バージョンは永続使用可、ただし新バージョンは取得不可
- 最近導入された **Annual Subscription** モデル: 契約期間中の全アップデートにアクセス可
- **メジャー跨ぎでは新規ライセンスまたはアップグレードライセンスが必要**（v12 のライセンスで v13 以降は使えない）
- ビルドマシン用にも**別ライセンスが必要**（製品 EULA 規定）

#### 旧バージョン提供サービス（重要）

- メシウス（旧 GrapeCity）は**直販では旧バージョンを販売していない**が、**新規ライセンス購入者には必要な旧バージョンのインストーラを提供**する公式運用がある（[ComponentSource](https://www.componentsource.com/product/spread-net/licensing) [Spread.NET](http://Spread.NET) [Licensing FAQ](https://www.componentsource.com/product/spread-net/licensing) 明記）
- 日本ではメシウス直販終了のため、**コンポーネントソース** または **クレバーブリッジ** 経由で取り寄せ（[メシウス公式: 旧バージョン製品の取り扱い](https://developer.mescius.jp/purchase/old-version)）
- ⚠️ 「予告なく完全販売終了する場合あり」のため**早めの問合せ推奨**

#### 上位互換の公式保証

- メシウス公式の[移行情報ページ](https://developer.mescius.jp/spread-winforms/migration)で、**SPREAD for Windows Forms v19.0J は v3 / v5 / v7 / v8 / v10 / v11 / v12 / v15 / v17 との上位互換を保証**、廃止機能なしと明言
- つまり **v12 SP10 → v19 への直行も「動く」と公式保証されている**

#### 推奨ライセンス取得手順

1. [**Spread.NET](http://Spread.NET) v19 新規ライセンス**（または Annual Subscription）を必要本数購入（開発者数＋ビルドマシン分）
2. 購入時に **v14 / v16 / v17 のインストーラ提供を依頼**（移行検証・段階移行用、追加費用なしの想定）
3. 移行ガイド・移行セミナー資料を入手（[SPREAD 移行セミナー Speaker Deck](https://speakerdeck.com/mescius_dev/spread-migration) はメシウスが2024-11に開催したセミナー資料、無償公開）

### 4-2. 段階移行案（リスク最小・検証重視）

```mermaid
flowchart LR
	A["Spread 12 SP10<br>VS2017"] --> B["Spread 14<br>VS2017 / VS2019"]
	B --> C["Spread 16 or 17<br>VS2019 / VS2022"]
	C --> D["Spread 19<br>VS2022 / VS2026"]
```

- **Step1:** VS2017 を維持したまま **Spread 12 → 14** に上げる（NuGet 化込み）。`licenses.licx` 更新と `FarPoint.Win.*` の参照差し替えのみで完了するケースが多い。
- **Step2:** **VS を 2019 (LTSC) または 2022 へ移行**しつつ、Spread を **14 → 16 または 17** へ。v17 の Breaking Changes（§3-5）の影響を確認。※ v15 は VS2022 非対応のためスキップ。
- **Step3:** 最終的に **Spread 19 + VS2022/2026** へ。Pivot エンジン等の新機能は使わなくても既存コードは動く想定。
- **ライセンス**: v19 を 1 本購入し、§4-1 の手順で **v14 / v16 / v17 のインストーラを取り寄せ**て段階的に切替。

### 4-3. 直行案（v12 SP10 → v19 一気通貫）

```mermaid
flowchart LR
	A["Spread 12 SP10<br>VS2017"] --> B["Spread 19<br>VS2022 / VS2026"]
```

- **Step1:** VS2022 / VS2026 + Spread 19 の組合せで新環境を構築。
- **Step2:** v12 プロジェクトを開いて **`FarPoint.Win.*` の参照差替え + `licenses.licx` 更新 + Designer 再保存**。
- **Step3:** v17 Breaking Changes の該当箇所（§3-5 grep 結果）を一括修正。
- **適合条件**: 本件のコードビルド方式（§0-1）であれば**現実的に成立**。Designer に規定値が深く埋め込まれていないため、問題切り分けが容易。32bit 専用部品が無いため VS2022 の 64bit デザイナ問題も該当しない。
- **公式保証**: v19 は v12 との上位互換が公式保証されており、廃止機能なし（§4-1）。
- **ライセンス**: **v19 のみ**で完結。中間バージョンの取り寄せ不要。

### 4-4. 段階移行 vs 直行 比較

| 観点 | 段階移行案（§4-2） | 直行案（§4-3） |
| --- | --- | --- |
| 移行プロジェクト数 | 3 ステップ | **1 ステップ** |
| 必要ライセンス | v19 + 中間版インストーラ取り寄せ | **v19 のみ** |
| 所要期間 | 長い（半年〜1 年） | **短い（数ヶ月）** |
| 問題切り分けやすさ | **容易**（VS / Spread を分離可） | VS と Spread の問題が混在 |
| 本件のコードビルド方式との相性 | ○ | **◎**（Designer 再生成リスクが低い） |
| v17 Breaking Changes 検証 | Step2 で集中検証 | 移行と同時に grep ベースで一括検証 |
| v19 新機能の活用 | Step3 まで使えない | **最初から利用可** |
| VS2022 Toolbox 問題への対応タイミング | Step2 移行時 | 移行時（§3-3 回避策の事前導入で対応） |
| 失敗時のロールバック | **ステップ単位で戻せる** | 全体を戻すしかない |
| テスト工数 | 各ステップで実施（分散） | 移行完了後に集中 |

<aside>
🎯

**本件への推奨: §4-3 直行案**。コードビルド方式（§0-1）で Designer 依存が薄く、32bit 専用部品も無い構成では、段階移行のメリット（問題切り分け容易性）が小さく、**ライセンス1本で短期完結する直行案の利点が上回る**。
**前提条件**: ① v17 Breaking Changes の grep（§3-5）と修正方針の事前確定、② VS2022 Toolbox 問題の回避策（§3-3）の手順化、③ 印刷・PDF 出力の比較テスト準備（v18 の差分対応）。
**段階移行案を選ぶケース**: ライセンス予算が厳しく v19 単体購入が困難な場合、または開発チームを並行運用させて段階的に学習させたい場合。

</aside>

### 4-5. ソース無修正前提で必要になる作業

- 以下は "ソース改修" には数えないが、**プロジェクト構成ファイル**は必ず触る:
    - `*.vbproj` の `<Reference Include="FarPoint.Win.Spread" ...>` の HintPath / Version 書き換え（または NuGet `<PackageReference>` 化）
    - `licenses.licx` のバージョン文字列更新
    - `app.config` への `<bindingRedirect>` 追記（メジャー跨ぎで参照を維持したい場合）
    - `Form.Designer.vb` の自動再生成差分（プロパティ既定値変更分）
- これらは**変換ツール**ではなく、**Spread 公式インストーラ + VS の参照マネージャ + Designer の再保存**で完結する。

---

## 5. 変換ツール／自動移行ツールの有無

- **Spread 専用の自動変換ツールは公式提供なし**。
- Spread 9 時代から「Toolbox から旧 FpSpread を外して新 FpSpread を入れ直す」「インストーラが Publisher Policy を GAC に配置する」という**手動＋インストーラ任せの移行**が前提になっている。
- VS 側の変換は `.vbproj` の SDK 形式化（VS2017 以降の SDK 形式 csproj/vbproj）で受け持つ範囲。**WinForms+[VB.NET](http://VB.NET) の旧形式 vbproj のままでも Spread 19 + VS2022 で動作可能**なので、SDK 形式化は必須ではない。

---

## 6. 既知のリスク・注意事項

- **Spread 17 のアクティブセル一貫性**: 複数シート選択 → 一括処理しているコード（マクロ的な処理、Print 範囲指定など）で挙動が変わる可能性。
- **Spread 17 のヘッダ WrapText 既定値**: ヘッダ多段表示や強制折返しを `ColumnHeaderRenderer.WordWrap` で抑止していた画面は崩れる可能性。
- **Spread 18 の PDF/印刷**: 帳票出力の見た目を比較テスト必須。
- **Spread 19 の Pivot エンジン**: 既存 Pivot を使用していなければ影響なし。新機能のため。
- **デザイナ依存問題（VS 起因）**: VS2022 のアウトプロセス Designer は Spread 配置済みフォームを開けない事象が散発的に報告されている（Stack Overflow 79213035 など）。**Spread 16 以降 + VS2022 17.11 以前** の組合せが最も安定との報告あり。
- **ライセンス証跡**: Spread はメジャー単位の有償ライセンス。**v12 のライセンスで v13 以降は使えない**。MESCIUS（旧 GrapeCity）のサブスクリプション契約状況を確認すること。

---

## 7. まとめ（実行アクション）

1. [**Spread.NET](http://Spread.NET) v19 新規ライセンス（または Annual Subscription）を必要本数購入**し、必要に応じて v14 / v16 / v17 のインストーラ提供をメシウス／コンポーネントソースに依頼（§4-1）。本件のコードビルド方式なら**直行案（v12 → v19、§4-3）が推奨**。
2. **VS のバージョンアップ計画と歩調を合わせる**:
    - VS2017 維持 → Spread 14 まで上げて様子見。
    - VS2022 移行 → **Spread 16 以上必須**（v15 は不可）。
    - VS2026 視野 → 最終的に **Spread 19** へ。
3. **NuGet 化（`GrapeCity.Spread.WinForms`）を移行と同時に実施**。インストーラ依存からの脱却。
4. **Spread 17 の Breaking Changes** に対する画面別の影響確認（複数シート選択、ヘッダ WrapText）。
5. **Spread 18 の PDF/印刷出力比較**。
6. **Designer 再生成差分を Git で管理**。Spread のメジャー跨ぎ前後で必ず分離コミット。
7. **VS2022 Toolbox グレーアウト問題への備え**: NuGet 経由で参照、必要ならコードビハインド配置で回避。
8. **VS バージョンアップとは独立した別プロジェクトとしてスケジュール**するか、**Step1 (Spread 14 + VS2017)** だけ先行実施し、残りを VS 移行プロジェクトに合流させる。

---

## 8. 参考リンク

- [Spread.NET](http://Spread.NET) [Breaking Changes (公式)](https://developer.mescius.com/spreadnet/docs/latest/readme/BreakingChanges)
- [Breaking Changes for Version 17.0.20231.0](https://developer.mescius.com/spreadnet/docs/latest/readme/BreakingChanges/breakingchangesSpWin/breakingchangeswin20231)
- [Spread.NET](http://Spread.NET) [Releases 一覧](https://developer.mescius.com/spreadnet/releases)
- [What's New in](https://developer.mescius.com/spreadnet/releases/spreadnet-19) [Spread.NET](http://Spread.NET) [v19 (2026-01)](https://developer.mescius.com/spreadnet/releases/spreadnet-19)
- [Spread.NET](http://Spread.NET) [v17 Release Highlights](https://developer.mescius.com/spreadnet/releases/spreadnet-17)
- [Spread.NET](http://Spread.NET) [v14 (.NET 5 / NuGet 初対応)](https://developer.mescius.com/spreadnet/releases/spreadnet-14)
- [GrapeCity.Spread.WinForms NuGet (v19.0.2)](https://www.nuget.org/packages/GrapeCity.Spread.WinForms)
- [Spread.NET](http://Spread.NET) [Compatibility (ComponentSource)](https://www.componentsource.com/product/spread-net/compatibilities)
- [VS2022 Toolbox FpSpread グレーアウト問題 (Microsoft Q&A)](https://learn.microsoft.com/en-us/answers/questions/2279957/farpoint-grapecity-spread-net-(v16-2-0-v18-1-0)-to)
- [Spread v15 が VS2022 で動かない件 (公式フォーラム)](https://developer.mescius.com/forums/spread-webforms/asp-net-windows-form-version-15-not-run-with-visual-studio-2022)