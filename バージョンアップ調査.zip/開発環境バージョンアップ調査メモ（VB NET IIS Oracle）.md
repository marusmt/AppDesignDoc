# 開発環境バージョンアップ調査メモ（VB.NET / IIS / Oracle）

<aside>
📌

現行構成（[VB.NET](http://VB.NET) WinForms ＋ IIS（SOAP）＋ Oracle 19c）のサポート切れに伴うバージョンアップ検討用メモ。各ツールの **後継候補・中間バージョン・依存関係** を一次情報ベースで整理。

</aside>

## 現行構成（前提）

- 画面：[VB.NET](http://VB.NET) WinForms アプリケーション
- サーバ：IIS（APサーバ）。クライアント⇔サーバは **SOAP** でやり取り
- DB：Oracle 19c Enterprise Edition (19.3)
- DB接続：[**ODP.NET](http://ODP.NET) Unmanaged**（`Oracle.DataAccess.dll`）

| 区分 | 現行 |
| --- | --- |
| 開発IDE | Visual Studio 2017（[VB.NET](http://VB.NET)） |
| サーバOS | Windows Server 2019 |
| クライアントOS | Windows 11 |
| ランタイム | .NET Framework 4.7.2 |
| UI部品 | Spread for Windows Forms 12.0 (SP10) |
| DB | Oracle 19c EE (19.3) |
| DB接続 | Oracle.DataAccess.dll（[ODP.NET](http://ODP.NET) Unmanaged） |

---

# 1. Visual Studio（IDE）

## 1-1. サポート期限（公式）

| 製品 | Mainstream End | Extended End | 出典 |
| --- | --- | --- | --- |
| Visual Studio 2017 | 2022-04-12 | **2027-04-13** | [learn.microsoft.com](http://learn.microsoft.com) |
| Visual Studio 2019 | 2024-04-09 | **2029-04-10** | [learn.microsoft.com](http://learn.microsoft.com) |
| Visual Studio 2022 | 2027-01-12 | **2032-01-13** | [learn.microsoft.com](http://learn.microsoft.com) |
| **Visual Studio 2026** | —（Modern Lifecycle） | **2027-11-09**（初版リタイア予定） | [learn.microsoft.com](http://learn.microsoft.com) |

<aside>
ℹ️

**VS2026 からサポートポリシーが変更:** 2025-11-11 GA。**Modern Lifecycle Policy** へ移行し、年次リリースごとに **2年サポート**(1年目=全更新、2年目=セキュリティのみ＝LTSC)。**LTSC チャンネルは 2026年11月 提供開始**予定。

出典: [VS2026 Servicing](https://learn.microsoft.com/en-us/visualstudio/releases/2026/servicing-vs)・[VS2026 Channels](https://learn.microsoft.com/en-us/visualstudio/releases/2026/release-rhythm)

</aside>

## 1-2. 中間バージョン（系列）

### VS2017 系列

- **15.9** が最終サービシングベースライン（2027-04 までセキュリティ更新）
- 直近の修正は 15.9.78（2025-11-11 リリース）等まで継続
- 出典：[VS2017 リリース履歴](https://learn.microsoft.com/en-us/visualstudio/releases/2017/vs2017-relnotes-history)・[15.9 リリースノート](https://learn.microsoft.com/en-us/visualstudio/releases/2017/vs2017-relnotes)

### VS2019 系列（最終サービシングベースライン）

| 版 | 開始 | 終了 |
| --- | --- | --- |
| **16.11** | 2021-08-10 | **2029-04-10** |

*16.0 / 16.4 / 16.7 / 16.9 などの中間ベースラインは採用候補から除外。最終ベースラインの 16.11 のみ記載。*

出典：[VS2019 ライフサイクル](https://learn.microsoft.com/en-us/lifecycle/products/visual-studio-2019)

### VS2022 系列（LTSC）

| 版 | 開始 | 終了 |
| --- | --- | --- |
| 17.0 (LTSC) | 2021-11-08 | 2023-07-11 |
| 17.2 (LTSC) | 2022-05-10 | 2024-01-09 |
| 17.4 (LTSC) | 2022-11-08 | 2024-07-09 |
| 17.6 (LTSC) | 2023-05-16 | 2025-01-14 |
| 17.8 (LTSC) | 2023-11-14 | 2025-07-08 |
| 17.10 (LTSC) | 2024-05-21 | 2026-01-13 |
| **17.12 (LTSC)**（現行最新LTSC） | 2024-11-12 | **2026-07-14** ⚠️ |

*Current チャンネル(17.14 等)は LTSC ではないため除外。今後リリースされる次期 LTSC(17.14 LTSC・17.16 LTSC 等)へ順次切り替えていく前提。*

### VS2026 系列（最新世代 / Modern Lifecycle）

| 版 | GA | Year 1 終了（全更新） | Year 2 終了（LTSC / セキュリティのみ） |
| --- | --- | --- | --- |
| **18.0**（初版） | 2025-11-11 | 2026-11 頃 | **2027-11-09** |
- 2026-04 時点の現行リリースは **18.4.x / 18.5.x** 系列。
- **LTSC チャンネル**は **2026年11月**提供開始予定。Professional / Enterprise / Build Tools が対象。
- **VS2022 の拡張機能はそのまま動作**(後方互換性あり)。
- バンドル: **.NET 10 / C# 14 / MSVC 14.50（LTS）**。
- 推奨ハード: Windows 11 / 64GB RAM / 16コア以上。VS2022 と同一HWでも高速化されていると表明。

出典: [VS2026 Lifecycle](https://learn.microsoft.com/en-us/lifecycle/products/visual-studio-2026)・[VS2026 Release Notes](https://learn.microsoft.com/en-us/visualstudio/releases/2026/release-notes)・[VS2026 GA Blog](https://devblogs.microsoft.com/visualstudio/visual-studio-2026-is-here-faster-smarter-and-a-hit-with-early-adopters/)・[VS Magazine GA記事](https://visualstudiomagazine.com/articles/2025/11/12/visual-studio-2026-ga-first-intelligent-developer-environment-ide.aspx)

<aside>
⚠️

**要検証事項:** VS2026 はサポートモデルが VS2022 までと**非連続**。「VS2022 LTSC を使い切ってから VS2026 LTSC へ」という二段構えになる。[**VB.NET](http://VB.NET) WinForms / .NET Framework 4.8 開発のワークロードが VS2026 で引き続き提供されるか、Spread / [ODP.NET](http://ODP.NET) が VS2026 で動作保証されるか**は、社内保守スタックで実機検証が必要。

</aside>

出典：[VS2022 ライフサイクル](https://learn.microsoft.com/en-us/lifecycle/products/visual-studio-2022)

<aside>
💡

**移行示唆（三段構え）:**
① **短期（2026年多）:** **VS2022 17.12 LTSC**(2026-07-14まで)で当座をしのぐ
② **中期（2026-11以降）:** **VS2026 LTSC** へ移行（LTSC チャンネル提供開始後）
③ **以後:** **VS2026 以降の年次 LTSC**を順次追従（各 2年サポート）
VS2019 16.11 は .NET Framework 中心の保守延命用途なら 2029-04-10 まで使用可。

</aside>

## 1-3. VS2017 から各世代へのアップグレード時の非互換情報

<aside>
🔀

**詳細は別ページに分離:** [VS2017からのアップグレード非互換情報（VS2019 / VS2022 / VS2026）](https://www.notion.so/VS2017-VS2019-VS2022-VS2026-4cbceffed22c499ea7ef7f328cc0b9d8?pvs=21)

ソース・プロジェクトファイルの非互換、世代別の落とし穴、変換ツールの要否、推奨アクションを世代ごとにまとめている。

</aside>

- （旧）以下は分離前の本文。今後はリンク先を正本とする。
    
    ### 1-3-0. 大前提：プロジェクト形式と互換性のレベル
    
    [VB.NET](http://VB.NET) WinForms（.NET Framework）は **古い形式の `.vbproj` ＋ `.sln`** を使う。これは VS2017 / 2019 / 2022 / 2026 すべてが**読み取り・ビルド可能**な形式で、SDK スタイル（.NET Core/.NET 系）への切り替えは強制されない。Microsoft 公式も「下位互換は維持、ただし機能差で再保存が必要な場合あり」と明記している。
    
    出典: [VS2022 Port, migrate, and upgrade projects](https://learn.microsoft.com/en-us/visualstudio/releases/2022/port-migrate-and-upgrade-visual-studio-projects)・[Install Visual Studio Versions Side-by-Side](https://learn.microsoft.com/en-us/visualstudio/install/install-visual-studio-versions-side-by-side)
    
    | 項目 | VS2017 | VS2019 | VS2022 | VS2026 |
    | --- | --- | --- | --- | --- |
    | IDE プロセス | 32bit | 32bit | **64bit**（17.0〜） | 64bit |
    | `.sln` 形式 | Format 12.00 / `# Visual Studio 15` | Format 12.00 / `# Visual Studio Version 16` | Format 12.00 / `# Visual Studio Version 17` | Format 12.00 / `# Visual Studio Version 18`（`.slnx` 任意） |
    | `.vbproj`（旧形式 / WinForms .NET FW） | ○ | ○ | ○ | ○ |
    | WinForms デザイナ | 32bit in-proc | 32bit in-proc | **64bit** in-proc（.NET FW）／out-of-proc（.NET） | 64bit in-proc／out-of-proc |
    | サポートする最低 .NET FW（WinForms新規） | 4.5.2〜 | 4.0〜 | **4.6.2〜**（4.5系新規不可） | **4.6.2〜**（同上） |
    
    出典: [VS2022 Compatibility](https://learn.microsoft.com/en-us/visualstudio/releases/2022/compatibility)・[VS2026 Compatibility](https://learn.microsoft.com/en-us/visualstudio/releases/2026/compatibility)・[New simpler solution file format](https://devblogs.microsoft.com/visualstudio/new-simpler-solution-file-format/)・[VS2026 Insiders（VS2022 ワークロード互換）](https://visualstudio.microsoft.com/insiders/)
    
    <aside>
    ✅
    
    **結論的に**、本件構成（[VB.NET](http://VB.NET) WinForms ＋ .NET Framework 4.7.2 ＋ Spread 12 ＋ [ODP.NET](http://ODP.NET) Unmanaged）であれば、**いずれの世代も「ソリューションを開いて再保存」のワンウェイアップグレードで済む**ケースが多い。コードの構文変更は原則不要。ただし下記の「再ビルド時に発生しうる非互換」は別問題として残る。
    
    </aside>
    
    ---
    
    ### 1-3-1. VS2017 → VS2019
    
    #### ✅ ソース・プロジェクトファイルの非互換
    
    - `.sln` ヘッダの `# Visual Studio 15` → `# Visual Studio Version 16` に**自動書き換え**（VS2019 で保存時）。VS2017 で再度開くことも可能。
    - `.vbproj`（旧形式 [VB.NET](http://VB.NET) WinForms）は**ノータッチで動作**。Microsoft も「変換不要」と明言。
    - `Settings.Designer.vb` / `Resources.Designer.vb` 等の自動生成ファイルもそのまま利用可。
    - VB 言語仕様の追加はあるが、**既存コードを壊す breaking change は VB コンパイラ側でほぼなし**（Roslyn の VB 互換ポリシー）。
        
        出典: [Breaking changes in the VB compiler](https://learn.microsoft.com/en-us/dotnet/visual-basic/whats-new/breaking-changes)
        
    
    #### ⚠️ 注意が必要な非互換ポイント
    
    - **C++/MFC/ATL** を含むソリューションの場合、ATL/MFC コンポーネントが「Individual Components」での明示インストールに変わった。今回は無関係。
    - **Crystal Reports**, **Windows Phone**, **Silverlight** 等のレガシー拡張は VS2019 で**サポート終了**（→ 該当しなければ影響なし）。
    - **Windows 10 SDK の古いバージョン**は VS2019 インストーラから除外。WinForms .NET FW なら影響なし。
    - 一部の古い拡張機能（VSIX）は VS2019 で動作しないものがある。
    
    #### 🔧 必要なアクション
    
    - **不要**（IDE をインストールして開くだけ）。
    - 念のため **`.sln` と `.vbproj` のバージョン管理上のコミット**を残す（ヘッダだけ変わるため）。
    - ソースの変換ツール適用は**不要**。
    
    ---
    
    ### 1-3-2. VS2017 → VS2022
    
    #### 🔥 最大の落とし穴：**VS2022 は 64bit プロセス**
    
    WinForms デザイナは VS と同一プロセス（in-proc）で動作するため、**32bit のみのコンポーネントを参照しているフォームはデザイナで開けなくなる**。実行時は AnyCPU / x86 でビルドすれば従来通り動くが、**設計時のみ動かない**。
    
    出典: [Troubleshoot 32-bit problems（公式）](https://learn.microsoft.com/en-us/dotnet/desktop/winforms/visualstudio/troubleshoot-32bit)・[Why doesn't VS 2022 show my WinForms UI?](https://grantwinney.com/why-doesnt-vs2022-show-my-winforms-ui/)
    
    <aside>
    ⚠️
    
    **現行構成での実機確認ポイント:**
    ① **Spread for Windows Forms 12.0 (SP10):** 64bit ホストでデザイナが動くか要検証（Spread 自体は AnyCPU だが、内部で参照する 3rd party ActiveX があると詰む）
    ② [**ODP.NET](http://ODP.NET) Unmanaged（Oracle.DataAccess.dll）:** 32bit / 64bit でアセンブリが分かれる。**実行時は問題ないがデザイナにはほぼ無関係**（DB 接続コードは設計時に評価されないため）
    ③ **古い OCX / ActiveX をフォームに貼っている場合:** デザイナで開けなくなる可能性大。AxImp で生成された Ax* / AxInterop* DLL が 32bit のみの場合 NG
    
    </aside>
    
    #### ✅ ソース・プロジェクトファイルの非互換
    
    - `.sln` は `# Visual Studio Version 17` に書き換わるが**フォーマット自体は同じ**。VS2017 / 2019 でも開ける（双方向互換）。
    - `.vbproj`（旧形式）は**ノータッチで動作**。
    - **InitializeComponent ハンドラの記述スタイルが変わる事象**が報告あり：VS2022 でフォームを保存すると、コントロールの `Handles` 句が `Form.Designer.vb` 内の `AddHandler` に置き換わるケースがある。**動作上の問題はない**が、ダブルクリックでイベントハンドラに飛ばなくなる等の編集体験低下あり。
        
        出典: [VBForums: VS2022 unwantedly converted my VS2017 project](https://www.vbforums.com/showthread.php?910468-VS2022-unwantedly-converted-my-VS2017-project-net-FRAMEWORK-Windows-Form-App)
        
    - **`Settings.Designer.vb` の自動再生成**で書式が変わるバグが 17.4 系で報告（後続バージョンで改善傾向）。
        
        出典: [Developer Community: VB Settings.Designer.vb](https://developercommunity.visualstudio.com/t/VS-2022-174-is-breaking-the-VB-Settings/10328728)
        
    
    #### ⚠️ ターゲットフレームワークの仕様変更
    
    - VS2022 で **新規** 作成できる .NET Framework は **4.6.2 以上**。
    - **既存** プロジェクトの 4.5 / 4.6 / 4.7.2 はそのままターゲットとして維持可（→ 4.7.2 のままで問題なし）。
    - ただし **.NET 4.7.2 Targeting Pack が VS2022 のインストーラに無い**ケースあり。**.NET Framework SDK / Targeting Pack を別途手動インストール**が必要になることがある。
        
        出典: [Reddit: Cannot use .NET 4.7.2 with VS2022](https://www.reddit.com/r/VisualStudio/comments/utgvg6/cannot_use_net_472_with_visual_studio_2022/)・[Using older .NET Frameworks with VS2022](https://medium.com/@jonschdev/using-older-net-frameworks-with-visual-studio-2022-2ef4e77a7a81)
        
    
    #### 🔧 必要なアクション
    
    - IDE インストール時に「**.NET Framework 4.7.2 開発ツール**」を Individual Components から明示選択（または .NET Framework 4.8 Developer Pack 経由でも 4.7.2 をターゲット可）。
    - **デザイナ問題が出るフォームの洗い出し:** 実機で 1 フォームずつ開いて確認。詰まる場合の対処は以下：
        - [a] 該当 32bit COM コンポーネントの **64bit / AnyCPU 版**へ差し替え
        - [b] それが無ければ **VS2022 をインストールしつつ、UI 編集だけ VS2019 を併存**（サイドバイサイドで共存可）
        - [c] 最終手段で問題のフォームだけ**コードベースで編集**
    - **Spread 12 のデザイナサポート保証**は MESCIUS 側の表明を要確認（v17 以降は 64bit デザイナ正式対応済み）。
    - **変換ツールは不要**。手動で「フォームを開いてエラーが出るか」を確認するのが最速。
    
    ---
    
    ### 1-3-3. VS2017 → VS2026
    
    #### ✅ ソース・プロジェクトファイルの非互換
    
    - VS2026 は **VS2022 のワークロード・拡張機能と完全互換**（後方互換あり）と Microsoft が明言。
        
        出典: [VS2026 Insiders](https://visualstudio.microsoft.com/insiders/)・[VS2026 GA Blog](https://devblogs.microsoft.com/visualstudio/visual-studio-2026-is-here-faster-smarter-and-a-hit-with-early-adopters/)
        
    - `.sln` ヘッダは `# Visual Studio Version 18` に書き換わる（フォーマットは 12.00 のまま）。
    - 任意で **`.slnx`（XML 形式の新ソリューションファイル）**へ移行可能だが、**強制ではない**。当面は `.sln` のままで問題なし。
        
        出典: [The New .slnx Solution Format](https://www.milanjovanovic.tech/blog/the-new-slnx-solution-format-migration-guide)
        
    - `.vbproj`（旧形式）は**ノータッチで動作**。
    - VS2022 と同様、**64bit IDE** なので 32bit コンポーネント問題は VS2022 と同等の注意が必要。
    
    #### ⚠️ 注意が必要な非互換ポイント（VS2026 固有）
    
    - **VB WinForms デザイナの不安定さ**が 18.0 / 18.1 系列で複数報告されている。
        - 「`Method not found: GetGenericArguments()`」などで UserControl が表示されない
        - WinForms デザイナのシャドウキャッシュ削除で解消するケース
        - **System.Reflection.Metadata 10.x が混入すると out-of-proc デザイナが落ちる**ため、NuGet 側でバージョンピン留めが必要なケースあり
        
        出典: [SO: UserControl not visible in designer in VS2026](https://stackoverflow.com/questions/79909009/usercontrol-not-visible-in-designer-in-visual-studio-2026)・[Developer Community: Problem in VB designer VS2026](https://developercommunity.visualstudio.com/t/Problem-in-VB-designer-VS-2026/11000625)・[Opening any WinForm in VS2026 Insiders fails](https://developercommunity.microsoft.com/t/11060335)
        
    - **.NET Framework 4.7.2 ターゲットは引き続き可能**（VS2026 公式互換表に明記：4.8.1 / 4.8 / 4.7.2 / 4.7.1 / 4.7 / 4.6.2 / 3.5 SP1）。
        
        出典: [VS2026 Compatibility](https://learn.microsoft.com/en-us/visualstudio/releases/2026/compatibility)
        
    - **GitHub Copilot app modernization（.NET アップグレード支援）** が標準搭載。Assess → Plan → Execute の三段階ワークフロー。**.NET Framework → .NET（モダン）への将来移行**を検討する場合に有用。
        
        出典: [VS2026 release notes - January Update 18.2.0](https://learn.microsoft.com/en-us/visualstudio/releases/2026/release-notes)
        
    
    #### 🔧 必要なアクション
    
    - VS2022 で問題なく動いていれば、**VS2026 でも基本そのまま動く**（VS2022 拡張機能も後方互換）。
    - ただし WinForms デザイナの 18.x 系不具合は要実機検証。**LTSC チャンネル提供（2026-11 予定）まで待つ**のが安全。
    - **変換ツールは不要**。
    
    ---
    
    ### 1-3-4. 直接アップグレードの可否マトリクス
    
    | 移行 | 直接アップ可否 | 必要な改修（ソース面） | 必要な改修（プロジェクト面） | 変換ツール | 主な検証ポイント |
    | --- | --- | --- | --- | --- | --- |
    | VS2017 → **VS2019** | **○ 直接可** | 不要 | `.sln` ヘッダ自動更新のみ | 不要 | レガシー拡張（Crystal/Silverlight等）の有無 |
    | VS2017 → **VS2022** | **○ 直接可**（VS2019 を経由する必要なし） | 原則不要（一部 `Handles` 句がデザイナ生成側へ移される事象あり） | `.sln` ヘッダ自動更新／.NET FW 4.7.2 Targeting Pack 別途インストール | 不要（必要なら .NET Upgrade Assistant） | **32bit COM/ActiveX のデザイナ表示**／Spread・[ODP.NET](http://ODP.NET) のデザイナ動作 |
    | VS2017 → **VS2026** | **○ 直接可** | 原則不要 | VS2022 と同等 | 不要（`.slnx` 化は任意） | WinForms デザイナの 18.x 不具合／[ODP.NET](http://ODP.NET) Unmanaged 動作 |
    
    <aside>
    💡
    
    **段階アップは原則不要:** [VB.NET](http://VB.NET) WinForms（.NET Framework）は **VS2002 / 2003 のような古い形式**でない限り、VS2017 → VS2026 まで**ワンウェイ変換のみで直接アップグレード可能**。途中バージョンを経由する技術的必要性はない。
    ただし**実プロジェクトの確認手順としては** VS2017 → VS2022 → VS2026 のように段階確認するのが安全（問題切り分けが容易）。
    
    </aside>
    
    ---
    
    ### 1-3-5. 変換ツール・支援ツール一覧
    
    | ツール | 用途 | 本件での適用 |
    | --- | --- | --- |
    | **Visual Studio のワンウェイ変換**（IDE 標準） | `.sln` / `.vbproj` のヘッダ・MSBuild バージョン更新 | **これだけで完結する見込み** |
    | [.NET Upgrade Assistant](https://learn.microsoft.com/en-us/dotnet/core/porting/upgrade-assistant-overview) | .NET Framework → .NET（Core/8/9/10）への移行支援。NuGet 互換分析、API 互換分析 | **今回は不要**（.NET Framework 4.7.2 → 4.8 など FW 内の移動には基本使わない）。**将来 .NET 8/10 へ移植する際の本命ツール** |
    | [CsprojToVs2017](https://github.com/hvanbakel/csprojtovs2017) | 旧形式 `.csproj` → SDK スタイル変換 | **WinForms .NET FW では推奨しない**（SDK スタイル化は WinForms .NET FW で恩恵が薄く、逆にリスク増）。VB 用の同等ツールも未成熟 |
    | **GitHub Copilot app modernization**（VS2026 内蔵） | Assess（評価）→ Plan（計画）→ Execute（実行）の三段階で .NET アップグレードを支援。NuGet 古いパッケージ・API 非互換を抽出 | VS2026 へ移行後、**将来 .NET 化を検討する際**の事前評価ツールとして有用 |
    | **.NET Portability Analyzer** | .NET Framework → .NET の API 互換性分析 | 同上。FW 内移動には不要 |
    
    ---
    
    ### 1-3-6. まとめ：本件構成での推奨アクション
    
    1. **VS2017 → VS2022 を直接実施**（VS2019 経由不要）。
    2. プロジェクトファイル変換は **VS2022 で開いて保存するだけ**。ソース変更・専用変換ツール適用は不要。
    3. .NET Framework 4.7.2 はそのまま継続（または 4.8 へ in-place 引き上げ）。**Targeting Pack の追加インストール**を忘れずに。
    4. **要実機検証:**
        - [ ]  Spread 12 のフォームが VS2022（64bit）デザイナで開けるか
        - [ ]  [ODP.NET](http://ODP.NET) Unmanaged 参照のあるフォームのデザイナ動作
        - [ ]  古い ActiveX / OCX を貼っているフォームの有無
        - [ ]  Crystal Reports など VS2019 以降で除外されたコンポーネントの依存有無
    5. VS2026 への移行は **2026-11 LTSC リリース後**に再評価（WinForms デザイナの 18.x 不具合の落ち着きを待つ）。
    6. 同時並行で進めるべき作業：
        - ① **Spread 12 → v17/v18/v19 への更新計画**（.NET FW 4.6.2 以上必須）
        - ② [**ODP.NET](http://ODP.NET) 19c 系列の最新パッチ（19.26 系）への更新**（ファイルバージョン同一なのでアプリ改修不要）
        - ③ **Managed [ODP.NET](http://ODP.NET) への移行検討**（Unmanaged 23ai/26ai 以降 desupport を見据えて）

---

# 2. Windows Server（IIS / APサーバ OS）

| 版 | Mainstream End | Extended End |
| --- | --- | --- |
| Windows Server 2016 | 2022-01-11 | 2027-01-12 |
| **Windows Server 2019**（現行） | 2024-01-09 | **2029-01-09** |
| Windows Server 2022 | 2026-10-13 | 2031-10-14 |
| Windows Server 2025 | 2030-10-10 | 2035-10-11 |

出典：[Windows Server 2019 lifecycle](https://learn.microsoft.com/en-us/lifecycle/products/windows-server-2019)・[Windows Server リリース情報](https://learn.microsoft.com/en-us/windows/release-health/windows-server-release-info)

<aside>
⚠️

[ODP.NET](http://ODP.NET) 21c で **Server 2022 / Windows 11 をサポート**するのは [**ODP.NET](http://ODP.NET) 21.4 以降**。Server 2025 のサポートは [**ODP.NET](http://ODP.NET) 23 系**で明記。

</aside>

---

# 3. Windows 11（クライアントOS）

- Windows 11 は Modern Lifecycle Policy（製品全体としては “In Support”）
- 実務上は **バージョン（22H2 / 23H2 / 24H2 / 25H2）単位の更新終了日**で管理する必要がある
- 例：23H2（Home/Pro）は 2025-11-11 で更新終了
- 出典：[Windows 11 Home/Pro lifecycle](https://learn.microsoft.com/en-us/lifecycle/products/windows-11-home-and-pro)・[Windows 11 リリース情報](https://learn.microsoft.com/en-us/windows/release-health/windows11-release-information)

---

# 4. .NET Framework（ランタイム）

## 4-1. バージョン整理

| 版 | リリース | 備考 |
| --- | --- | --- |
| 4.6.2 | 2016-08-02 | EOL：2027-01-12 |
| 4.7 | 2017-04-11 | OSサポートに連動 |
| 4.7.1 | 2017-10-17 | OSサポートに連動 |
| **4.7.2**（現行） | 2018-04-30 | OSサポートに連動 |
| 4.8 | 2019-04-18 | OSサポートに連動。**実質的な現行最新系** |
| 4.8.1 | 2022-08-09 | OSサポートに連動 |

出典：[Microsoft .NET Framework lifecycle](https://learn.microsoft.com/en-us/lifecycle/products/microsoft-net-framework)・[システム要件](https://learn.microsoft.com/en-us/dotnet/framework/get-started/system-requirements)

## 4-2. 重要ルール

- .NET Framework 4.x は **in-place update**（同一マシンに 4.x が複数共存できない／上書き更新）
- **OSに同梱されるコンポーネント**としての性格が強く、実運用上は **OSサポート期限が支配的**

---

# 5. Spread for Windows Forms（MESCIUS [Spread.NET](http://Spread.NET)）

## 5-1. メジャー系列（v12 → v19）

| メジャー | 主なリリース／日付 | 備考 |
| --- | --- | --- |
| **v12**（現行） | v12.2 - 2019-07-22 | 現行は 12.0 SP10 |
| v13 | （存在確認） | スライサー、強化シェイプエンジン等 |
| v14 | （存在確認） | — |
| v15 | v15.1 - 2022-04-26 / v15.2 - 2022-07-26 / v15.3 - 2022-09-02 | リッチテキスト編集等 |
| v16 | v16.0 - 2022-11-07 | 19新関数、Forecast/GoalSeek等 |
| v17 | v17 - 2023-12-26 / v17.1 - 2024-04-25 / v17.2 - 2024-09-18 | .NET 8 対応、RibbonBar、ChartSheet |
| v18 | v18 - 2024-12-12 / v18.1 - 2025-04-30 / v18.2 - 2025-07-30 | PDF出力強化、新WPF版 |
| **v19**（最新） | v19 - 2026-01-05 | 新ピボットエンジン、TRIMRANGE/REGEX等 |

出典：[Spread.NET](http://Spread.NET) [Releases](https://developer.mescius.com/spreadnet/releases)・[v17](https://developer.mescius.com/spreadnet/releases/spreadnet-17)・[v18](https://developer.mescius.com/spreadnet/releases/spreadnet-18)・[v19](https://developer.mescius.com/spreadnet/releases/spreadnet-19)

## 5-2. .NET Framework 依存関係

- **NuGet（Spread WinForms 19.0.2）のターゲット：** .NET Framework **4.6.2** / .NET 6.0
    
    出典：[NuGet GrapeCity.Spread.WinForms](https://www.nuget.org/packages/GrapeCity.Spread.WinForms)
    
- **ベンダー推奨：** .NET Framework アプリは **4.8 を推奨**
    
    出典：[MESCIUS Forums - .NET Framework Support Status](https://developer.mescius.com/forums/winforms-edition/net-framework-version-support-status)
    
- ComponentOne 系 WinForms の動作要件として「**Visual Studio 2017 以上 / .NET Framework 4.5.2 以上**」の記載
    
    出典：[ComponentOne System Requirements](https://developer.mescius.com/componentone/system-requirements)
    

<aside>
✅

**結論：** 「Spread 最新化＝4.8 必須」とまでは言えないが、**ベンダー推奨は4.8**。Oracle 側の制約と合わせると、結局 **4.8 へ引き上げが現実解**。

</aside>

---

# 6. Oracle 接続（[ODP.NET](http://ODP.NET) Unmanaged / `Oracle.DataAccess.dll`）

## 6-1. [ODP.NET](http://ODP.NET) ドライバ種別

- **Unmanaged Driver**（現行採用 / `Oracle.DataAccess.dll`）：従来型・Oracle Client 必須
- **Managed Driver**（`Oracle.ManagedDataAccess.dll`）：100% マネージド、単一アセンブリ
- [**ODP.NET](http://ODP.NET) Core**：.NET (Core) 向け、クロスプラットフォーム

<aside>
⚠️

**重要：** Oracle Database 23ai リリースで、**Unmanaged [ODP.NET](http://ODP.NET) は非推奨（deprecated）化**が公表済み。今後の主要リリースで desupport 予定。  

出典：[Unmanaged](https://medium.com/@alex.keh/unmanged-odp-net-is-deprecated-migrate-to-managed-odp-net-or-odp-net-core-f57c6935a322) [ODP.NET](http://ODP.NET) [Is Deprecated（Alex Keh / Oracle）](https://medium.com/@alex.keh/unmanged-odp-net-is-deprecated-migrate-to-managed-odp-net-or-odp-net-core-f57c6935a322)

</aside>

## 6-2. [ODP.NET](http://ODP.NET)（ODAC）世代別 .NET Framework 要件

| 世代 | Unmanaged の .NET Framework 要件 | Managed の .NET Framework 要件 | OS 要件（抜粋） | DB アクセス | 出典 |
| --- | --- | --- | --- | --- | --- |
| ODAC **18c (18.3)** | 3.5 SP1 〜 **4.7.x** まで | 4.0 〜 **4.7.x** まで | Windows 7/8.1/10、Server 2008R2〜2016 系 | — | [ODAC 18c インストールノート](https://www.oracle.com/topics/technologies/dotnet/install183.html) |
| ODAC **19c (19.3)** | **4.5.2 / 4.6.x / 4.7.x / 4.8.x** | **4.5.2 / 4.6.x / 4.7.x / 4.8.x** | Win 8.1 / 10、Server 2012R2 / 2016 / 2019 | DB 11.2 以降 | [ODAC 19.3 System Requirements](https://docs.oracle.com/en/database/oracle/oracle-data-access-components/19.3/odpnt/InstallSystemRequirements.html) |
| [ODP.NET](http://ODP.NET) **21c** | **.NET Framework 4.8 のみ** | **.NET Framework 4.8 のみ** | Win 10/11、Server 2012R2 / 2016 / 2019 / 2022（**21.4 以降**） | DB 12.1.0.2 以降 | [ODP.NET](http://ODP.NET) [21c System Requirements](https://docs.oracle.com/en/database/oracle/oracle-database/21/odpnt/InstallSystemRequirements.html) |
| [ODP.NET](http://ODP.NET) **23ai** | **4.7.2 以上** | **4.7.2 以上** | Win 10/11、Server 2016 / 2019 / 2022 / **2025** | DB **19c 以降** | [ODP.NET](http://ODP.NET) [23 System Requirements](https://docs.oracle.com/en/database/oracle/oracle-database/23/odpnt/InstallSystemRequirements.html) |

### 6-2-1. [ODP.NET](http://ODP.NET) / ODAC のサポート期間

[ODP.NET](http://ODP.NET)（ODAC）の世代別サポート期間は、原則として **対応する Oracle Database 本体のサポート期間に連動**する（同一 MOS Note 742060.1 配下）。Unmanaged Driver については Oracle が個別アナウンスを出している。

| 世代 | 対応DB | Premier Support 終了 | Extended / パッチング終了 | 備考 |
| --- | --- | --- | --- | --- |
| ODAC **18c** | 18c （Innovation） | **終了済**（2021-06） | —（ES 対象外） | Innovation Release。本番採用不可 |
| **ODAC 19c** | 19c （LTR） | **2029-12-31** | **2032-12-31** | 現行採用候補。DB 19c と同一期限 |
| [ODP.NET](http://ODP.NET) 21c | 21c （Innovation） | **2027-07-31** | —（ES 対象外） | Win 11 / Server 2022 のサポートは 21.4+ から |
| [**ODP.NET](http://ODP.NET) 23ai / 26ai** | 23ai （LTR） | **2031-12-31**（延長後） | **TBD**（後日告知予定） | 2024-11 に Premier が 2029-12-31 → 2031-12-31 へ延長。Extended は TBD |

出典: [MOS Note 742060.1](https://support.oracle.com/knowledge/Oracle%20Database%20Products/742060_1.html)・[23ai Premier Support 延長（Mike Dietrich, 2024-11-27）](https://mikedietrichde.com/2024/11/27/premier-support-end-date-for-oracle-database-23ai-has-been-adjusted/)

<aside>
🔴

**Unmanaged [ODP.NET](http://ODP.NET) 固有のアナウンス（重要）**

Oracle は 2024年7月、**23ai リリースで Unmanaged [ODP.NET](http://ODP.NET) を非推奨化**することを公式発表。

- **「23ai 初版から少なくとも 8年間はパッチを提供」**（2024年5月起点 → **概ね 2032年頃まで**）
- Oracle Lifetime Support 配下で [**ODP.NET](http://ODP.NET) 23ai は Sustaining Support で無期限利用可**（ただし新規パッチなし）
- **将来の [ODP.NET](http://ODP.NET) メジャーリリースで Unmanaged は desupport / 提供停止**
- Oracle 公式推奨: Unmanaged → **Managed [ODP.NET](http://ODP.NET)**（.NET Framework系）または [**ODP.NET](http://ODP.NET) Core**（.NET系）へ移行

出典: [Unmanaged](https://medium.com/@alex.keh/unmanged-odp-net-is-deprecated-migrate-to-managed-odp-net-or-odp-net-core-f57c6935a322) [ODP.NET](http://ODP.NET) [Is Deprecated（Alex Keh / Oracle, 2024-07-29）](https://medium.com/@alex.keh/unmanged-odp-net-is-deprecated-migrate-to-managed-odp-net-or-odp-net-core-f57c6935a322)・[Oracle AI Database 26ai Deprecations](https://docs.oracle.com/en/database/oracle/oracle-database/26/upgrd/oracle-database-changes-deprecations-desupports.html)

</aside>

<aside>
💡

**読み解き:** 「Unmanaged は 23ai でパッチを約 8年（~2032）もらえるが、その次の世代では消える」。つまり **2032年頃が Unmanaged 利用の事実上のデッドライン**。ちなみに 19c DB の Extended Support 終了（2032-12-31）とほぼ同じタイミングで終わる設計と読み取れる。

</aside>

## 6-3. `Oracle.DataAccess.dll`（バージョン表記ルール）

- .NET Framework 4 向け：**Assembly version は 4.x.x.x 系列**
- 製品バージョンは DLL の「Product version」プロパティ、アセンブリバージョンは「File version」プロパティで確認可能
- 出典：[ODP.NET](http://ODP.NET) [Versioning Scheme（19c）](https://docs.oracle.com/en/database/oracle/oracle-database/19/odpnt/InstallVersioningScheme.html)・[同（21c）](https://docs.oracle.com/en/database/oracle/oracle-database/21/odpnt/InstallVersioningScheme.html)

### 6-3-1. リリース済みファイルバージョン一覧

<aside>
🔍

**現在のシステム判定:**

- File version: **`4.122.19.1`** → [**ODP.NET](http://ODP.NET) 19c 系列**（Unmanaged）
- Product version: **`4.122.19.1.20190510`** → ビルド日 **2019-05-10** = **ODAC 19c 初版 19.3 GA そのもの**
- 結論: **2019年の初版 19c ドライバから一度もパッチ適用されていない状態**（約 7年放置）
</aside>

#### 重要な仕様（File version は固定される）

Unmanaged [ODP.NET](http://ODP.NET) の **アセンブリバージョン（= File version）は同一メジャー内で固定**される。これは Publisher Policy DLL によって古い参照を新しいアセンブリへ転送する仕組みを保つための意図的な設計。**File version だけでは正確なパッチレベルは判別できない**。

| 識別子 | どこで確認するか | 内容 |
| --- | --- | --- |
| **File version**（アセンブリバージョン） | DLL プロパティ「ファイルバージョン」 | メジャーだけ識別（`4.122.19.1` 等） |
| **Product version** | DLL プロパティ「製品バージョン」 | 実際のリリース＋ビルド日（`4.122.19.1.20190510` 等） |
| ODAC zip 名 | ダウンロードファイル名 | 例: `ODAC1921Xcopy_x64.zip` |

#### Unmanaged [ODP.NET](http://ODP.NET) （Oracle.DataAccess.dll）主要リリース

| File version | 世代 | 主な Product version（ODAC リリース） | 初回リリース |
| --- | --- | --- | --- |
| 4.122.18.x | ODAC 18c | 18.3.0.0.0 | 2018-08 |
| **4.122.19.1** ← 現行 | **ODAC 19c** | **19.3**（=現行・2019-12 GA） / 19.5 / 19.6 / 19.10（2021-01）/ 19.13（2021-10）/ 19.16（2022-07）/ 19.19（2023-04）/ **19.21**（2023-10）/ 19.22（2023-12）/ 19.23（2024-04）/ 19.24 / 19.25 / 19.26 … | 2019-12（19.3） |
| 4.122.21.x | [ODP.NET](http://ODP.NET) 21c | 21.4 / 21.5 / 21.6 / 21.7 / 21.8 / 21.9 〜 | 2022（21.4） |
| **4.122.23.x** | [ODP.NET](http://ODP.NET) 23ai / AI DB 26ai | 23.4（2024-05-02 GA）/ 23.5 / 23.6 / 23.7 / 23.8 / 23.9（2025-07）/ **23.26**（2025-10、26ai 改称） 〜 | 2024-05-02（23.4） |

*Managed Driver と [ODP.NET](http://ODP.NET) Core は別系列（Managed = `4.122.x.x.x`、Core = `2.0.x.x` / `3.21.x.x` / `23.x.x` 等）。本表は Unmanaged のみを対象とする。*

出典: [ODP.NET](http://ODP.NET) [Versioning Scheme（23）](https://docs.oracle.com/en/database/oracle/oracle-database/23/odpnt/InstallVersioningScheme.html)・[ODAC 19c Release 1 Install Instructions](https://www.oracle.com/topics/technologies/dotnet/install193.html)・[Oracle .NET Downloads](https://www.oracle.com/database/technologies/net-downloads.html)・[New](https://www.oracle.com/database/technologies/new-dotnet-features.html) [ODP.NET](http://ODP.NET) [Features by Release](https://www.oracle.com/database/technologies/new-dotnet-features.html)・[NuGet Oracle.ManagedDataAccess 19.21](https://www.nuget.org/packages/Oracle.ManagedDataAccess/19.21.0)

<aside>
⚠️

**現状リスク（重要）:** ODAC 19.3（2019-12）以降の **四半期パッチ（19.5 〜 19.26+）が一切適用されていない**。Oracle が公開している CVE 修正・バグ修正・.NET 4.8 / Windows 11 / Server 2022 などの追加サポート、TLS 1.3 などの強化はすべて未取り込みの状態。Premier Support 期限（2029-12-31）まで時間はあるが、**少なくとも最新の 19.x へ早期にパッチ当てするのが現実解**。

</aside>

<aside>
💡

**推奨アクション:** 19c 系列内の最新パッチ（**19.26 系**）への更新は、File version が同一（`4.122.19.1`）のままなので **アプリ側のバインディングリダイレクト追加なしで差し替え可能**。Oracle Client 側（ORACLE_HOME 配下）の更新と ODAC zip 適用で完結する。一方で Managed / Core への切り替えは別途検討（§6-1・§6-2-1 参照）。

</aside>

## 6-4. Unmanaged 固有の依存（重要）

- Unmanaged [ODP.NET](http://ODP.NET) は **Oracle Client（ORACLE_HOME）必須**
- アプリが参照する [ODP.NET](http://ODP.NET) の版と、ORACLE_HOME 側 [ODP.NET](http://ODP.NET) の版を **一致させる**必要あり（version mismatch 注意）
- 出典：[Installing](https://docs.oracle.com/en/database/oracle/oracle-database/21/odpnt/InstallODP.html) [ODP.NET](http://ODP.NET)[, Unmanaged Driver](https://docs.oracle.com/en/database/oracle/oracle-database/21/odpnt/InstallODP.html)

## 6-5. Oracle Database 各リリースのサポート期間

| リリース | 分類 | GA | Premier Support 終了 | Extended / パッチング終了 | 備考 |
| --- | --- | --- | --- | --- | --- |
| **19c**（現行） | Long Term Release | 2019-04 | **2029-12-31** | **2032-12-31** | “Longest strategic release”。当初 2024-04-30 PS / 2027-04-30 ES だったが、2024年11月に大幅延長 |
| 21c | Innovation Release | 2021-08 | **2027-07-31** | —（ES 対象外） | Innovation Release は Extended Support 対象外。当初 2024-04 予定の PS が 2027-07-31 まで延長された |
| **23ai → AI Database 26ai** | Long Term Release | 2024-05-02（オンプレミス同日） | **~2029頃**（GAから 5 年） | **2032-12-31**（パッチング終了日） | 2025-10 の RU 23.26.0 以降は **Oracle AI Database 26ai** にブランド変更。LTR なので 5年 PS + 3年 ES が原則 |

出典: [MOS Note 742060.1（Release Schedule of Current Database Releases）](https://support.oracle.com/knowledge/Oracle%20Database%20Products/742060_1.html)・[19c 延長アナウンス（Mike Dietrich, 2024-11-20）](https://mikedietrichde.com/2024/11/20/important-update-to-oracle-database-19c-support-timelines/)・[21c Premier 延長（Mike Dietrich）](https://mikedietrichde.com/2023/12/11/premier-support-for-oracle-database-21c-extended/)・[The Register: 19c Extended to 2032](https://www.theregister.com/2025/02/18/oracle_extends_19c_support/)・[Blue Crystal: 19c Premier Extension](https://www.bluecrystal.com.au/news/oracle-premier-support-extension/)・[Oracle Lifetime Support Policy](https://www.oracle.com/support/lifetime-support/)

### 6-5-1. Oracle サポートステージの読み方

- **Premier Support：** フルサポート（パッチ・重要修正・テクサポ）。追加費用なし
- **Extended Support (ES)：** 追加料金でパッチと重要修正を提供。Long Term Release のみ対象。通常 PS 終了後 3年
- **Sustaining Support：** ES 終了後も無期限提供されるが、**新規パッチは出ない**。事実上の「サポート切れ」
- **Innovation Release（例: 18c / 21c）：** 機能検証用の短期リリース。**ES 対象外**なため長期本番では採用しない
- **Long Term Release（例: 19c / 23ai）：** 本番採用推奨。**5年 PS + 3年 ES** が原則

<aside>
✅

**19c は 2032-12-31 まで使い切れる**ため、当面の DB 本体側はサポート切れリスク低。トリガーになるのは本体よりも [ODP.NET](http://ODP.NET) Unmanaged の desupport タイミング（23ai/26ai 世代以降）。DB 本体より接続ドライバ側のロードマップを優先して詰めるのが現実的。

</aside>

---

# 7. 依存関係マトリクス（衝突しやすい箇所の総括）

| 移行アクション | 必要となる .NET Framework | 影響する周辺要件 |
| --- | --- | --- |
| Spread を v17〜v19 系へ | 4.6.2 以上（推奨は 4.8） | VS2017 以上 |
| [ODP.NET](http://ODP.NET) Unmanaged を 19c へ | 4.5.2 / 4.6.x / 4.7.x / 4.8.x（4.7.2 でも可） | Oracle Client 19c、Server 2012R2〜2019 |
| [ODP.NET](http://ODP.NET) Unmanaged を 21c へ | **4.8 必須** | Server 2022/Win 11 は 21.4+、Oracle Client 21c |
| [ODP.NET](http://ODP.NET) を 23ai 世代へ | 4.7.2 以上 | **Unmanaged は非推奨**。Managed/Core への移行が前提 |
| Server OS を 2022/2025 へ | — | [ODP.NET](http://ODP.NET) 21.4+（2022）／23系（2025） |

---

# 8. 推奨される移行方針（現時点の整理）

## 8-1. 短期（現行スタックを延命しつつサポート内に収める）

- IDE：当座は **VS2022 17.12 LTSC**、2026-11 以降は **VS2026 LTSC** へ移行（以降は各年次 LTSC を追従）
- ランタイム：**.NET Framework 4.8** へ統一
- Spread：**v18 / v19**（.NET Framework 4.8 ベース）へ
- Oracle 接続：[**ODP.NET](http://ODP.NET) 19c（Unmanaged）** をパッチ最新化、または **Managed Driver へ移行**を検討開始
- サーバ OS：**Windows Server 2022 LTSC** を本命に

## 8-2. 中長期（10年後を見据える）

- **Unmanaged [ODP.NET](http://ODP.NET) を Managed [ODP.NET](http://ODP.NET) へ移行**（23ai でのdeprecation 対応）
- WinForms 維持なら .NET Framework 4.8 継続、もしくは **.NET 8/9（LTS）** への移植検討
- IIS（SOAP）部分は、**WCF → CoreWCF**（.NET 移植）または **REST 化**を視野

---

# 9. 次にやるべき棚卸し（実機側）

- [ ]  現行サーバ／クライアント上の `Oracle.DataAccess.dll` の **File version / Product version**
- [ ]  サーバ／クライアントに入っている **Oracle Client（ODAC）の版**（ORACLE_HOME / GAC / Publisher Policy）
- [ ]  Windows 11 クライアントの **22H2 / 23H2 / 24H2 / 25H2** 内訳
- [ ]  Spread 12.0 (SP10) の保守契約状況（MESCIUS の Maintenance Plan の有無）
- [ ]  IIS 側 SOAP/WCF サービスの構成（バインディング、認証、TLS）