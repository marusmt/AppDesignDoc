<#
.SYNOPSIS
    指定ファイルを UTF-8 BOM付き・CRLF 改行に変換する。
.PARAMETER Path
    変換対象ファイルのパス（ワイルドカード可）。複数指定可。
.EXAMPLE
    cd C:\Repos\SourceList
    .\tools\Convert-ToUTF8BOMCrLf.ps1 -Path .\src\Logger.psm1
    .\tools\Convert-ToUTF8BOMCrLf.ps1 -Path .\src\*.ps1, .\src\*.psm1
#>
param(
    [Parameter(Mandatory)]
    [string[]]$Path
)

$utf8Bom = New-Object System.Text.UTF8Encoding($true)

foreach ($pattern in $Path) {
    foreach ($file in (Get-Item -Path $pattern)) {
        # 既存 CR を除去してから LF を CRLF に統一する（二重 CR 防止）
        $content = [System.IO.File]::ReadAllText($file.FullName)
        $content = $content -replace "`r", ''
        $content = $content -replace "`n", "`r`n"
        [System.IO.File]::WriteAllText($file.FullName, $content, $utf8Bom)
        Write-Host "変換完了: $($file.FullName)"
    }
}
