﻿$ErrorActionPreference = 'Stop'

function Get-FileEncoding {
    <#
    .SYNOPSIS
        ファイルの文字エンコーディングを判定する。
    .PARAMETER FilePath
        判定対象ファイルの絶対パス。
    .PARAMETER DefaultEncoding
        BOM なしの場合に使用するデフォルトエンコーディング。
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$FilePath,
        [string]$DefaultEncoding = 'UTF-8'
    )
    # v02 で本実装。v01 では呼び出しなし。
    throw [System.NotImplementedException]::new('Get-FileEncoding は v02 で実装予定')
}

Export-ModuleMember -Function Get-FileEncoding
