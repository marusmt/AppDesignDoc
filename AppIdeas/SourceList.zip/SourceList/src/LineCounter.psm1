﻿$ErrorActionPreference = 'Stop'

function Get-LineCounts {
    <#
    .SYNOPSIS
        ファイルの総行数・コメント行数・空行数をカウントする。
    .PARAMETER FilePath
        カウント対象ファイルの絶対パス。
    .PARAMETER Language
        言語種別。'VBNET' / 'PLSQL' / 'OTHER' のいずれか。
    .PARAMETER Encoding
        ファイルの文字エンコーディング。
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$FilePath,
        [Parameter(Mandatory)]
        [string]$Language,
        [Parameter(Mandatory)]
        [string]$Encoding
    )
    # v02 で本実装。v01 では呼び出しなし。
    throw [System.NotImplementedException]::new('Get-LineCounts は v02 で実装予定')
}

Export-ModuleMember -Function Get-LineCounts
