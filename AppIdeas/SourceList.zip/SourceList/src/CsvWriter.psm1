﻿$ErrorActionPreference = 'Stop'

function Export-SourceListCsv {
    <#
    .SYNOPSIS
        走査結果レコードを UTF-8 BOM付き CSV ファイルとして出力する。
    .PARAMETER Records
        出力対象のレコード配列。
    .PARAMETER OutputPath
        出力先 CSV ファイルの絶対パス。
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [object[]]$Records,
        [Parameter(Mandatory)]
        [string]$OutputPath
    )
    # v05 で本実装。v01 では呼び出しなし。
    throw [System.NotImplementedException]::new('Export-SourceListCsv は v05 で実装予定')
}

Export-ModuleMember -Function Export-SourceListCsv
