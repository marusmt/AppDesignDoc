# 機能設計書（functional-design.md）

> 本ドキュメントは SourceList の「どう動くか」を定義する永続的ドキュメントです。
> コマンド仕様・設定ファイル仕様・処理フロー・ログ仕様を定義します。

---

## 1. コマンド仕様

### スクリプト名

```
src\SourceList.ps1
```

### パラメータ一覧

| パラメータ | 型 | 必須 | 既定値 | 説明 |
|-----------|-----|------|--------|------|
| `-RootPath` | `String` | ✓ | — | 走査対象のルートフォルダパス |
| `-ConfigPath` | `String` | — | `.\config\settings.psd1` | 設定ファイルのパス |
| `-OutputDir` | `String` | — | `.\output` | CSV 出力先ディレクトリ |
| `-LogDir` | `String` | — | `.\logs` | ログ出力先ディレクトリ |

### 実行例

```powershell
# 最小構成（設定ファイルはデフォルト）
.\src\SourceList.ps1 -RootPath "C:\Projects\MyApp"

# 設定ファイルを明示指定
.\src\SourceList.ps1 -RootPath "C:\Projects\MyApp" -ConfigPath ".\config\settings.psd1"

# 出力先を変更
.\src\SourceList.ps1 -RootPath "C:\Projects\MyApp" -OutputDir "D:\Reports"
```

### 終了コード

| コード | 意味 |
|--------|------|
| `0` | 正常終了（スキップあり含む） |
| `1` | 異常終了（RootPath が存在しない、設定ファイル読み込み失敗など） |

---

## 2. 設定ファイル仕様

### ファイル形式

PowerShell Data File（`.psd1`）を使用する。
`Import-PowerShellDataFile` で読み込み可能な Hash テーブル形式。

### ファイルパス

```
config\settings.psd1
```

### 定義項目

```powershell
@{
    # VB.NET 系として扱う拡張子（小文字）
    VbNetExtensions  = @(
        '.vb', '.vbproj', '.sln', '.resx', '.config',
        '.xml', '.xsd', '.xsl', '.txt', '.ini',
        '.bat', '.cmd', '.ps1', '.md', '.csv'
    )

    # PL/SQL 系として扱う拡張子（小文字）
    PlSqlExtensions  = @(
        '.sql', '.pkb', '.pks', '.prc', '.fnc', '.trg', '.vw'
    )

    # 除外する拡張子（バイナリ等）
    ExcludeExtensions = @(
        '.exe', '.dll', '.pdb', '.png', '.jpg', '.jpeg',
        '.gif', '.bmp', '.ico', '.zip', '.7z', '.rar',
        '.cab', '.msi', '.lib', '.obj', '.bin', '.dat'
    )

    # 除外するフォルダ名（部分一致）
    # output・logs・.steering はツール自身の生成物／作業フォルダのため除外（自己参照防止）
    # docs・tests は走査対象に含める
    ExcludeFolders   = @(
        'bin', 'obj', '.git', '.vs', 'node_modules',
        'output', 'logs', '.steering'
    )
}
```

### 拡張子判定の優先順位

1. `ExcludeExtensions` に含まれる → スキップ（CSV に `SKIPPED` で記録）
2. `PlSqlExtensions` に含まれる → `PLSQL`
3. `VbNetExtensions` に含まれる → `VBNET`
4. いずれにも該当しない → `OTHER`（処理対象として扱う）

> `PlSqlExtensions` を `VbNetExtensions` より先に評価する。両リストに同じ拡張子が定義された場合は PL/SQL が優先される。

### 設定ファイルが存在しない場合

上記の値をスクリプト内のデフォルト定数として使用し、警告メッセージをログに記録したうえで処理を続行する。

### 同梱設定ファイル

リポジトリに `config\settings.psd1` を既定値で同梱する。ユーザーはこのファイルを編集することで対象拡張子・除外フォルダを変更できる。

### 将来拡張用（MVP 範囲外）

以下は MVP では設定ファイル化しない。スクリプト内定数として管理し、将来のバージョンで設定ファイル化を検討する。

| 項目 | MVP での扱い |
|------|-------------|
| コメント記号定義（`'`、`REM`、`--`、`/* */`） | スクリプト内定数 |
| 進捗表示の閾値（既定: 1,000 件ごと） | スクリプト内定数 |
| ログレベルのフィルタ | 全レベル出力固定 |

---

## 3. 処理フロー

```mermaid
flowchart TD
    A[開始] --> B[パラメータ検証\nRootPath 存在確認]
    B -->|NG| Z1[エラーログ出力\n終了コード 1]
    B -->|OK| C[設定ファイル読み込み\nsettings.psd1]
    C -->|読み込み失敗| C2[デフォルト値で続行\n警告ログ]
    C -->|OK| D[出力先ディレクトリ確認・作成\noutput / logs]
    C2 --> D
    D --> E[ファイル走査開始\nGet-ChildItem -Recurse]
    E --> F{除外フォルダか?}
    F -->|Yes| E
    F -->|No| G{対象拡張子か?}
    G -->|No: バイナリ等| H[スキップ\nログ記録・CSV に SKIPPED で記録]
    H --> E
    G -->|Yes| I[エンコーディング判定\nBOM検出 → 拡張子フォールバック]
    I -->|想定外エンコーディング| H
    I -->|OK| J[ファイル読み込み\n行単位で処理]
    J --> K[行数カウント\n総行数 / コメント行数 / 空行数]
    K --> L[結果をリストに追加]
    L --> M{1,000件ごと?}
    M -->|Yes| N[進捗をコンソール＋ログに出力]
    N --> E
    M -->|No| E
    E -->|走査完了| O[CSV 出力\nUTF-8 BOM付き CRLF\nExport-Csv 一括書き込み]
    O --> P[完了メッセージ\n言語別・スキップ理由別サマリをコンソール＋ログに出力]
    P --> Q[終了コード 0]
```

---

## 4. 行数カウント判定ロジック

### 行分類の優先順位

1 行を以下の優先順位で分類する。上位の条件に該当した時点で確定し、残りは評価しない。

| 優先順位 | 分類 | 条件 |
|---------|------|------|
| 1 | 空行 | 半角スペース・タブ・改行文字以外の文字を含まない |
| 2 | コメント行 | 空白除去後の行全体がコメント記号で始まる（VB.NET: `'`・`REM`、PL/SQL: `--`・ブロックコメント内） |
| 3 | コード行 | 上記以外すべて |

### 混在行の扱い

コードとコメントが同一行に存在する行（例: `Dim x As Integer ' 変数宣言`）は **コード行** として分類する。`CommentLines` にはカウントしない。

### MVP 制限事項

以下は MVP では簡易判定とし、制限事項として明記する。

- 文字列リテラル内のコメント記号（例: `Dim s = "-- not a comment"`）を誤ってコメントと判定する可能性がある
- PL/SQL のブロックコメント（`/* … */`）が文字列リテラル内に現れる場合も同様
- 誤判定が発生した場合、実際より `CommentLines` が多くカウントされる方向にずれる

---

## 5. ログ出力仕様

### ファイルパス

```
logs\SourceList_yyyyMMdd_HHmmss.log
```

### ファイルフォーマット

| 項目 | 仕様 |
|------|------|
| 文字コード | UTF-8 BOM付き |
| 改行コード | CRLF |

### ログレベル

| レベル | 用途 |
|--------|------|
| `INFO` | 正常な処理の節目（走査開始・完了・進捗・CSV出力完了） |
| `WARN` | 処理は続行できるが注意が必要な事象（設定ファイル不在・デフォルト使用） |
| `SKIP` | ファイルをスキップした理由（バイナリ・想定外エンコーディング・読み込みエラー） |
| `ERROR` | 処理継続不能なエラー（RootPath 不在・出力ディレクトリ作成失敗など） |

### ログフォーマット

```
yyyy-MM-dd HH:mm:ss [LEVEL] メッセージ
```

### 出力例

```
2026-04-28 10:00:00 [INFO]  走査開始: C:\Projects\MyApp
2026-04-28 10:00:00 [WARN]  設定ファイルが見つかりません。デフォルト値で続行します: .\config\settings.psd1
2026-04-28 10:00:05 [INFO]  進捗: 1,000 件処理済み
2026-04-28 10:00:07 [SKIP]  バイナリ拡張子のためスキップ: C:\Projects\MyApp\bin\Release\MyApp.exe
2026-04-28 10:00:09 [SKIP]  想定外エンコーディングのためスキップ: C:\Projects\MyApp\legacy\old.vb
2026-04-28 10:00:12 [INFO]  走査完了: 合計 1,570 件
2026-04-28 10:00:12 [INFO]    処理対象: 1,523 件（VBNET: 1,102 件 / PLSQL: 287 件 / OTHER: 134 件）
2026-04-28 10:00:12 [INFO]    スキップ:    47 件（バイナリ: 38 件 / 想定外エンコーディング: 6 件 / 読み込みエラー: 3 件）
2026-04-28 10:00:12 [INFO]  CSV 出力完了: .\output\SourceList_20260428_100000.csv
```

---

## 6. CSV 出力仕様

### ファイルパス

```
output\SourceList_yyyyMMdd_HHmmss.csv
```

### カラム定義

| # | カラム名 | 型 | 説明 |
|---|----------|----|------|
| 1 | `FullPath` | String | ファイルのフルパス |
| 2 | `RelativePath` | String | 走査ルートからの相対パス |
| 3 | `FileName` | String | ファイル名（拡張子含む） |
| 4 | `Extension` | String | 拡張子（小文字、ドット含む。例: `.vb`） |
| 5 | `Language` | String | `VBNET` / `PLSQL` / `OTHER` / `SKIPPED` |
| 6 | `SizeBytes` | Integer | ファイルサイズ（バイト） |
| 7 | `Lines` | Integer | 総行数 |
| 8 | `CommentLines` | Integer | コメント行数 |
| 9 | `BlankLines` | Integer | 空行数 |
| 10 | `LastWriteTime` | String | 最終更新日時（`yyyy-MM-dd HH:mm:ss`） |

### フォーマット詳細

| 項目 | 仕様 |
|------|------|
| 文字コード | UTF-8 BOM付き（`EF BB BF`） |
| 区切り文字 | カンマ（`,`） |
| 改行コード | CRLF（`\r\n`） |
| ヘッダ行 | あり（1 行目） |
| エスケープ | RFC 4180 準拠（値にカンマ・`"`・改行を含む場合はダブルクォートで囲む。`"` は `""` にエスケープ） |

### スキップされたファイルの扱い

| 事象 | CSV への記録 | 備考 |
|------|------------|------|
| バイナリ拡張子 | 記録する（`Language=SKIPPED`、Lines / CommentLines / BlankLines は空文字） | スキップ理由はログのみ |
| 想定外エンコーディング | 記録する（`Language=SKIPPED`、行数系カラムは空文字） | スキップ理由はログのみ |
| ファイル読み込み例外 | 記録する（`Language=SKIPPED`、行数系カラムは空文字） | スキップ理由はログのみ |
| `ExcludeFolders` 配下 | **記録しない** | フォルダ単位で走査対象外のため |

### 想定対象規模と出力方式

- 想定最大規模: **10 万ファイル以下**
- 処理中は全結果をメモリ上の配列に保持し、走査完了後に `Export-Csv` で一括書き込みする
- 10 万ファイルを超える規模での動作は保証しない（制限事項として明記）

---

## 7. エラー・スキップ処理仕様

| 事象 | 処理 | ログレベル |
|------|------|-----------|
| `-RootPath` が存在しない | 即時終了（終了コード 1） | `ERROR` |
| 設定ファイルが存在しない | デフォルト値で続行 | `WARN` |
| バイナリ拡張子のファイル | スキップ（CSV に SKIPPED で記録） | `SKIP` |
| 想定外エンコーディング | スキップ（CSV に SKIPPED で記録） | `SKIP` |
| ファイル読み込み中の例外 | スキップして次のファイルへ（CSV に SKIPPED で記録） | `SKIP` |
| 出力ディレクトリ作成失敗 | 即時終了（終了コード 1） | `ERROR` |
| CSV 書き込み失敗 | 即時終了（終了コード 1） | `ERROR` |
