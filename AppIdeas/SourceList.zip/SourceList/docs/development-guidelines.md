# 開発ガイドライン（development-guidelines.md）

> 本ドキュメントは SourceList の開発において守るべきコーディング規約・テスト方針・Git 規約を定義する永続的ドキュメントです。

---

## 1. PowerShell コーディング規約

### 基本方針

- **PowerShell 5.1 構文のみ使用する。** `??`（null 合体演算子）・`ForEach-Object -Parallel` など PS7 以降の構文は使用しない
- **標準コマンドのみ使用する。** `Install-Module` で追加したモジュールに依存しない
- **`Import-Module` は `src\` 内の自作 `.psm1` のみ許可する**

### ファイル保存規約

| 項目 | 規約 |
|------|------|
| 文字コード | **UTF-8 BOM付き**（PS 5.1 で日本語コメントが化けないように） |
| 改行コード | CRLF |
| インデント | **スペース 4 つ**（タブ禁止） |

### 命名規則

| 対象 | 規則 | 例 |
|------|------|-----|
| スクリプト・モジュール名 | PascalCase | `FileScanner.psm1` |
| 関数名 | `動詞-名詞` 形式（PowerShell 標準動詞を使う。一覧は `Get-Verb` で確認） | `Get-FileEncoding`, `Write-LogMessage` |
| パラメータ名 | PascalCase | `-RootPath`, `-ConfigPath` |
| ローカル変数 | camelCase | `$filePath`, `$lineCount` |
| 定数・設定値 | PascalCase（スクリプトスコープ変数） | `$Script:DefaultProgressInterval` |
| モジュール内公開関数 | `Export-ModuleMember` で明示的にエクスポート | — |

### 関数設計

- **1 関数 1 責務。** 関数は単一の目的を持ち、50 行を超える場合は分割を検討する
- **副作用を明示する。** ファイル書き込み・コンソール出力などの副作用がある関数は動詞で明示する（`Write-`, `Export-`, `Add-` など）
- **パラメータには型を明示する**
  ```powershell
  function Get-LineCount {
      param(
          [string]$FilePath,
          [string]$Language
      )
  }
  ```
- **`[CmdletBinding()]` を付与し、`-Verbose` / `-ErrorAction` を自動サポートする**

### エラーハンドリング

- **`$ErrorActionPreference = 'Stop'` を `SourceList.ps1` および各 `.psm1` モジュールの先頭に設定し、未処理例外を `catch` に落とす。`$ErrorActionPreference` はスコープごとに独立して評価されるため、モジュール側にも個別に設定が必要。**
- **`try/catch` で例外を捕捉し、スキップ処理はログ記録後に続行する**
- **異常終了時は `exit 1` で明示的に終了コードを返す**

```powershell
$ErrorActionPreference = 'Stop'
try {
    # 処理
} catch {
    Write-LogMessage -Level 'SKIP' -Message "読み込みエラー: $($_.Exception.Message)" -LogPath $logPath
}
```

### コメント規約

- **コードを読めば分かることはコメントしない**
- **「なぜ」が非自明な箇所にのみコメントを書く**（制約・回避策・PS 5.1 固有の挙動差など）
- **関数のコメントは1行の簡潔な説明のみ**（多行ブロックコメント不要）
- **PowerShell ヘルプブロック（`<# .SYNOPSIS #>`）はモジュール内の関数には MVP では書かない。** エントリポイントスクリプト（`SourceList.ps1`）のみ、実行例・パラメータ説明のため記述する

```powershell
# PS 5.1 の Get-Content は BOM 付き UTF-8 として扱うため、BOM 検出には ReadAllBytes を使う
$bytes = [System.IO.File]::ReadAllBytes($FilePath)
```

### 禁止事項

| 禁止 | 理由 |
|------|------|
| `Write-Host` をログ出力・進捗表示以外に使う | パイプラインを汚染するため |
| グローバル変数（`$Global:`）の使用 | スコープ汚染を避けるため |
| `Invoke-Expression` の使用 | セキュリティリスクのため |
| ハードコードされたパス | 再利用性・移植性を損なうため |
| `echo` / `print` | PowerShell では `Write-Output` を使う |

> `Write-Host` はコンソールへの進捗表示・ログメッセージの出力に限り使用を許容する。パイプラインや戻り値が必要な処理では `Write-Output` を使う。

---

## 2. CSV フォーマット規約

`functional-design.md` セクション6「CSV 出力仕様」が正となる。ここでは実装上の注意点を補足する。

### `Export-Csv` の使い方

```powershell
# -NoTypeInformation で "#TYPE ..." ヘッダ行を除去する
# -Encoding UTF8 で BOM付き UTF-8 を出力する（PS 5.1 の挙動）
$results | Export-Csv -Path $csvPath -Encoding UTF8 -NoTypeInformation
```

### SKIPPED 行の扱い

行数系カラム（`Lines` / `CommentLines` / `BlankLines`）が空になる SKIPPED ファイルは、
対応プロパティに `$null` を設定する。`Export-Csv` が空文字として出力する。

```powershell
[PSCustomObject]@{
    FullPath      = $file.FullName
    RelativePath  = $relativePath
    FileName      = $file.Name
    Extension     = $ext
    Language      = 'SKIPPED'
    SizeBytes     = $file.Length
    Lines         = $null
    CommentLines  = $null
    BlankLines    = $null
    LastWriteTime = $file.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss')
}
```

---

## 3. テスト方針

### テストの種類

本ツールは自動テストフレームワークを使用しない。**手動検証を基本**とする。

| 種類 | 内容 | 格納場所 |
|------|------|---------|
| サンプルソース | 境界ケースを網羅した VB.NET・PL/SQL ファイル | `tests/vbnet/`・`tests/plsql/` |
| 期待値 CSV | 各サンプルに対する期待される出力 | `tests/expected/` |

### テストケース設計方針

各境界ケースに対してサンプルファイルと期待値 CSV を 1 対 1 で作成する。

**VB.NET 必須ケース:**

| # | ファイル名 | 検証内容 |
|---|-----------|---------|
| 01 | `01_comment_only.vb` | `'` コメント行のみ |
| 02 | `02_rem_comment.vb` | `REM` コメント（大文字・小文字混在） |
| 03 | `03_mixed_line.vb` | コードとコメントの混在行（コード行扱いを確認） |
| 04 | `04_blank_lines.vb` | 空行・スペースのみ行・タブのみ行 |
| 05 | `05_no_trailing_newline.vb` | 最終行に改行なし（1行と数えることを確認） |
| 06 | `06_utf8_bom.vb` | UTF-8 BOM付きファイル |
| 07 | `07_utf16_le.vb` | UTF-16 LE ファイル |

**PL/SQL 必須ケース:**

| # | ファイル名 | 検証内容 |
|---|-----------|---------|
| 01 | `01_line_comment.sql` | `--` 行頭コメント |
| 02 | `02_inline_comment.sql` | 行中の `--`（コード行扱いを確認） |
| 03 | `03_block_comment_single.sql` | 1行完結ブロックコメント `/* … */` |
| 04 | `04_block_comment_multi.sql` | 複数行ブロックコメント |
| 05 | `05_block_mixed.sql` | `/*` 後にコードが続く行（コード行扱いを確認） |
| 06 | `06_sjis.sql` | Shift_JIS エンコーディング（日本語コメント含む） |
| 07 | `07_block_inline_with_code.sql` | 行頭がコードで `/* … */` を含む混在行（コード行扱いを確認。例: `x := 1; /* インラインコメント */`）。`architecture.md` 4パターン分類パターン3 を検証 |
| 08 | `08_block_comment_with_line_marker.sql` | BLOCK_COMMENT 状態中の `--` がブロックコメントの一部として扱われ、状態が変わらないことを確認。`architecture.md` 任意8 を検証 |

### 手動検証手順

1. `tests/vbnet/`・`tests/plsql/` のサンプルを走査対象として `SourceList.ps1` を実行する
2. 生成された CSV を `tests/expected/` の期待値 CSV と手動で差分確認する
3. 相違点があれば原因を特定し、スクリプトまたは期待値 CSV を修正する

### 期待値 CSV のゴールデンマスター方式

v0.1 完成時点での実行出力を目視レビューで承認し、`tests/expected/` に固定する。以降の変更で出力が変わった場合は、意図した変更かどうかを確認したうえで期待値 CSV を更新する。

### 期待値 CSV の管理

- 期待値 CSV は Git 管理対象とする
- スクリプトの仕様変更時は期待値 CSV も同時に更新する
- ファイル名規則: `<言語>_<連番>_<内容>.csv`（例: `vbnet_01_comment_only.csv`）

---

## 4. Git 規約

### ブランチ戦略

個人利用（MVP）のため、シンプルな運用とする。

- **`main`:** 常に動作する状態を保つ
- **`feature/<タスク名>`:** 機能追加・修正作業用（任意。小規模な修正は `main` 直コミットも可）

### コミットメッセージ規約

**言語:** 日本語で記述する（個人プロジェクトのため。将来チームで使う場合は英語への移行を検討する）

```
<種別>: <変更内容の要約>（50 文字以内）

<詳細説明（任意）>
```

**種別:**

| 種別 | 用途 |
|------|------|
| `feat` | 新機能追加 |
| `fix` | バグ修正 |
| `docs` | ドキュメントのみの変更 |
| `refactor` | 動作を変えないリファクタリング |
| `test` | テストサンプル・期待値の追加・修正 |
| `chore` | ビルド・設定・`.gitignore` 等の変更 |

**例:**
```
feat: FileScanner モジュールに除外フォルダフィルタを追加

-contains による完全一致判定で output_archive のような誤除外を防止
```

### コミットのタイミング

- 1 タスク（`.steering/tasklist.md` の 1 チェックボックス）完了ごとにコミットする
- 動作確認前の中間状態はコミットしない
- `output/*.csv` / `logs/*.log` はコミットしない（`.gitignore` で除外済み）

---

## 5. 実行手順

### 前提：リポジトリルートからの実行

SourceList.ps1 は **リポジトリルートをカレントディレクトリとして実行すること。**

`.\config\settings.psd1`・`.\output`・`.\logs` はカレントディレクトリ相対パスで解決される（`$PSScriptRoot` ベースではない）。

```powershell
# 正しい実行例（リポジトリルートから）
cd C:\Repos\SourceList
.\src\SourceList.ps1 -RootPath C:\Projects\MyApp
```

### パラメータ一覧

| パラメータ | 必須 | 既定値 | 説明 |
|---|---|---|---|
| `-RootPath` | ✓ | — | 走査対象ルートフォルダ。存在しない場合はエラー終了。 |
| `-ConfigPath` |  | `.\config\settings.psd1` | v01 未対応（指定しても WARN ログに記録して無視）。v10 で対応予定。 |
| `-OutputDir` |  | `.\output` | CSV 出力先フォルダ。未存在時は自動作成（v05 以降で CSV を生成）。 |
| `-LogDir` |  | `.\logs` | ログ出力先フォルダ。未存在時は自動作成。 |

### 終了コード

| コード | 意味 |
|---|---|
| `0` | 正常終了 |
| `1` | 異常終了（RootPath 不存在・モジュールロード失敗・走査中例外等） |
