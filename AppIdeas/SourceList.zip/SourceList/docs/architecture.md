# 技術仕様書（architecture.md）

> 本ドキュメントは SourceList の技術構成・実装方針を定義する永続的ドキュメントです。
> PowerShell 構成・ファイル走査方式・エンコーディング判定・コメント判定ステートマシンを定義します。

---

## 1. テクノロジースタック

| 分類 | 採用技術 | 備考 |
|------|---------|------|
| 実行環境 | Windows（ローカル） | ネットワーク接続不要 |
| スクリプト言語 | PowerShell 5.1 | Windows 標準、PS7 系は対象外 |
| ファイル形式（設定） | PowerShell Data File（`.psd1`） | `Import-PowerShellDataFile` で読み込み |
| ファイル形式（出力） | CSV（UTF-8 BOM付き） | Excel 取り込み対応 |
| ファイル形式（ログ） | テキスト（UTF-8 BOM付き） | CRLF 改行 |
| 外部依存 | **なし** | PowerShell 標準コマンドのみ |

---

## 2. スクリプト構成

### ファイル構成

```
src\
├── SourceList.ps1        # エントリポイント（パラメータ処理・全体制御）
├── FileScanner.psm1      # フォルダ走査・拡張子フィルタ
├── LineCounter.psm1      # 行数カウント・コメント判定
├── EncodingDetector.psm1 # エンコーディング判定
├── CsvWriter.psm1        # CSV 出力
└── Logger.psm1           # ログ出力
```

### モジュール責務

| モジュール | 責務 |
|-----------|------|
| `SourceList.ps1` | パラメータ検証・設定読み込み・各モジュール呼び出し・終了コード制御 |
| `FileScanner.psm1` | `Get-ChildItem` による再帰走査・除外フォルダ／拡張子フィルタ・言語種別判定 |
| `LineCounter.psm1` | 行単位のループ・空行／コメント行／コード行の分類・PL/SQL ブロックコメント状態管理 |
| `EncodingDetector.psm1` | BOM 検出・拡張子フォールバック・想定外エンコーディング判定 |
| `CsvWriter.psm1` | `Export-Csv` による一括書き込み・UTF-8 BOM付き出力 |
| `Logger.psm1` | タイムスタンプ付きログ行の生成・コンソール出力＋ファイル追記 |

> 単体テスト容易性・責務分離の観点から、MVP 段階から 6 モジュール構成で実装する。

---

## 3. ファイル走査方式

### 使用コマンド

```powershell
Get-ChildItem -Path $RootPath -Recurse -File
```

### 除外フォルダの処理

`Get-ChildItem` の `-Exclude` は再帰走査では機能しないため、
走査結果をパス分解＋`-contains` で完全一致フィルタリングする。
`-like` による部分一致は `output_archive` のような類似名フォルダの誤除外を招くため使用しない。

```powershell
$files = Get-ChildItem -Path $RootPath -Recurse -File | Where-Object {
    $parts = $_.FullName -split '\\'
    $excluded = $false
    foreach ($part in $parts) {
        if ($config.ExcludeFolders -contains $part) {
            $excluded = $true
            break
        }
    }
    -not $excluded
}
```

### 拡張子フィルタの適用順序

`functional-design.md` セクション2「拡張子判定の優先順位」に従う。

---

## 4. エンコーディング判定

### 判定フロー

```
先頭 4 バイトを読む（境界条件回避のため BOM が 3 バイトでも余裕を持って取得する）
  │
  ├─ EF BB BF → UTF-8 BOM付き   → [System.Text.Encoding]::UTF8
  ├─ FF FE    → UTF-16 LE       → [System.Text.Encoding]::Unicode
  ├─ FE FF    → UTF-16 BE       → 想定外 → スキップ
  │
  └─ BOM なし
        │
        ├─ PL/SQL 系拡張子（.sql / .pkb / .pks / .prc / .fnc / .trg / .vw）
        │     → Shift_JIS（CP932）
        │     → [System.Text.Encoding]::GetEncoding(932)
        │
        └─ それ以外（VB.NET 系）
              → UTF-8 BOM なし
              → New-Object System.Text.UTF8Encoding($false)
```

### PowerShell 5.1 固有の実装注意

| 操作 | 推奨方法 | 注意点 |
|------|---------|--------|
| BOM 検出 | `[System.IO.File]::ReadAllBytes` で先頭バイトを取得 | `Get-Content` では BOM 判定不可 |
| UTF-8 BOM付き読み込み | `Get-Content -Encoding UTF8` | PS 5.1 では BOM 付き UTF-8 として扱われる |
| BOM なし UTF-8 読み込み | `[System.IO.File]::ReadAllLines($path, $enc)` | `$enc = New-Object System.Text.UTF8Encoding($false)` |
| Shift_JIS 読み込み | `[System.IO.File]::ReadAllLines($path, $enc)` | `$enc = [System.Text.Encoding]::GetEncoding(932)` |
| UTF-16 LE 読み込み | `[System.IO.File]::ReadAllLines($path, $enc)` | `$enc = [System.Text.Encoding]::Unicode` |

---

## 5. コメント判定ステートマシン

### VB.NET

VB.NET はブロックコメントを持たないため、状態管理不要。行ごとに独立して判定する。

```
行頭（TrimStart 後）が以下のいずれかに該当 → コメント行
  - "'" で始まる
  - "REM " で始まる（大小文字不問）
  - "REM" と完全一致（大小文字不問）
```

### PL/SQL

PL/SQL はブロックコメントが複数行にまたがるため、**ステートマシン**で管理する。

#### 状態定義

| 状態 | 説明 |
|------|------|
| `CODE` | 通常のコード処理中 |
| `BLOCK_COMMENT` | `/* … */` ブロックコメント内 |

#### 状態遷移

```
【CODE 状態】
  行頭（TrimStart 後）が "--" で始まる
    → コメント行・状態は CODE のまま

  行頭（TrimStart 後）が "/*" で始まる場合は以下の 4 パターンで分岐する（補足表参照）

  上記以外 → コード行

【BLOCK_COMMENT 状態】
  行内に "*/" が出現
    → CODE 状態へ遷移
    → その行はコメント行として扱う

  "*/" が出現しない → コメント行・状態は BLOCK_COMMENT のまま

> BLOCK_COMMENT 状態中に "--" が出現してもコメント行であり、状態は変わらない
> （ブロックコメントの一部として扱う）。
> ブロックコメントのネスト（/* /* */ */）は非対応。最初の */ で CODE 状態に戻る。
```

#### 1行完結ブロックコメントの 4 パターン分類

| # | パターン | 例 | 分類 | 状態遷移 |
|---|---------|-----|------|---------|
| 1 | 行頭が `/*` で始まり、同行内に `*/` あり（1行完結） | `/* コメント */` | コメント行 | CODE のまま |
| 2 | 行頭が `/*` で始まり、`*/` の後にコードが続く | `/* メモ */ x := 1;` | コード行 | CODE のまま |
| 3 | 行頭がコードで、行内に `/* … */` を含む（混在行） | `x := 1; /* メモ */` | コード行 | CODE のまま |
| 4 | 行頭が `/*` で始まり、同行内に `*/` なし | `/* コメント開始` | コメント行 | CODE → BLOCK_COMMENT |

> パターン2・3 は `functional-design.md` セクション4「混在行はコード行扱い」と整合する。

#### MVP 制限事項

- 文字列リテラル内のコメント記号（例: `Dim s = "-- not a comment"`）を誤ってコメントと判定する可能性がある
- PL/SQL のブロックコメント（`/* … */`）が文字列リテラル内に現れる場合も同様
- 誤判定が発生した場合、実際より `CommentLines` が多くカウントされる方向にずれる

---

## 6. CSV 出力実装方針

### Export-Csv による一括書き込み

```powershell
$results | Export-Csv -Path $csvPath -Encoding UTF8 -NoTypeInformation
```

> PowerShell 5.1 の `Export-Csv -Encoding UTF8` は BOM 付き UTF-8 を出力する（PS 7 では BOM なし。本ツールは PS 5.1 専用のため問題なし）。
> また PS 5.1 の `Export-Csv` はすべての値を一律ダブルクォートで囲む。RFC 4180 は「必要な場合のみ囲む」を推奨するが「囲んでも良い」とも規定しており、`functional-design.md` の RFC 4180 準拠ルールの許容範囲内と見なす。

### 行数系カラムが空の行（SKIPPED）

`$null` を格納したプロパティは `Export-Csv` で空文字として出力される。
これを利用して SKIPPED ファイルの行数系カラムを空文字にする。

---

## 7. パフォーマンス方針

| 項目 | 方針 |
|------|------|
| 想定最大規模 | 10 万ファイル以下 |
| メモリ方式 | 全結果をメモリ上の配列（`[System.Collections.Generic.List[PSObject]]`）に保持し、完了後に一括 `Export-Csv` |
| 進捗表示 | 1,000 件ごとにコンソール＋ログに出力（`Write-Host` / ログ追記） |
| ファイル読み込み | 行単位（`ReadAllLines`）。巨大ファイルでもストリーミング不要（行数カウントが目的のため全行読み込みが前提） |
| 最大ファイルサイズ | 50 MB。超過ファイルはスキップ（CSV に `SKIPPED`、ログに `WARN`） |

---

## 8. 技術的制約まとめ

| 制約 | 詳細 |
|------|------|
| PowerShell 5.1 限定 | `??`（null 合体）・`ForEach-Object -Parallel` など PS7 構文は使用しない |
| 標準コマンドのみ | `Install-Module` 不要。`Import-Module` は `src\` 内の自作 `.psm1` のみ許可 |
| ネットワーク非依存 | `Invoke-WebRequest` / `Invoke-RestMethod` は使用しない |
| 文字コード出力固定 | 出力 CSV・ログは常に UTF-8 BOM付き CRLF |
| スクリプト自身の文字コード | `SourceList.ps1` および `.psm1` は **UTF-8 BOM付き** で保存（PS 5.1 で日本語コメントが化けないように） |

---

## 9. 実行モデルと運用前提

### カレントディレクトリ依存

`SourceList.ps1` の起動パラメータ既定値（`-ConfigPath` / `-OutputDir` / `-LogDir`）は **カレントディレクトリ相対パス** で解決される。

| パス | 解決基準 | 備考 |
|------|---------|------|
| モジュール Import-Module（`Logger.psm1` 等） | `$PSScriptRoot`（`src\` フォルダ） | スクリプト配置場所が固定のため安全 |
| `.\config\settings.psd1` / `.\output` / `.\logs` | カレントディレクトリ | 既定値パラメータが `.\` 相対 |

### 実行方法

**SourceList.ps1 はリポジトリルートをカレントディレクトリとして実行すること。**

```powershell
cd C:\Repos\SourceList
.\src\SourceList.ps1 -RootPath C:\Projects\MyApp
```

### v10 での解消

v10 で `-ConfigPath` / `-OutputDir` / `-LogDir` にフルパス指定できるようになると、カレントディレクトリ依存が解消される。
