# ユビキタス言語定義（glossary.md）

> 本ドキュメントは SourceList プロジェクトで使用する用語を一元化する永続的ドキュメントです。
> 用語の定義はここを正とし、他ドキュメントとの不整合があれば本ドキュメントに合わせる。

---

## 1. プロジェクト・対象資産

| 用語（日本語） | 別名・英語 | 定義 | 出典 |
|--------------|-----------|------|------|
| SourceList | — | 本プロジェクトのツール名。VB.NET / PL/SQL ソース資産を棚卸しし CSV に出力する PowerShell 5.1 スクリプト | product-requirements.md §1, CLAUDE.md |
| ソース資産棚卸し | — | 指定フォルダ配下のソースファイルを網羅的に一覧化し、規模感（行数・コメント数）を数値で見える化すること | product-requirements.md §1 |
| 走査ルート | RootPath | `SourceList.ps1` の `-RootPath` パラメータで指定するフォルダ。再帰走査の起点となる。スクリプト内にハードコードしない | functional-design.md §1 |
| 対象資産 | — | 走査ルート配下の VB.NET 系ファイルおよび PL/SQL 系ファイル全体。バイナリは含まない | product-requirements.md §3 |
| MVP | Minimum Viable Product | 最小実行可能プロダクト。本プロジェクトでは丸山利和専用の初期バージョン（v0.1）を指す | product-requirements.md §2 |

---

## 2. 言語・ファイル種別

| 用語（日本語） | 別名・英語 | 定義 | 出典 |
|--------------|-----------|------|------|
| VB.NET | VBNET | Visual Studio 2017 で構築した画面アプリケーションの実装言語。本ツールでは `.vb` を中心にバイナリ以外の全拡張子を対象とする | product-requirements.md §3 |
| PL/SQL | PLSQL | Oracle 向け SQL 拡張言語。バッチアプリケーション、および画面アプリから呼び出されるものを含む。`.sql` / `.pkb` / `.pks` / `.prc` / `.fnc` / `.trg` / `.vw` を対象とする | product-requirements.md §3 |
| Language 値 | — | CSV の `Language` カラムに格納する文字列。`VBNET` / `PLSQL` / `OTHER` / `SKIPPED` の 4 値のいずれか | functional-design.md §6 |
| OTHER | — | VbNetExtensions にも PlSqlExtensions にも該当しない拡張子のファイルに付与する Language 値。行数カウントは行う | functional-design.md §2 |
| SKIPPED | — | バイナリ拡張子・想定外エンコーディング・読み込み例外などの理由でスキップされたファイルに付与する Language 値。行数系カラムは空文字とする | functional-design.md §6, §7 |
| バイナリファイル | — | `.exe` / `.dll` / `.png` / `.zip` など、テキストエディタで正常に読めない形式のファイル。ExcludeExtensions に定義し走査対象から除外する | product-requirements.md §3 |
| テキストファイル | — | テキストエディタで読み書き可能なファイル。VB.NET 系・PL/SQL 系を含む。本ツールの処理対象 | product-requirements.md §3 |

---

## 3. 行数カウント

| 用語（日本語） | 別名・英語 | 定義 | 出典 |
|--------------|-----------|------|------|
| 物理行 | Physical Line | ファイル内の改行文字で区切られた行の数。最終行に改行がなくても 1 行と数える。本ツールの「行」は常に物理行を指す（→ 論理行も参照） | product-requirements.md §5 FR-04 |
| 論理行 | — | 複数の物理行にまたがる 1 つの文（例: VB.NET の行継続文字 `_` を使った記述）。本ツールでは論理行を扱わず、物理行のみを対象とする | — |
| 総行数 | Lines | ファイル全体の物理行数。CSV の `Lines` カラムに格納する | functional-design.md §6 |
| コメント行数 | CommentLines | コメントのみを含む物理行の数。混在行はコード行として扱うためコメント行数に含まない。CSV の `CommentLines` カラムに格納する | functional-design.md §4, §6 |
| 空行数 | BlankLines | 半角スペース・タブ・全角スペース（　）・改行文字以外の文字を含まない行の数。参考値として CSV の `BlankLines` カラムに格納する | functional-design.md §4, §6 |
| コメント行 | — | TrimStart 後の行全体がコメント記号で始まる物理行。CommentLines としてカウントする | functional-design.md §4 |
| コード行 | — | 空行でもコメント行でもない物理行。コードのみの行と混在行の両方を含む。CommentLines にはカウントしない | functional-design.md §4 |
| 混在行 | — | コードとコメントが同一物理行に存在する行（例: `Dim x As Integer ' 変数宣言`）。**コード行として分類し、CommentLines にはカウントしない** | functional-design.md §4, architecture.md §5 |
| 最終行改行なし | — | ファイルの最終行に改行文字がない状態。それでも 1 行として総行数に含める | product-requirements.md §5 FR-04 |

---

## 4. コメント判定

| 用語（日本語） | 別名・英語 | 定義 | 出典 |
|--------------|-----------|------|------|
| コメント記号 | — | コメント開始を示す文字列。VB.NET では `'` と `REM`、PL/SQL では `--` と `/*`／`*/` | architecture.md §5 |
| 単一行コメント（VB.NET） | — | 行頭（TrimStart 後）が `'` または `REM`（大小文字不問）で始まる行。その行全体をコメント行として扱う | architecture.md §5 |
| 単一行コメント（PL/SQL） | 行コメント | 行頭（TrimStart 後）が `--` で始まる行。行の途中に `--` が現れる場合はコード行扱い | architecture.md §5 |
| ブロックコメント | — | PL/SQL の `/* … */` で囲まれたコメント。複数行にまたがる場合はステートマシンで継続判定する（→ §11 ステートマシン・CODE 状態・BLOCK_COMMENT 状態を参照） | architecture.md §5 |
| TrimStart | 行頭空白除去 | 行の先頭にある半角スペース・タブを取り除く操作。コメント記号の判定前に必ず適用する | architecture.md §5 |
| 行頭判定 | — | TrimStart 後の文字列がコメント記号で始まるかどうかを確認すること | architecture.md §5 |
| 1行完結ブロックコメント | — | `/* コメント */` のように同一行内で開始と終了が完結するブロックコメント。4パターン分類表（architecture.md §5）に従って処理する | architecture.md §5 |
| インラインコメント | — | コード行の途中に書かれたコメント部分（例: `x := 1; /* メモ */` の `/* メモ */` 部分）。その行は混在行として分類され、コード行扱いとなる（→ §3 混在行を参照） | architecture.md §5, functional-design.md §4 |
| 文字列リテラル内コメント記号 | — | `"-- not a comment"` のように文字列の中にコメント記号が含まれる場合。MVP では誤検出の可能性があり制限事項として明記する。誤判定の方向は CommentLines の過大カウント | functional-design.md §4, architecture.md §5 |

---

## 5. 文字エンコーディング

| 用語（日本語） | 別名・英語 | 定義 | 出典 |
|--------------|-----------|------|------|
| BOM | Byte Order Mark | ファイル先頭に付与されるバイト列。エンコーディングの識別に使う。`EF BB BF`（UTF-8）/ `FF FE`（UTF-16 LE）が主な対象 | architecture.md §4 |
| BOM 検出 | エンコーディング判定（第一優先） | ファイル先頭 4 バイトを読み取り、BOM の有無とエンコーディングを判定する処理。BOM なしの場合は拡張子フォールバックへ進む | architecture.md §4 |
| UTF-8 BOM付き | UTF-8 with BOM | 先頭バイトが `EF BB BF` の UTF-8 ファイル。VB.NET 系ソース、本ツールの出力 CSV・ログで使用。PS 5.1 の `Get-Content -Encoding UTF8` はこの形式を扱う | architecture.md §4 |
| UTF-8 BOM なし | UTF-8 without BOM | BOM のない UTF-8 ファイル。VB.NET 系で BOM なしの場合はこのエンコーディングと判定する。`New-Object System.Text.UTF8Encoding($false)` で読み込む | architecture.md §4 |
| UTF-16 LE | UTF-16N | 先頭バイトが `FF FE` のファイル。VB.NET 系で稀に出現する。`[System.Text.Encoding]::Unicode` で読み込む | architecture.md §4 |
| UTF-16 BE | — | 先頭バイトが `FE FF` のファイル。本プロジェクトでは想定外エンコーディングとして扱い、スキップする | architecture.md §4 |
| Shift_JIS | CP932, sjis | Windows 拡張 Shift_JIS（コードページ 932）。PL/SQL 系ファイルの既定エンコーディング。`[System.Text.Encoding]::GetEncoding(932)` で読み込む | architecture.md §4 |
| 想定外エンコーディング | — | UTF-16 BE・BOM なし UTF-16 など、本ツールが処理対象としないエンコーディング。対象ファイルをスキップし CSV に SKIPPED で記録、ログに SKIP レベルで記録する | product-requirements.md §5 FR-06 |

---

## 6. ファイル走査・除外

| 用語（日本語） | 別名・英語 | 定義 | 出典 |
|--------------|-----------|------|------|
| 再帰走査 | — | `Get-ChildItem -Recurse -File` によって走査ルート配下のすべてのファイルを再帰的に列挙すること | architecture.md §3 |
| 拡張子フィルタリング | — | ファイルの拡張子をもとに対象・除外を判定する処理。ExcludeExtensions → PlSqlExtensions → VbNetExtensions → OTHER の優先順位で適用する | functional-design.md §2 |
| 除外拡張子 | ExcludeExtensions | スキップ対象のバイナリ拡張子リスト。`settings.psd1` で定義する。拡張子判定の最優先で評価する | functional-design.md §2 |
| 除外フォルダ | ExcludeFolders | 走査対象から除外するフォルダ名のリスト。フォルダ名の完全一致（`-contains`）で判定する。`settings.psd1` で定義する | functional-design.md §2 |
| 自己参照防止 | — | `output` / `logs` / `.steering` など、ツール自身の生成物・作業フォルダを ExcludeFolders に含め、走査対象から除外すること。二重カウントを防ぐ目的 | functional-design.md §2 |
| 完全一致フィルタ | — | パスを `\\` で分割し、各フォルダ名が ExcludeFolders リストに含まれるかを `-contains` で判定する方式。`-like` による部分一致（`output_archive` の誤除外）を防ぐ | architecture.md §3 |
| スキップ | — | ファイルを処理対象から除外すること。ExcludeFolders 配下は CSV にも記録しない。バイナリ等は CSV に `SKIPPED` で記録し、ログに `SKIP` レベルで記録する | functional-design.md §7 |
| 最大ファイルサイズ | — | 本ツールが処理するファイルの上限サイズ。50 MB 超のファイルはスキップし、CSV に `SKIPPED`、ログに `WARN` で記録する | architecture.md §7 |

---

## 7. CSV 出力

| 用語（日本語） | 別名・英語 | 定義 | 出典 |
|--------------|-----------|------|------|
| 出力 CSV | SourceList CSV | `output\SourceList_yyyyMMdd_HHmmss.csv` に生成する本ツールの主要成果物。実行のたびに新規生成し上書きしない | functional-design.md §6 |
| RFC 4180 | — | CSV フォーマットの事実上の標準仕様。カンマ区切り・ダブルクォート囲み・CRLF 改行・エスケープ規則（`"` → `""`）を定める | functional-design.md §6 |
| CRLF | — | `\r\n`（キャリッジリターン＋ラインフィード）。本ツールの CSV・ログの改行コード。Windows / Excel 互換 | functional-design.md §6 |
| ダブルクォート囲み | — | CSV の各値をダブルクォート（`"`）で囲む方式。PS 5.1 の `Export-Csv` は一律ダブルクォートで囲む（RFC 4180 許容範囲内） | architecture.md §6 |
| ヘッダ行 | — | CSV の 1 行目。カラム名を記述する。`-NoTypeInformation` により PS の型情報行（`#TYPE …`）は出力しない | development-guidelines.md §2 |
| 行数系カラム | — | CSV の `Lines` / `CommentLines` / `BlankLines` カラムの総称。SKIPPED ファイルでは空文字を格納する | functional-design.md §6, §7 |
| 一括書き込み | Export-Csv | 走査完了後にメモリ上の全結果を `Export-Csv` で一度に書き込む方式。想定最大規模 10 万ファイルを前提とする | architecture.md §6, §7 |

---

## 8. ログ

| 用語（日本語） | 別名・英語 | 定義 | 出典 |
|--------------|-----------|------|------|
| ログファイル | — | `logs\SourceList_yyyyMMdd_HHmmss.log` に生成する実行ログ。UTF-8 BOM付き CRLF。実行のたびに新規生成し上書きしない | functional-design.md §5 |
| ログレベル | — | ログ行の種別を示すラベル。`INFO` / `WARN` / `SKIP` / `ERROR` の 4 値 | functional-design.md §5 |
| INFO | — | 正常な処理の節目（走査開始・完了・進捗・CSV 出力完了）を記録するログレベル | functional-design.md §5 |
| WARN | — | 処理は続行できるが注意が必要な事象（設定ファイル不在・デフォルト使用・50 MB 超えファイルなど）を記録するログレベル | functional-design.md §5, architecture.md §7 |
| SKIP | — | ファイルをスキップした理由（バイナリ・想定外エンコーディング・読み込みエラー）を記録するログレベル | functional-design.md §5 |
| ERROR | — | 処理継続不能なエラー（RootPath 不在・出力ディレクトリ作成失敗など）を記録するログレベル。終了コード 1 で終了する | functional-design.md §5, §7 |
| サマリログ | — | 走査完了時に出力する集計情報。言語別処理件数とスキップ理由別件数の内訳を含む | functional-design.md §5 |
| 進捗ログ | 進捗表示 | 1,000 件ごとにコンソール（標準出力）とログファイルの両方に出力する処理件数の表示 | functional-design.md §5, product-requirements.md §5 FR-09 |

---

## 9. 設定ファイル

| 用語（日本語） | 別名・英語 | 定義 | 出典 |
|--------------|-----------|------|------|
| settings.psd1 | — | `config\settings.psd1` に配置する設定ファイル。対象拡張子・除外拡張子・除外フォルダを定義する。リポジトリに既定値で同梱する | functional-design.md §2 |
| PowerShell Data File | .psd1 | `@{ Key = Value }` 形式のハッシュテーブルを記述するファイル形式。`Import-PowerShellDataFile` で読み込む。PS 5.1 標準サポート | functional-design.md §2 |
| VbNetExtensions | — | VB.NET 系として扱う拡張子のリスト。`settings.psd1` で定義する。PlSqlExtensions より後に評価する | functional-design.md §2 |
| PlSqlExtensions | — | PL/SQL 系として扱う拡張子のリスト。`settings.psd1` で定義する。VbNetExtensions より優先して評価する | functional-design.md §2 |
| ExcludeExtensions | — | スキップ対象のバイナリ拡張子リスト。`settings.psd1` で定義する。拡張子判定の最優先で評価する | functional-design.md §2 |
| ExcludeFolders | — | 走査から除外するフォルダ名リスト。`settings.psd1` で定義する。完全一致（`-contains`）で判定する | functional-design.md §2 |
| デフォルト値 | — | `settings.psd1` が存在しない場合にスクリプト内定数として使用する各設定の初期値。警告をログに記録したうえで続行する | functional-design.md §2 |

---

## 10. スペック駆動開発・運用

| 用語（日本語） | 別名・英語 | 定義 | 出典 |
|--------------|-----------|------|------|
| 永続的ドキュメント | — | `docs/` 配下に配置する、アプリケーション全体の「何を作るか」「どう作るか」を定義するドキュメント群。基本設計が変わらない限り更新しない | repository-structure.md §2 |
| ステアリングファイル | steering | `.steering/<日付-バージョン-タスク名>/` 配下に配置する作業単位の実装計画ドキュメント。`requirements.md` / `design.md` / `tasklist.md` の 3 点セット | repository-structure.md §2, CLAUDE.md |
| requirements.md | — | ステアリングファイルの 1 つ。今回の作業の要求内容（変更・追加する機能の説明・受け入れ条件・制約事項）を記述する | CLAUDE.md |
| design.md | — | ステアリングファイルの 1 つ。変更内容の設計（実装アプローチ・変更するコンポーネント・影響範囲）を記述する | CLAUDE.md |
| tasklist.md | — | ステアリングファイルの 1 つ。具体的な実装タスクと進捗状況を管理するチェックリスト | CLAUDE.md, repository-structure.md §4 |
| ユビキタス言語 | Ubiquitous Language | DDD（ドメイン駆動設計）の概念。プロジェクト内で同じ概念を同じ名前で呼ぶことを徹底し、解釈の揺れを防ぐ。本ドキュメントがその定義の正とする | 本ドキュメント |
| ゴールデンマスター方式 | — | v0.1 完成時点の実行出力を目視レビューで承認して `tests/expected/` に固定し、以降の変更との差分を検証する手動テスト方式 | development-guidelines.md §3 |
| 期待値 CSV | — | `tests/expected/` に配置する、手動検証で正解となる CSV ファイル。ゴールデンマスターとして Git 管理する | development-guidelines.md §3, repository-structure.md §2 |

---

## 11. アーキテクチャ・実装

| 用語（日本語） | 別名・英語 | 定義 | 出典 |
|--------------|-----------|------|------|
| ステートマシン | State Machine | PL/SQL ブロックコメント判定で使用する状態管理の仕組み。`CODE` 状態と `BLOCK_COMMENT` 状態の 2 値を持ち、行ごとに遷移する | architecture.md §5 |
| CODE 状態 | — | ステートマシンの初期状態。通常のコードを処理中であることを示す。行頭が `/*` のパターンに応じて `BLOCK_COMMENT` 状態に遷移する場合がある | architecture.md §5 |
| BLOCK_COMMENT 状態 | — | ステートマシンの状態の 1 つ。`/*` を検出してから `*/` を検出するまでの間、ブロックコメント内を処理中であることを示す。この状態中の `--` はコメントの一部として扱い状態は変わらない | architecture.md §5 |
| モジュール | .psm1 | `src\` 配下の PowerShell モジュールファイル。各モジュールは単一の責務を持ち、`Export-ModuleMember` で公開関数を明示する | architecture.md §2 |
| 6モジュール構成 | — | MVP 段階から採用するスクリプト分割方針。`SourceList.ps1`（エントリポイント）+ `FileScanner.psm1` / `LineCounter.psm1` / `EncodingDetector.psm1` / `CsvWriter.psm1` / `Logger.psm1` の 6 ファイル構成。単体テスト容易性・責務分離が採用理由 | architecture.md §2 |
| エントリポイント | — | `src\SourceList.ps1`。パラメータ検証・設定読み込み・各モジュール呼び出し・終了コード制御を担う | architecture.md §2 |
| 終了コード | Exit Code | スクリプト終了時に返す数値。`0`（正常終了・スキップあり含む）/ `1`（異常終了）の 2 値 | functional-design.md §1 |
| $ErrorActionPreference | — | PowerShell の組み込み変数。`'Stop'` に設定することで未処理例外を `catch` ブロックに落とす。`SourceList.ps1` および各 `.psm1` の先頭に設定する。スコープごとに独立して評価されるため各ファイルに個別設定が必要 | development-guidelines.md §1 |
| Export-ModuleMember | — | `.psm1` 内で外部に公開する関数を明示的に宣言するコマンド。意図しない関数の公開を防ぐ | development-guidelines.md §1 |
| Verb-Noun 形式 | 動詞-名詞 形式 | PowerShell の関数命名規約。`Get-FileEncoding` / `Write-LogMessage` のように `動詞-名詞` の形式で命名する。動詞は PowerShell 標準動詞（`Get-Verb` で一覧確認可能）を使う | development-guidelines.md §1 |
| 終了コード 0 | — | 正常終了。スキップファイルが存在しても正常終了とする | functional-design.md §1 |
| 終了コード 1 | — | 異常終了。RootPath 不在・出力ディレクトリ作成失敗・CSV 書き込み失敗など処理継続不能なエラーで返す | functional-design.md §1, §7 |
