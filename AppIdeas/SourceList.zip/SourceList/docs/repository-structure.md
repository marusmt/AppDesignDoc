# リポジトリ構造定義書（repository-structure.md）

> 本ドキュメントは SourceList のリポジトリ構造・各ディレクトリの役割・ファイル配置ルールを定義する永続的ドキュメントです。

---

## 1. ディレクトリ構成

```
SourceList/                        # リポジトリルート
├── src/                           # PowerShell スクリプト本体
│   ├── SourceList.ps1             # エントリポイント
│   ├── FileScanner.psm1           # フォルダ走査・拡張子フィルタ
│   ├── LineCounter.psm1           # 行数カウント・コメント判定
│   ├── EncodingDetector.psm1      # エンコーディング判定
│   ├── CsvWriter.psm1             # CSV 出力
│   └── Logger.psm1                # ログ出力
│
├── config/                        # 設定ファイル
│   └── settings.psd1              # 対象拡張子・除外フォルダ定義（既定値同梱）
│
├── output/                        # CSV 出力先（Git 管理外）
│   └── SourceList_yyyyMMdd_HHmmss.csv
│
├── logs/                          # 実行ログ（Git 管理外）
│   └── SourceList_yyyyMMdd_HHmmss.log
│
├── tests/                         # 手動検証用サンプル
│   ├── vbnet/                     # VB.NET サンプルソース
│   ├── plsql/                     # PL/SQL サンプルソース
│   └── expected/                  # 期待値 CSV
│
├── docs/                          # 永続的ドキュメント
│   ├── ideas/                     # 壁打ち・アイデアメモ（自由形式）
│   ├── product-requirements.md    # プロダクト要求定義書
│   ├── functional-design.md       # 機能設計書
│   ├── architecture.md            # 技術仕様書
│   ├── repository-structure.md    # 本ドキュメント
│   ├── development-guidelines.md  # 開発ガイドライン
│   └── glossary.md                # ユビキタス言語定義
│
├── .steering/                     # 作業単位の実装計画（履歴として Git 管理）
│   └── yyyyMMdd-vXX-タスク名/
│       ├── requirements.md
│       ├── design.md
│       └── sourcelist.md
│
├── .gitignore                     # Git 除外設定
├── CLAUDE.md                      # Claude Code 用プロジェクトメモリ
└── README.md                      # プロジェクト概要・使い方
```

---

## 2. 各ディレクトリの役割

### `src/`

PowerShell スクリプト本体を格納する。

| ファイル | 役割 |
|---------|------|
| `SourceList.ps1` | エントリポイント。パラメータ検証・設定読み込み・各モジュール呼び出し・終了コード制御 |
| `FileScanner.psm1` | 再帰走査・除外フォルダフィルタ・拡張子判定・言語種別判定 |
| `LineCounter.psm1` | 行単位分類（空行／コメント行／コード行）・PL/SQL ブロックコメント状態管理 |
| `EncodingDetector.psm1` | BOM 検出・拡張子フォールバック・想定外エンコーディング判定 |
| `CsvWriter.psm1` | `Export-Csv` による UTF-8 BOM付き一括書き込み |
| `Logger.psm1` | タイムスタンプ付きログ行生成・コンソール出力＋ファイル追記 |

**ファイル配置ルール:**
- すべてのファイルは **UTF-8 BOM付き** で保存する（PS 5.1 で日本語コメントが化けないように）
- `SourceList.ps1` と同じディレクトリに `.psm1` を置き、相対パスで `Import-Module` する

### `config/`

設定ファイルを格納する。`settings.psd1` はリポジトリに既定値で同梱する。

| ファイル | 役割 |
|---------|------|
| `settings.psd1` | 対象拡張子・除外拡張子・除外フォルダの定義（PowerShell Data File 形式） |

**ファイル配置ルール:**
- `settings.psd1` は Git 管理対象とする（既定値として同梱）
- ユーザーが編集した `settings.psd1` もそのままコミットしてよい

> 将来チームで使う場合は `config/settings.default.psd1`（コミット対象）と `config/settings.psd1`（`.gitignore` 対象）の二段構成への移行を検討する。

### `output/`

実行のたびに生成される CSV ファイルを蓄積する。

**ファイル配置ルール:**
- ファイル名は `SourceList_yyyyMMdd_HHmmss.csv` 形式（上書きなし・蓄積）
- `.gitignore` により Git 管理対象外（`output/*.csv` を除外）

### `logs/`

実行のたびに生成されるログファイルを蓄積する。

**ファイル配置ルール:**
- ファイル名は `SourceList_yyyyMMdd_HHmmss.log` 形式（上書きなし・蓄積）
- `.gitignore` により Git 管理対象外（`logs/*.log` を除外）

### `tests/`

手動検証用のサンプルソースと期待値 CSV を格納する。

| サブディレクトリ | 内容 |
|----------------|------|
| `tests/vbnet/` | VB.NET 系サンプルソース（コメント・空行・混在行など境界ケースを網羅） |
| `tests/plsql/` | PL/SQL 系サンプルソース（単一行コメント・ブロックコメント・ネスト等） |
| `tests/expected/` | 各サンプルに対応する期待値 CSV |

**ファイル配置ルール:**
- `tests/` 配下はすべて Git 管理対象とする
- `ExcludeFolders` には含めない（走査対象に含める）

**テスト実行時の生成物の扱い:**
- 期待値 CSV は `tests/expected/` に配置し Git 管理対象とする
- 実行結果 CSV は通常どおり `output/` に出力し、手動で期待値と差分確認する
- 将来 v1.1 でテストランナーを実装する際は `tests/actual/`（`.gitignore` 対象）への出力方式を検討する

### `docs/`

永続的ドキュメントを格納する。アプリケーションの基本設計が変わらない限り更新されない。

| ファイル | 内容 |
|---------|------|
| `ideas/` | 壁打ち・ブレインストーミングの成果物（自由形式） |
| `product-requirements.md` | プロダクト要求定義書 |
| `functional-design.md` | 機能設計書 |
| `architecture.md` | 技術仕様書 |
| `repository-structure.md` | 本ドキュメント |
| `development-guidelines.md` | 開発ガイドライン |
| `glossary.md` | ユビキタス言語定義 |

**ファイル配置ルール:**
- すべて Git 管理対象とする
- `ExcludeFolders` には含めない（走査対象に含める）

### `.steering/`

作業単位の実装計画を格納する。

**命名規則:** `yyyyMMdd-vXX-タスク名/`（例: `20260428-v01-file-enumeration`）

**ファイル配置ルール:**
- `ExcludeFolders` の既定値に含め、走査対象から除外する（自己参照防止）
- 作業完了後も履歴として保持し、Git 管理対象とする

---

## 3. Git 管理方針

### 管理対象（コミットする）

| 対象 | 理由 |
|------|------|
| `src/` 配下の全ファイル | スクリプト本体 |
| `config/settings.psd1` | 既定値として同梱 |
| `tests/` 配下の全ファイル | 検証サンプル・期待値 |
| `docs/` 配下の全ファイル | 永続的ドキュメント |
| `.gitignore` / `CLAUDE.md` / `README.md` | プロジェクト管理ファイル |
| `.steering/` 配下の全ファイル | 作業履歴として保持 |

### 管理対象外（`.gitignore` で除外）

| 対象 | 理由 |
|------|------|
| `output/*.csv` | 実行のたびに生成される成果物 |
| `logs/*.log` | 実行のたびに生成されるログ |
| `*.tmp` | 一時ファイル |
| `*.bak` / `*.swp` | エディタのバックアップ・スワップファイル |
| `.vscode/*`（`.vscode/settings.json`・`.vscode/extensions.json` は除く） | VS Code 個人設定（共有不要なもの） |
| `Thumbs.db` / `desktop.ini` | Windows が自動生成するファイル |

---

## 4. ファイル命名規則

| 種別 | 規則 | 例 |
|------|------|-----|
| PowerShell スクリプト | PascalCase + `.ps1` | `SourceList.ps1` |
| PowerShell モジュール | PascalCase + `.psm1` | `FileScanner.psm1` |
| 設定ファイル | 小文字 + `.psd1` | `settings.psd1` |
| 出力 CSV | `SourceList_yyyyMMdd_HHmmss.csv` | `SourceList_20260428_100000.csv` |
| 出力ログ | `SourceList_yyyyMMdd_HHmmss.log` | `SourceList_20260428_100000.log` |
| ドキュメント | kebab-case + `.md` | `functional-design.md` |
| ステアリングディレクトリ | `yyyyMMdd-vXX-タスク名` | `20260428-v01-file-enumeration` |
| テストサンプル | `<連番>_<内容>.<拡張子>` | `01_basic.vb` |
| 期待値 CSV | `<言語>_<連番>_<内容>.csv` | `vbnet_01_basic.csv` |
