# SourceList — ソース資産一覧化ツール

Visual Studio 2017 で構築した VB.NET／PL/SQL アプリケーションのソース資産を棚卸しし、
ファイル一覧・行数・コメント数を CSV に出力する PowerShell 5.1 スクリプトです。

## 目的

開発ツールのバージョンアップ時に影響範囲を客観的に把握するため、
現状のソース資産を網羅的に一覧化し、規模感（行数・コメント数）を数値で見える化します。

## 動作要件

- Windows（ローカル実行）
- PowerShell 5.1（Windows 標準）
- 外部モジュール・インターネット接続 **不要**

## ディレクトリ構成

```
SourceList/
├── src/          # PowerShell スクリプト本体
├── config/       # 対象拡張子・除外フォルダなどの設定ファイル
├── output/       # 生成された CSV ファイル（日時付きで蓄積）
├── logs/         # 実行ログ（スキップ理由・エラー内容）
├── tests/        # 手動検証用サンプルソースおよび期待値 CSV
├── docs/         # 設計ドキュメント
│   └── ideas/    # 壁打ち・アイデアメモ
└── .steering/    # 作業単位の実装計画（requirements / design / tasklist）
```

## 使い方（予定）

> ⚠️ **仕様策定中です。** コマンド引数・設定ファイル形式は `docs/functional-design.md` で確定します。以下は現時点の想定例です。

```powershell
# 基本的な実行
.\src\SourceList.ps1 -RootPath "C:\Projects\MyApp"

# 設定ファイルを指定して実行
.\src\SourceList.ps1 -RootPath "C:\Projects\MyApp" -ConfigPath ".\config\settings.psd1"
```

実行すると `output\SourceList_yyyyMMdd_HHmmss.csv` が生成されます。

> 設定ファイルの形式は `.psd1`（PowerShell Data File）を想定しています。ただし最終決定は `docs/functional-design.md` で行います。

## 入力ファイルの想定文字コード

| 対象 | 文字コード | 備考 |
|------|-----------|------|
| VB.NET 系（`.vb` など） | UTF-8 / UTF-8 BOM付き / UTF-16 LE | BOM 検出で先に切り分ける |
| PL/SQL 系（`.sql` など） | Shift_JIS（CP932） | 原則 BOM なし |
| 出力 CSV | UTF-8 BOM付き | Excel 取り込み互換 |

## カウント定義

**行数カウント**
- 総行数（Lines）: ファイル全体の物理行数（最終行に改行なしでも 1 行と数える）
- コメント行数（CommentLines）: コメントのみの行。コードとの混在行は除く
- 空行数（BlankLines）: 空白のみの行（参考値）

**コメント判定ルール**
- VB.NET: 行頭（空白除去後）が `'` または `REM`（大小文字不問）で始まる行
- PL/SQL: 行頭（空白除去後）が `--` で始まる行、または `/* … */` ブロック内の行
  - 行の途中の `--` はコード行扱い

## CSV 出力カラム

| カラム | 説明 |
|--------|------|
| FullPath | ファイルのフルパス |
| RelativePath | 走査ルートからの相対パス |
| FileName | ファイル名 |
| Extension | 拡張子（小文字） |
| Language | `VBNET` / `PLSQL` / `OTHER` |
| SizeBytes | ファイルサイズ（バイト） |
| Lines | 総行数 |
| CommentLines | コメント行数 |
| BlankLines | 空行数 |
| LastWriteTime | 最終更新日時（`yyyy-MM-dd HH:mm:ss`） |

フォーマット: **UTF-8 BOM付き** / カンマ区切り / ダブルクォート囲み / 改行 CRLF

## 対象ファイル

- **VB.NET 系:** `.vb` / `.vbproj` / `.sln` / `.resx` / `.config` / `.xml` など（バイナリ除く）
- **PL/SQL 系:** `.sql` / `.pkb` / `.pks` / `.prc` / `.fnc` / `.trg` / `.vw`
- **除外（バイナリ）:** `.exe` / `.dll` / `.png` / `.zip` など

## ライセンス・作者

- ライセンス: 未定（個人利用）
- 作者: 丸山利和
