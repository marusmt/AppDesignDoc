-- Shift_JIS サンプル（v01 では判定のみ。実際の Shift_JIS 変換は手動で実施）
SELECT 1 FROM DUAL;
