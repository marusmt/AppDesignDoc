/*
  複数行にまたがるブロックコメント
  2行目
  3行目
*/
SELECT 1 FROM DUAL;
