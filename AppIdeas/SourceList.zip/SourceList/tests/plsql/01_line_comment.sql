-- これは行頭コメントです
-- 2行目の行頭コメント
SELECT 1 FROM DUAL;
