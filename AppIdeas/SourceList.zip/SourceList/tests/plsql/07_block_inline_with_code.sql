x := 1; /* インラインコメント */ -- architecture.md パターン3
SELECT 1 FROM DUAL;
