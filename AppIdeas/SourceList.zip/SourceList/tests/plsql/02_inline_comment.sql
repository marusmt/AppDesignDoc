SELECT 1 FROM DUAL; -- 行中の -- はコード行扱い
SELECT 2 FROM DUAL; -- 別の混在行
