/* ブロック開始後にコードが続く場合はコード行扱い */ SELECT 1 FROM DUAL;
SELECT 2 FROM DUAL; /* 行末ブロックコメント */
