/* 1行完結のブロックコメント */
SELECT 1 FROM DUAL;
