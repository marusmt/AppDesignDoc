/*
  BLOCK_COMMENT 状態中の -- はブロックコメントの一部
  -- この行はコメントマーカーではない
*/
SELECT 1 FROM DUAL;
