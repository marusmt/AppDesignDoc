' UTF-16 LE サンプル（v01 では判定のみ。実際の UTF-16 変換は手動で実施）
Dim x As Integer = 1
