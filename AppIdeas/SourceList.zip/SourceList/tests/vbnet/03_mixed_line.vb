Dim x As Integer = 1 ' インラインコメント（コード行扱い）
Dim y As String = "hello" ' 別の混在行
