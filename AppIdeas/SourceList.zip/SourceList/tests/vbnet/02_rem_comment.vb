REM これは REM コメントです
rem 小文字の rem コメント
Rem 先頭大文字の Rem コメント
