' UTF-8 BOM付きファイルのサンプル（v01 では判定のみ）
Dim x As Integer = 1
