# 設計書（design.md）

> 作業単位: `.steering/20260429-v01-file-enumeration/`
> 対象バージョン: v0.1（MVP）
> 作成日: 2026-04-29

---

## 1. モジュール間依存関係

### 依存関係図

```
SourceList.ps1
├── Logger.psm1           ← 直接呼び出し（ログ出力）
├── FileScanner.psm1      ← LogCallback scriptblock を渡して呼び出し（B案）
├── EncodingDetector.psm1 ← Import-Module のみ（v01 では呼び出しなし）
├── LineCounter.psm1      ← Import-Module のみ（v01 では呼び出しなし）
└── CsvWriter.psm1        ← Import-Module のみ（v01 では呼び出しなし）

FileScanner.psm1
└── Logger.psm1           ← 直接 Import-Module 禁止。
                             SourceList.ps1 から渡される [scriptblock]$LogCallback 経由で間接ログ出力
```

### 設計方針

- **Logger は SourceList.ps1 が一元管理する。** FileScanner が Logger を直接 Import-Module することは禁止。
- **FileScanner の実行中ログ（走査進捗・SKIP）は LogCallback scriptblock 経由で行う（B案）。**
  SourceList.ps1 が `{ param($level, $msg) Write-LogMessage -Level $level -Message $msg -LogPath $logPath }` 相当の scriptblock を生成し、Get-SourceFiles に渡す。FileScanner 内では `if ($LogCallback) { & $LogCallback $level $msg }` で呼び出す。
- **EncodingDetector / LineCounter / CsvWriter は v01 では Import-Module のみ行い、各関数（Get-FileEncoding / Get-LineCounts / Export-SourceListCsv）は呼び出さない。** Import-Module 時にエラーが出ないこと（関数シグネチャが正しく定義されていること）のみを v01 で確認する。

---

## 2. 公開 API（関数シグネチャ）

### Logger.psm1: Write-LogMessage

```powershell
function Write-LogMessage {
    [CmdletBinding()]
    param(
        [ValidateSet('INFO', 'WARN', 'SKIP', 'ERROR')]
        [string]$Level,
        [string]$Message,
        [string]$LogPath   # ログファイルのフルパス
    )
}
Export-ModuleMember -Function Write-LogMessage
```

**出力形式:** `2026-04-29 10:00:00 [INFO ] メッセージ本文`
**動作:** `Write-Host` でコンソール出力 + `Add-Content` でファイル追記
**ファイル書き込み失敗時の挙動:** §5 を参照。

---

### FileScanner.psm1: Get-SourceFiles

```powershell
function Get-SourceFiles {
    [CmdletBinding()]
    [OutputType([System.Collections.Generic.List[PSObject]])]
    param(
        [string]$RootPath,
        [string[]]$ExcludeFolders,
        [string[]]$ExcludeExtensions,
        [string[]]$PlSqlExtensions,
        [string[]]$VbNetExtensions,
        [scriptblock]$LogCallback = $null  # B案: Logger 直接依存を避けるため
    )
}
Export-ModuleMember -Function Get-SourceFiles
```

**戻り値:** `requirements.md §3` で定義した PSCustomObject の List。

---

### EncodingDetector.psm1: Get-FileEncoding（シグネチャ確定のみ）

```powershell
function Get-FileEncoding {
    [CmdletBinding()]
    param(
        [string]$FilePath,
        [string]$DefaultEncoding = 'UTF-8'
    )
    # v02 で本実装。v01 では NotImplementedException をスロー。
    throw [System.NotImplementedException]::new('Get-FileEncoding は v02 で実装予定')
}
Export-ModuleMember -Function Get-FileEncoding
```

**戻り値スキーマ（v02 実装時の確定済み仕様）:**
```powershell
[PSCustomObject]@{
    Encoding    = [string]  # 'UTF-8-BOM' | 'UTF-8' | 'UTF-16LE' | 'Shift_JIS' | 'UNKNOWN'
    HasBom      = [bool]
    IsSupported = [bool]    # false = SKIPPED 対象
}
```

> **v01 での取り扱い:** SourceList.ps1 は v01 で Get-FileEncoding を呼び出さない。Import-Module で関数定義が読み込めることのみ確認する。

---

### LineCounter.psm1: Get-LineCounts（スタブ）

```powershell
function Get-LineCounts {
    [CmdletBinding()]
    param(
        [string]$FilePath,
        [string]$Language,
        [string]$Encoding
    )
    throw [System.NotImplementedException]::new('Get-LineCounts は v02 で実装予定')
}
Export-ModuleMember -Function Get-LineCounts
```

> **v01 での取り扱い:** SourceList.ps1 は v01 で Get-LineCounts を呼び出さない。Import-Module のみ。

---

### CsvWriter.psm1: Export-SourceListCsv（スタブ）

```powershell
function Export-SourceListCsv {
    [CmdletBinding()]
    param(
        [object[]]$Records,
        [string]$OutputPath
    )
    throw [System.NotImplementedException]::new('Export-SourceListCsv は v05 で実装予定')
}
Export-ModuleMember -Function Export-SourceListCsv
```

> **v01 での取り扱い:** SourceList.ps1 は v01 で Export-SourceListCsv を呼び出さない。Import-Module のみ。

---

## 3. settings.psd1 スキーマ詳細

```powershell
@{
    # VB.NET プロジェクト関連ファイルとして計上する拡張子（小文字・ドット付き）
    # ※ product-requirements.md §3「バイナリファイルを除く テキスト系の全拡張子 を対象とする」に基づき、
    #   .bat/.cmd/.ps1 等の VB.NET 言語以外のプロジェクト関連ファイルも含む（意図的）。
    VbNetExtensions = @(
        '.vb', '.vbproj', '.sln', '.resx', '.config', '.xml',
        '.xsd', '.xsl', '.xslt', '.txt', '.ini', '.bat', '.cmd',
        '.ps1', '.psm1', '.psd1', '.md', '.csv'
    )

    # PL/SQL ソースファイルとして計上する拡張子（小文字・ドット付き）
    PlSqlExtensions = @(
        '.sql', '.pkb', '.pks', '.prc', '.fnc', '.trg', '.vw'
    )

    # バイナリ・スキャン対象外の拡張子（Language=SKIPPED として配列に含める）
    ExcludeExtensions = @(
        '.exe', '.dll', '.pdb', '.lib', '.obj', '.bin', '.dat',
        '.png', '.jpg', '.jpeg', '.gif', '.bmp', '.ico', '.tif', '.tiff',
        '.zip', '.7z', '.rar', '.cab', '.msi', '.gz', '.tar',
        '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx'
    )

    # 除外するフォルダ名（パスセグメント単位で完全一致。前フィルタで降りない）
    ExcludeFolders = @(
        'bin', 'obj',
        '.git', '.vs',
        'node_modules',
        'output', 'logs',
        '.steering'
    )
}
```

### 拡張子判定の優先順位

ExcludeExtensions → PlSqlExtensions → VbNetExtensions → OTHER の順で評価し、最初に一致した分類を採用する。

---

## 4. ログフォーマット

### フォーマット

```
yyyy-MM-dd HH:mm:ss [LEVEL ] メッセージ本文
```

**LEVEL の幅:** 常に 5 文字固定（右スペース補填）。`INFO ` / `WARN ` / `SKIP ` / `ERROR`

### 出力例

```
2026-04-29 10:00:00 [INFO ] 走査を開始します。RootPath=C:\Projects\MyApp
2026-04-29 10:00:01 [SKIP ] スキップ（ExcludeExtensions）: C:\Projects\MyApp\bin\app.exe
2026-04-29 10:00:02 [SKIP ] スキップ（アクセスエラー）: C:\Projects\MyApp\locked.vb — アクセスが拒否されました
2026-04-29 10:00:05 [WARN ] settings.psd1 が見つかりません。ハードコード定数で続行します。
2026-04-29 10:00:10 [ERROR] RootPath が存在しません: C:\NotExist
```

### ファイル名規則

`SourceList_yyyyMMdd_HHmmss.log`（例: `SourceList_20260429_100000.log`）

### BOM の扱い

PS 5.1 の `Add-Content -Encoding UTF8` はファイル新規作成時のみ先頭に BOM を付加する。追記時は BOM なしで書き込まれるため、ログファイル全体で BOM は冒頭 1 回のみとなる。これは正常動作。

---

## 5. エラーハンドリング方針

### 基本方針

`$ErrorActionPreference = 'Stop'` を各 `.ps1` / `.psm1` ファイルの先頭に設定し、未処理例外を `catch` に落とす。

### SourceList.ps1 のエラー処理

```powershell
$ErrorActionPreference = 'Stop'
try {
    # 処理本体
} catch {
    Write-LogMessage -Level 'ERROR' -Message $_.Exception.Message -LogPath $logPath
    exit 1
}
```

異常終了時は必ず `exit 1` で終了コードを返す（`requirements.md §9` 参照）。

### Logger.psm1 のファイル書き込み失敗処理

```powershell
$ErrorActionPreference = 'Stop'
$Script:LogWriteFailed = $false   # モジュールスコープ。初回失敗時のみ true に設定。

function Write-LogMessage {
    [CmdletBinding()]
    param(
        [ValidateSet('INFO', 'WARN', 'SKIP', 'ERROR')]
        [string]$Level,
        [string]$Message,
        [string]$LogPath
    )
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "$timestamp [$($Level.PadRight(5))] $Message"

    Write-Host $line

    if (-not $Script:LogWriteFailed) {
        try {
            Add-Content -Path $LogPath -Value $line -Encoding UTF8
        } catch {
            $Script:LogWriteFailed = $true
            Write-Host "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') [WARN ] ログファイルへの書き込みに失敗しました。以降はコンソール出力のみ継続します。"
        }
    }
}
```

- 初回ファイル書き込み失敗時のみ `$Script:LogWriteFailed = $true` に設定し、Write-Host で警告を出力する。
- 2 回目以降はファイル書き込みを試行しない（ログ呼び出しごとに例外スタックが積み上がるのを防ぐ）。
- `$Script:LogWriteFailed` はモジュールロード時にリセットされるため、再実行時は自動的に初期状態に戻る。

### FileScanner.psm1 のエラー処理（個別ファイル）

個別ファイルのアクセスエラーは `try/catch` で捕捉し、Language=`SKIPPED` として配列に含めたうえで処理を継続する。SKIP ログにはエラー理由を付与し、ExcludeExtensions による意図的スキップと区別できるようにする（§8.E 参照）。

---

## 6. 拡張子優先判定ロジックと除外フォルダフィルタ（擬似コード）

### フォルダ走査方式：A案（自前再帰・前フィルタ）

`Get-ChildItem -Recurse` は列挙完了まで結果を返さないため、`bin`/`obj`/`node_modules` 配下に大量ファイルがある場合に性能問題が生じる（FR-09 大規模フォルダ対応）。
BFS キューで 1 階層ずつ展開し、ExcludeFolders に該当するディレクトリには降りない。

```powershell
function Get-SourceFiles {
    ...
    $results = [System.Collections.Generic.List[PSObject]]::new()
    $queue   = New-Object 'System.Collections.Generic.Queue[string]'
    $queue.Enqueue($RootPath.TrimEnd('\'))   # 末尾スラッシュを正規化

    while ($queue.Count -gt 0) {
        $currentDir = $queue.Dequeue()

        # ── このディレクトリのファイルを処理 ──────────────────────────
        $files = Get-ChildItem -Path $currentDir -File -ErrorAction SilentlyContinue
        foreach ($file in $files) {
            $ext = $file.Extension.ToLower()

            try {
                if ($ExcludeExtensions -contains $ext) {
                    $language = 'SKIPPED'
                    if ($LogCallback) { & $LogCallback 'SKIP' "スキップ（ExcludeExtensions）: $($file.FullName)" }
                } elseif ($PlSqlExtensions -contains $ext) {
                    $language = 'PLSQL'
                } elseif ($VbNetExtensions -contains $ext) {
                    $language = 'VBNET'
                } else {
                    $language = 'OTHER'
                }

                $results.Add([PSCustomObject]@{
                    FullPath      = $file.FullName
                    RelativePath  = $file.FullName.Substring($RootPath.TrimEnd('\').Length + 1)
                    FileName      = $file.Name
                    Extension     = $ext
                    Language      = $language
                    SizeBytes     = $file.Length
                    LastWriteTime = $file.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss')
                })
            } catch {
                # アクセスエラー等。Language=SKIPPED として記録し継続（§8.E 参照）
                if ($LogCallback) { & $LogCallback 'SKIP' "スキップ（アクセスエラー）: $($file.FullName) — $($_.Exception.Message)" }
                $results.Add([PSCustomObject]@{
                    FullPath      = $file.FullName
                    RelativePath  = ''
                    FileName      = $file.Name
                    Extension     = $ext
                    Language      = 'SKIPPED'
                    SizeBytes     = 0
                    LastWriteTime = ''
                })
            }
        }

        # ── サブディレクトリをキューに追加（ExcludeFolders は降りない）──
        $subdirs = Get-ChildItem -Path $currentDir -Directory -ErrorAction SilentlyContinue
        foreach ($dir in $subdirs) {            # ← このループ内の continue
            if ($ExcludeFolders -contains $dir.Name) {
                if ($LogCallback) { & $LogCallback 'INFO' "除外フォルダをスキップ: $($dir.FullName)" }
                continue                         # ← foreach ($dir in $subdirs) の次要素へ
            }
            $queue.Enqueue($dir.FullName)
        }
    }

    return $results
}
```

**`-contains` で完全一致** を使う理由: `-like '*output*'` にすると `output_archive` 等が意図せず除外される。
**`$dir.Name` で照合** するため、パス中のどの階層にある `bin` フォルダも同様に除外される。
**末尾スラッシュ正規化:** `$RootPath.TrimEnd('\')` で正規化後に `Substring(Length + 1)` することで、相対パスの先頭スラッシュを安定して除去する。

---

## 7. 起動シーケンス（ディレクトリ自動作成）

SourceList.ps1 の処理順序：

```
【コンソール出力のみ（Logger 未ロード）】
  ①  パラメータ検証（-RootPath の存在確認）
      └─ 失敗 → Write-Host で ERROR 出力 → exit 1
  ②  LogDir 作成（未存在時: New-Item -ItemType Directory -Force）
      + ログファイルパス決定（SourceList_yyyyMMdd_HHmmss.log）
      + Import-Module Logger.psm1
      ここからファイルへのログ出力が有効になる

【ファイルログ + コンソール出力】
  ③  設定ファイル読み込み（settings.psd1 → ハードコード定数フォールバック + WARN ログ）
  ④  OutputDir 作成（未存在時: New-Item -ItemType Directory -Force）
  ⑤  Import-Module（FileScanner / EncodingDetector / LineCounter / CsvWriter）
      ※ EncodingDetector / LineCounter / CsvWriter は関数定義の存在確認のみ。
         v01 では Get-FileEncoding / Get-LineCounts / Export-SourceListCsv を呼び出さない。
  ⑥  Get-SourceFiles 呼び出し（LogCallback 渡し）
  ⑦  サマリ出力（走査件数・言語別内訳）
  ⑧  exit 0
```

> **①〜② はコンソール出力のみ。** Logger の Import-Module が完了するまでファイルログは出力されない。
> Logger Import を ② に前倒しすることで、③ 設定ファイル読み込みの WARN ログをファイルに記録できる。

> **運用前提（A案）:** `.\config\settings.psd1` / `.\output` / `.\logs` はカレントディレクトリ相対パスで解決される。
> `$PSScriptRoot` ベース（スクリプト配置フォルダ相対）のモジュール Import-Module と基準ディレクトリが異なる点に注意。
> SourceList.ps1 は **リポジトリルートをカレントディレクトリとして実行すること**（例: `cd C:\Repos\SourceList && .\src\SourceList.ps1 -RootPath ...`）。
> v10 で `-ConfigPath` / `-OutputDir` / `-LogDir` にフルパス指定を可能にした際にこの制約を解消する。

---

## 8. 設計判断記録

### D. LastWriteTime の型：[string] 採用

`LastWriteTime` プロパティは `[DateTime]` ではなく `[string]`（`'yyyy-MM-dd HH:mm:ss'` 形式）として返す。
`Export-Csv` で DateTime 型を出力すると Excel 取り込み時に書式が環境依存でズレるため、文字列として固定形式で出力する。

### E. Language カラムへの SKIPPED 混在と v01 での方針

**v01 の決定:** ExcludeExtensions による意図的スキップとアクセスエラーによる事故的スキップを、どちらも `Language=SKIPPED` として扱う。CSV 上での区別は SKIP ログのメッセージ（`（ExcludeExtensions）` / `（アクセスエラー）`）で行う。

**既知の制限:** v05 で CSV 出力を実装した際に、意図的スキップと事故的スキップが同一カラム値となり区別できない問題が顕在化する。将来 `Status` カラムを分離する（`SCANNED` / `SKIPPED` / `ERROR`）ことを検討するが、v01 時点での schema 変更は行わない。

### F. -ConfigPath が指定された場合の v01 での挙動

`-ConfigPath` は v10 で完全対応予定（`requirements.md §5`）。v01 では `-ConfigPath` が指定されても無視し、WARN ログに記録したうえで通常の settings.psd1 読み込みへ進む。

### G. パス結合規約：Join-Path 限定

パスの文字列連結（`"$dir\$file"` など）は禁止。必ず `Join-Path` を使用する（`development-guidelines.md §1` 参照）。
擬似コード中の `$file.FullName.Substring(...)` は相対パス計算であり、パス結合ではないため許容する。

### H. テストサンプルファイルの配置方針

`tests/vbnet/` / `tests/plsql/` 配下に `development-guidelines.md §3` で定義したサンプルファイルを配置する。
v01 では走査対象として使用し、出力件数・言語別内訳を手動確認する（AC-01〜AC-07 検証）。
`tests/` 配下は `ExcludeFolders` に含めない（走査対象）。

### I. tests/vbnet/01_binary_skip.exe の取り扱い

`tests\vbnet\01_binary_skip.exe` は **0 バイトのダミーファイルを `.exe` にリネームしたもの**。実行可能ファイルとしての中身を持たないため、ウイルス対策ソフトの誤検知リスクは低い。

- 作成方法: `New-Item -Path "tests\vbnet\01_binary_skip.exe" -ItemType File`
- ウイルス対策ソフトが隔離した場合は除外設定を追加したうえで `git checkout` で復元する
