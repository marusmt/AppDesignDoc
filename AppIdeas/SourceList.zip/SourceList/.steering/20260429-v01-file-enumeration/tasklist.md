# タスクリスト（tasklist.md）

> 作業単位: `.steering/20260429-v01-file-enumeration/`
> 対象バージョン: v0.1（MVP）
> 作成日: 2026-04-29

---

## AC マッピング早見表

| AC    | 内容（概要）                                     | 対応タスク     |
| ----- | ------------------------------------------------ | -------------- |
| AC-01 | 走査件数・言語別内訳がコンソール＋ログに出力     | T4 + T7        |
| AC-02 | ExcludeFolders 配下が走査結果配列に含まれない    | T4 + T7        |
| AC-03 | ExcludeExtensions → Language=SKIPPED + SKIP ログ | T4 + T7        |
| AC-04 | その他拡張子 → Language=OTHER                    | T4 + T7        |
| AC-05 | -RootPath 不在 → exit 1 + ERROR ログ             | T3             |
| AC-06 | settings.psd1 不在 → フォールバック + WARN ログ  | T2 + T3        |
| AC-07 | PS 5.1 で追加モジュールなし実行                  | T3（部分）+ T7 |

---

## T1. Logger.psm1 実装

**依存:** なし（最初に実装する）

### 実装内容

- `src\Logger.psm1` を新規作成（UTF-8 BOM付き / CRLF / 4スペースインデント）
- `$ErrorActionPreference = 'Stop'` をファイル先頭に設定
- `$Script:LogWriteFailed = $false` をモジュールスコープに定義
- `Write-LogMessage` 関数を `design.md §2` のシグネチャで実装
  - `[ValidateSet('INFO','WARN','SKIP','ERROR')]` を付与
  - `Write-Host` でコンソール出力
  - `$Script:LogWriteFailed` が `$false` の場合のみ `Add-Content` でファイル追記
  - 初回書き込み失敗時に `$Script:LogWriteFailed = $true` + Write-Host 警告
- `Export-ModuleMember -Function Write-LogMessage` で明示エクスポート

### 完了条件

- [ ] `Import-Module .\src\Logger.psm1` でエラーが出ない
- [ ] `Write-LogMessage -Level 'INFO' -Message 'テスト' -LogPath '.\logs\test.log'` でコンソールに `yyyy-MM-dd HH:mm:ss [INFO ] テスト` 形式で出力される
- [ ] 同コマンドでログファイルが生成され、同一内容が書き込まれている
- [ ] 存在しないパスを `$LogPath` に指定した場合、Write-Host で WARN メッセージが出てコンソール出力のみ継続される
- [ ] `[ValidateSet]` が有効で、`-Level 'DEBUG'` 等の不正値でエラーが出る
- [ ] 不正な `$LogPath` で連続2回 `Write-LogMessage` を呼んだとき、WARN 通知が **1回だけ** 出力される（2回目以降は試行せず抑止）

---

## T2. config/settings.psd1 作成

**依存:** なし（T1 と並行可）

### 実装内容

- `config\settings.psd1` を新規作成（UTF-8 BOM付き / CRLF）
- `design.md §3` の完全スキーマを既定値で実装
  - `VbNetExtensions`（18拡張子）
  - `PlSqlExtensions`（7拡張子）
  - `ExcludeExtensions`（29拡張子）
  - `ExcludeFolders`（8フォルダ名）

### 完了条件

- [ ] `Import-PowerShellDataFile .\config\settings.psd1` でエラーが出ない
- [ ] 返されたハッシュテーブルに `VbNetExtensions` / `PlSqlExtensions` / `ExcludeExtensions` / `ExcludeFolders` の4キーが存在する
- [ ] `.vb` が `VbNetExtensions` に、`.sql` が `PlSqlExtensions` に含まれる
- [ ] `.exe` が `ExcludeExtensions` に、`bin` / `.steering` が `ExcludeFolders` に含まれる

---

## T5. スタブ3モジュール作成

**依存:** なし（T1 / T2 / T6 と並行可。ただし **T3 着手前には完了必須**）

> T3 の起動シーケンス ⑤ で3モジュールを Import-Module するため、T3 の動作確認前に完成している必要がある。

### 実装内容（各モジュール共通）

UTF-8 BOM付き / CRLF で作成。各ファイル先頭に `$ErrorActionPreference = 'Stop'`。

#### EncodingDetector.psm1

- `Get-FileEncoding` 関数（`design.md §2` のシグネチャ）
- 本体は `throw [System.NotImplementedException]::new('...')` のみ
- `Export-ModuleMember -Function Get-FileEncoding`

#### LineCounter.psm1

- `Get-LineCounts` 関数（`design.md §2` のシグネチャ）
- 本体は `throw [System.NotImplementedException]::new('...')` のみ
- `Export-ModuleMember -Function Get-LineCounts`

#### CsvWriter.psm1

- `Export-SourceListCsv` 関数（`design.md §2` のシグネチャ）
- 本体は `throw [System.NotImplementedException]::new('...')` のみ
- `Export-ModuleMember -Function Export-SourceListCsv`

### 完了条件

- [ ] `Import-Module .\src\EncodingDetector.psm1` でエラーが出ない
- [ ] `Import-Module .\src\LineCounter.psm1` でエラーが出ない
- [ ] `Import-Module .\src\CsvWriter.psm1` でエラーが出ない

---

## T3. SourceList.ps1 骨格実装

**依存:** T1（Logger）・T2（settings.psd1）・**T5（スタブ3モジュール）** 完了後

### 実装内容

- `src\SourceList.ps1` を新規作成（UTF-8 BOM付き / CRLF）
- `$ErrorActionPreference = 'Stop'` をファイル先頭に設定
- パラメータブロック定義（`-RootPath` / `-ConfigPath` / `-OutputDir` / `-LogDir`）
- `design.md §7` の起動シーケンス（①〜⑧）を実装
  - ① `-RootPath` の存在検証（失敗時 `exit 1`）
  - ② LogDir 作成 + ログファイルパス決定 + `Import-Module Logger.psm1`
  - ③ settings.psd1 読み込み（不在時 WARN ログ + ハードコード定数フォールバック）
    - `-ConfigPath` 指定時は WARN ログを出して無視（v01 での挙動）
  - ④ OutputDir 作成
  - ⑤ Import-Module 残4モジュール（FileScanner / EncodingDetector / LineCounter / CsvWriter）
  - ⑥ `Get-SourceFiles` 呼び出し（LogCallback 渡し）
  - ⑦ サマリ出力（総件数 / VBNET / PLSQL / OTHER / SKIPPED 各件数）
  - ⑧ `exit 0`
- ハードコード定数（`$Script:Default*`）をスクリプト先頭に定義

### 実装上の注意

- **`-RootPath` の存在検証は `Test-Path -Path $RootPath -PathType Container` を使用する**（ファイルパスを誤指定された場合に弾く）
- LogDir / OutputDir の作成には `Join-Path` を使用する（文字列連結禁止）
- `New-Item -ItemType Directory -Force` は既存ディレクトリに対してもエラーを出さない
- LogCallback scriptblock は `$logPath` 変数をクロージャとしてキャプチャする

### 完了条件

- [ ] **AC-05:** 存在しないパスを `-RootPath` に指定した場合、終了コード `1` で終了し、`ERROR` メッセージがコンソールに出力される
- [ ] **AC-05（ファイル指定）:** `-RootPath` にフォルダではなくファイルパスを指定した場合も終了コード `1` で終了する（`Test-Path -PathType Container` による弾き）
- [ ] **AC-06:** `config\settings.psd1` をリネームした状態で実行した場合、`WARN` ログが出てハードコード定数で処理が続行される
- [ ] `-LogDir` / `-OutputDir` で指定したディレクトリが未存在の場合、自動生成される
- [ ] ログファイル（`logs\SourceList_*.log`）が生成される
- [ ] **AC-07（部分検証）:** PS 5.1 で T3 完了状態のスケルトン（FileScanner は未実装のため T4 完了後でも可）を実行し、`Import-Module Logger.psm1` が成功して起動シーケンスが `exit 0` まで到達する

---

## T4. FileScanner.psm1 実装

**依存:** T3（SourceList.ps1 骨格）完了後

### 実装内容

- `src\FileScanner.psm1` を新規作成（UTF-8 BOM付き / CRLF）
- `$ErrorActionPreference = 'Stop'` をファイル先頭に設定
- `Get-SourceFiles` 関数を `design.md §2・§6` のシグネチャ・擬似コードで実装
  - BFS キューによる自前再帰（前フィルタ）
  - `$RootPath.TrimEnd('\')` で末尾スラッシュを正規化してから処理
  - ExcludeFolders は `$dir.Name` で完全一致（`-contains`）
  - 拡張子優先順位: ExcludeExtensions → PlSqlExtensions → VbNetExtensions → OTHER
  - アクセスエラー時は `Language=SKIPPED` + SKIP ログ（`（アクセスエラー）` プレフィックス）
  - `[OutputType([System.Collections.Generic.List[PSObject]])]` を付与
- `Export-ModuleMember -Function Get-SourceFiles` で明示エクスポート

### 実装上の注意

- `New-Object 'System.Collections.Generic.Queue[string]'` を使用（PS 5.1 でジェネリック型の `::new()` が効かない場合の代替）
- `RelativePath` は `$file.FullName.Substring($normalizedRoot.Length + 1)` で算出（+1 はパスセパレータ分）
- ルートパス自体のファイル（`$currentDir` がルートの場合）も正しく処理されることを確認

### 完了条件

- [ ] **AC-02:** `tests\vbnet\bin\excluded_file.vb` が走査結果に含まれないことを確認
- [ ] **AC-03:** `.exe` ファイルが Language=`SKIPPED` で返され、SKIP ログに `（ExcludeExtensions）` が記録される
- [ ] **AC-04:** `tests\other\01_unknown.xyz` と `02_arbitrary.foo` が Language=`OTHER` として返される
- [ ] `.vb` → `VBNET`、`.sql` → `PLSQL` が正しく判定される
- [ ] `.steering` フォルダ配下のファイルが走査結果に含まれない
- [ ] ログに `（ExcludeExtensions）` と `（アクセスエラー）` のプレフィックスが区別して記録される

---

## T6. tests/ サンプルファイル作成

**依存:** なし（T1〜T5 と並行可）

### 実装上の注意（フォルダ・ファイル一括作成）

```powershell
# tests/ 配下の作成（リポジトリルートで実行）
New-Item -ItemType Directory -Force -Path @(
    'tests\vbnet',
    'tests\vbnet\bin',
    'tests\plsql',
    'tests\other'
)

# VB.NET サンプル（7ファイル）
@('01_comment_only','02_rem_comment','03_mixed_line',
  '04_blank_lines','05_no_trailing_newline','06_utf8_bom','07_utf16_le') |
  ForEach-Object { New-Item -ItemType File -Path "tests\vbnet\$_.vb" }

# .exe ダミー（0バイト）
New-Item -ItemType File -Path 'tests\vbnet\01_binary_skip.exe'

# ExcludeFolders テスト用ダミー
New-Item -ItemType File -Path 'tests\vbnet\bin\excluded_file.vb'

# PL/SQL サンプル（8ファイル）
@('01_line_comment','02_inline_comment','03_block_comment_single',
  '04_block_comment_multi','05_block_mixed','06_sjis',
  '07_block_inline_with_code','08_block_comment_with_line_marker') |
  ForEach-Object { New-Item -ItemType File -Path "tests\plsql\$_.sql" }

# OTHER 判定用（拡張子がどのリストにも該当しない）
New-Item -ItemType File -Path 'tests\other\01_unknown.xyz'
New-Item -ItemType File -Path 'tests\other\02_arbitrary.foo'
```

> 各サンプルの中身は最小限で構わない。v01 では走査対象として存在すればよい（行数カウントは v02 以降）。

### 作成対象サマリ

#### tests/vbnet/

| ファイル名                  | 用途（v01 での確認内容）                            |
| --------------------------- | --------------------------------------------------- |
| `01_comment_only.vb`        | VBNET 判定の確認                                    |
| `02_rem_comment.vb`         | VBNET 判定の確認                                    |
| `03_mixed_line.vb`          | VBNET 判定の確認                                    |
| `04_blank_lines.vb`         | VBNET 判定の確認                                    |
| `05_no_trailing_newline.vb` | VBNET 判定の確認                                    |
| `06_utf8_bom.vb`            | VBNET 判定の確認                                    |
| `07_utf16_le.vb`            | VBNET 判定の確認                                    |
| `01_binary_skip.exe`        | ExcludeExtensions → SKIPPED の確認（0バイトダミー） |
| `bin\excluded_file.vb`      | ExcludeFolders → 走査結果に含まれないことの確認     |

#### tests/plsql/

| ファイル名                              | 用途（v01 での確認内容） |
| --------------------------------------- | ------------------------ |
| `01_line_comment.sql`                   | PLSQL 判定の確認         |
| `02_inline_comment.sql`                 | PLSQL 判定の確認         |
| `03_block_comment_single.sql`           | PLSQL 判定の確認         |
| `04_block_comment_multi.sql`            | PLSQL 判定の確認         |
| `05_block_mixed.sql`                    | PLSQL 判定の確認         |
| `06_sjis.sql`                           | PLSQL 判定の確認         |
| `07_block_inline_with_code.sql`         | PLSQL 判定の確認         |
| `08_block_comment_with_line_marker.sql` | PLSQL 判定の確認         |

#### tests/other/

| ファイル名         | 用途（v01 での確認内容）                           |
| ------------------ | -------------------------------------------------- |
| `01_unknown.xyz`   | OTHER 判定の確認（どのリストにも該当しない拡張子） |
| `02_arbitrary.foo` | OTHER 判定の確認（複数件の OTHER を確認）          |

### 完了条件

- [ ] `tests\vbnet\` 配下に 7 + 1（.exe）+ 1（bin\）= 9エントリが存在する
- [ ] `tests\plsql\` 配下に 8 ファイルが存在する
- [ ] `tests\other\` 配下に 2 ファイル（`.xyz` / `.foo`）が存在する
- [ ] `01_binary_skip.exe` のファイルサイズが 0 バイトである
- [ ] `tests\vbnet\bin\excluded_file.vb` が存在する

---

## T7. 統合確認・AC検証

**依存:** T1〜T6 すべて完了後

### 検証コマンド

```powershell
# -OutputDir / -LogDir を明示指定（output/ logs/ が RootPath 配下に生成されないことを確認）
.\src\SourceList.ps1 -RootPath .\tests -OutputDir .\output -LogDir .\logs

# 既定値での実行（ExcludeFolders により output/ logs/ が除外されることを確認）
.\src\SourceList.ps1 -RootPath .\tests
```

### 確認項目

#### AC-01 〜 AC-04（FileScanner 動作確認）

- [ ] **AC-01:** コンソールとログに「走査件数」「VBNET / PLSQL / OTHER / SKIPPED 各件数」が出力される
- [ ] **AC-02:** `tests\vbnet\bin\excluded_file.vb` が走査結果に含まれない（bin フォルダ除外）
- [ ] **AC-03:** `01_binary_skip.exe` が Language=`SKIPPED` として走査結果に含まれ、SKIP ログに `（ExcludeExtensions）` が記録される
- [ ] **AC-04:** `tests\other\01_unknown.xyz` および `02_arbitrary.foo` が Language=`OTHER` として走査結果に含まれる

#### AC-05（-RootPath バリデーション）

- [ ] **AC-05:** `.\src\SourceList.ps1 -RootPath C:\NotExist` を実行 → 終了コード `1`、ERROR メッセージがコンソールとログに出力される

#### AC-06（settings.psd1 フォールバック）

- [ ] **AC-06:** `config\settings.psd1` をリネームした状態で実行 → WARN ログが出て処理が続行する。元に戻して再確認。

#### AC-07（PS 5.1 互換性）

- [ ] **AC-07:** `$PSVersionTable.PSVersion.Major` が `5` であることを確認した上で実行し、Import-Module エラーが発生しない

#### DoD 追加確認

- [ ] `output\` ディレクトリが自動生成されている（v01 では CSV は生成されない）
- [ ] `logs\SourceList_*.log` が生成されており、走査サマリが記録されている
- [ ] `.steering` フォルダ配下のファイルがコンソールサマリに含まれていない

---

## 実装上のリスクと対処

| #   | リスク                                                                     | 対処方針                                                                                                                                                          |
| --- | -------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| R1  | **PS 5.1 でジェネリック型 `::new()` が動作しない**                         | `New-Object 'System.Collections.Generic.Queue[string]'` で代替。T4 で最初に確認する                                                                               |
| R2  | **`$RootPath` 末尾スラッシュによる相対パス計算ズレ**                       | `$RootPath.TrimEnd('\')` で正規化後に処理。`Substring(Length + 1)` で先頭セパレータを除去                                                                         |
| R3  | **UTF-8 BOM 欠落（PS 5.1 で日本語コメントが化ける）**                      | 実装完了後に全 `.ps1` / `.psm1` を VS Code で開いてステータスバーの文字コード表示を確認。v02 以降で `Get-Content -Encoding Byte` によるバッチチェック自動化を検討 |
| R4  | **`Add-Content -Encoding UTF8` がログに BOM を重複付加**                   | PS 5.1 ではファイル新規作成時のみ BOM を付加し、追記時は付加しない（正常動作。`design.md §4` 参照）                                                               |
| R5  | **`Get-ChildItem -ErrorAction SilentlyContinue` がアクセス拒否を握り潰す** | v01 では許容。v02 以降で個別ファイルの `try/catch` と組み合わせて詳細化を検討                                                                                     |
| R6  | **`[ValidateSet]` により不正な Level 値で実行時エラーが発生**              | 内部コードは `'INFO'` / `'WARN'` / `'SKIP'` / `'ERROR'` の4値のみ使用する                                                                                         |
| R7  | **`tests\vbnet\01_binary_skip.exe` がウイルス対策ソフトに隔離される**      | 0 バイトファイルとして作成。隔離時は除外設定追加 + `git checkout` で復元（`design.md §8.I` 参照）                                                                 |
| R8  | **ExcludeFolders の `$dir.Name` 照合で大文字小文字が区別される**           | Windows の NTFS はデフォルト大文字小文字不区別。`-contains` も PS 5.1 では大文字小文字不区別のため問題なし                                                        |
