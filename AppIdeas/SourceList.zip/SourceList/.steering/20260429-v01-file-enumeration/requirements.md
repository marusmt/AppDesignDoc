# 要求内容（requirements.md）

> 作業単位: `.steering/20260429-v01-file-enumeration/`
> 対象バージョン: v0.1（MVP）
> 作成日: 2026-04-29

---

## 1. 今回の作業概要

SourceList の **1 エントリスクリプト + 5 モジュール構成** の骨組みを作成し、
フォルダ走査・拡張子フィルタリング・言語種別判定までを動作可能な状態にする。
CSV 出力・行数カウント・コメント判定・エンコーディング本実装は次フェーズ以降。

---

## 2. パラメータ仕様（`SourceList.ps1`）

| パラメータ      | 必須/任意 | 既定値                     | 備考                                           |
| --------------- | --------- | -------------------------- | ---------------------------------------------- |
| `-RootPath`   | 必須      | なし                       | 走査対象のルートフォルダ                       |
| `-ConfigPath` | 任意      | `.\config\settings.psd1` | 設定ファイルのパス                             |
| `-OutputDir`  | 任意      | `.\output`               | CSV 出力先ディレクトリ（v01 では作成確認のみ） |
| `-LogDir`     | 任意      | `.\logs`                 | ログ出力先ディレクトリ                         |

---

## 3. FileScanner 出力スキーマ

`FileScanner.psm1` の `Get-SourceFiles` 関数が返す PSCustomObject の構造。
後続モジュール（LineCounter / CsvWriter）との I/F として確定させる。

```powershell
[PSCustomObject]@{
    FullPath      = [string]  # ファイルのフルパス
    RelativePath  = [string]  # 走査ルートからの相対パス
    FileName      = [string]  # ファイル名（拡張子含む）
    Extension     = [string]  # 拡張子（小文字・ドット含む。例: '.vb'）
    Language      = [string]  # 'VBNET' | 'PLSQL' | 'OTHER' | 'SKIPPED'
    SizeBytes     = [long]    # ファイルサイズ（バイト）
    LastWriteTime = [string]  # 'yyyy-MM-dd HH:mm:ss'
}
```

> `Lines` / `CommentLines` / `BlankLines` は LineCounter（v02 以降）が追加する。
> ExcludeFolders 配下のファイルはこの配列に含めない（返却しない）。

---

## 4. 用語と挙動の定義

ファイルの処理結果を以下の 5 区分に明確に定義する。

| 区分                          | 判定条件                           | Language 値 | 走査結果配列       | ログ                 |
| ----------------------------- | ---------------------------------- | ----------- | ------------------ | -------------------- |
| **VB.NET**              | VbNetExtensions に該当する拡張子   | `VBNET`   | **含める**   | DEBUG（任意）        |
| **PL/SQL**              | PlSqlExtensions に該当する拡張子   | `PLSQL`   | **含める**   | DEBUG（任意）        |
| **OTHER**               | いずれのリストにも該当しない拡張子 | `OTHER`   | **含める**   | なし（通常処理）     |
| **スキップ（Skipped）** | ExcludeExtensions に該当する拡張子 | `SKIPPED` | **含める**   | `SKIP` レベル      |
| **除外（Excluded）**    | ExcludeFolders 配下のフォルダ      | —          | **含めない** | INFO（フォルダ単位） |

> `DEBUG` は `functional-design.md §5` 定義外のため v01 では実装しない。
> VBNET / PLSQL ファイルのログ出力は任意とし、実装しない場合は「なし（通常処理）」と同等に扱う。

---

## 5. 実装スコープ

### 実装対象

| ファイル                      | v01 の実装内容                                                                                                                                                                                                                            |
| ----------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `src\SourceList.ps1`        | パラメータ定義・設定ファイル読み込み・モジュール `Import-Module`・`-OutputDir` / `-LogDir` で指定されたディレクトリが存在しない場合は起動時に自動作成・`Get-SourceFiles` 呼び出し・サマリをコンソール＋ログに出力・終了コード制御 |
| `src\FileScanner.psm1`      | `Get-SourceFiles` 関数：再帰走査・ExcludeFolders フィルタ（`-contains` 完全一致）・拡張子優先順位判定（ExcludeExtensions → PlSqlExtensions → VbNetExtensions → OTHER）・Language 値付き PSCustomObject 返却                        |
| `src\Logger.psm1`           | `Write-LogMessage` 関数：タイムスタンプ付きログ行生成・`Write-Host` でコンソール出力・ログファイル追記                                                                                                                                |
| `src\EncodingDetector.psm1` | **A案：関数シグネチャ + 戻り値スキーマの確定のみ**（v01 ではファイル内容を読まないため BOM 検出不要。v02 で本実装）                                                                                                                 |
| `src\LineCounter.psm1`      | 関数シグネチャのみ定義（スタブ）。行数カウントは v02 で実装                                                                                                                                                                               |
| `src\CsvWriter.psm1`        | 関数シグネチャのみ定義（スタブ）。CSV 出力は v05 で実装                                                                                                                                                                                   |
| `config\settings.psd1`      | 既定値で同梱（VbNetExtensions / PlSqlExtensions / ExcludeExtensions / ExcludeFolders）                                                                                                                                                    |

### `settings.psd1` 既定値（ExcludeFolders）

v01 で同梱する `config\settings.psd1` に設定する `ExcludeFolders` の既定値。
完全一致（`-contains`）で判定する。

| フォルダ名            | 除外理由                             |
| --------------------- | ------------------------------------ |
| `bin` / `obj`     | VS ビルド出力                        |
| `.git` / `.vs`    | バージョン管理・IDE キャッシュ       |
| `node_modules`      | 将来の npm 混入対策                  |
| `output` / `logs` | ツール自身の生成物（自己参照防止）   |
| `.steering`         | 作業計画ドキュメント（自己参照防止） |

### 実装対象外（次フェーズ以降）

| 機能                                               | 予定フェーズ |
| -------------------------------------------------- | ------------ |
| エンコーディング本実装（BOM 検出・Shift_JIS）      | v02          |
| 行数・コメント数カウント                           | v02〜v04     |
| CSV 出力                                           | v05          |
| 設定ファイルの外部化（`-ConfigPath` の完全対応） | v10          |

---

## 6. 設定値の優先順位（3 層構造）

| 優先順位  | 設定ソース                               | v01 での状態                                         |
| --------- | ---------------------------------------- | ---------------------------------------------------- |
| 1（最低） | スクリプト内ハードコード定数             | 実装済み（最終フォールバック）                       |
| 2（通常） | `config\settings.psd1`（同梱ファイル） | 実装済み（`Import-PowerShellDataFile` で読み込み） |
| 3（最高） | `-ConfigPath` で指定された外部ファイル | v10 で実装予定。v01 での挙動は design.md で確定      |

> `settings.psd1` が存在しない場合は優先順位 1（ハードコード定数）にフォールバックし、
> `WARN` ログを出力して処理を続行する（→ `functional-design.md §2`）。

---

## 7. 受け入れ条件（AC）

| #     | 条件                                                                                                                                 |
| ----- | ------------------------------------------------------------------------------------------------------------------------------------ |
| AC-01 | `-RootPath` に実在するフォルダを指定して実行すると、走査件数・言語別内訳がコンソールとログに出力される                             |
| AC-02 | Section 5「`settings.psd1` 既定値（ExcludeFolders）」表に記載のフォルダ配下のファイルが、走査結果配列に含まれない                  |
| AC-03 | ExcludeExtensions に該当するファイルが Language=`SKIPPED` として走査結果配列に含まれ、`SKIP` レベルでログに記録される            |
| AC-04 | ExcludeExtensions にも PlSqlExtensions にも VbNetExtensions にも該当しないファイルが Language=`OTHER` として走査結果配列に含まれる |
| AC-05 | `-RootPath` が存在しない場合に終了コード `1` で終了し、`ERROR` レベルのメッセージがコンソールとログに出力される                |
| AC-06 | `config\settings.psd1` が存在しない場合にハードコード定数で続行し、`WARN` レベルのログが出力される                               |
| AC-07 | PowerShell 5.1 で追加モジュールなしに実行できる                                                                                      |

---

## 8. 完了の定義（DoD）

以下をすべて満たした時点で v01 完了とする。

- [ ] AC-01〜AC-07 をすべて手動確認した
- [ ] `tests/` 配下のサンプルフォルダに対して実行し、コンソール出力に想定のファイル件数・言語別内訳が表示された
- [ ] `output/` / `logs/` の生成ディレクトリが存在することを確認した（v01 ではログのみ生成）
- [ ] PowerShell 5.1 で `Import-Module` エラーが発生しないことを確認した

---

## 9. 制約事項

- PowerShell 5.1 構文のみ使用する（`??` / `ForEach-Object -Parallel` 等 PS7 構文禁止）
- すべての `.ps1` / `.psm1` は **UTF-8 BOM付き** で保存する（→ `development-guidelines.md §1`）
- `$ErrorActionPreference = 'Stop'` の設定方針は `development-guidelines.md §1` に従う
- パス結合には `Join-Path` を使用する（パス結合における文字列連結 `"$dir\$file"` は禁止）
- 外部モジュール・ネットワーク接続は使用しない
- 終了コード規約は `functional-design.md §1` を正とする（`0`: 正常 / `1`: 異常）
- ログレベルは `functional-design.md §5` を正とする（`INFO` / `WARN` / `SKIP` / `ERROR`）
