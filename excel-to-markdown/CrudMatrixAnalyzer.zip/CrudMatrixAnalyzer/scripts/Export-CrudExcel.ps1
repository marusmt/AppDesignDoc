<#
.SYNOPSIS
    CRUD解析結果をExcelファイルに出力する

.DESCRIPTION
    解析結果をピボットし、以下のシートを持つExcelを生成する
    1. テーブル×機能サマリー: テーブル単位でCRUD操作を一覧化
    2. 項目別詳細: テーブル×項目×機能のCRUD詳細
    3. テーブル定義: テーブル・カラム・データ型一覧
    4. インデックス定義: インデックス・テーブル・カラム一覧
    5. 未使用カラム: 定義済みだがコードから参照されていないカラム
    6. 生データ: 全解析結果の一覧

    Excel出力には ImportExcel モジュール または COM オートメーションを使用する
#>

function Build-CrudSummaryMatrix {
    param([System.Collections.ArrayList]$CrudResults)

    $features = ($CrudResults | ForEach-Object { $_.FeatureName } | Sort-Object -Unique)
    $tables = ($CrudResults | ForEach-Object { $_.TableName } | Sort-Object -Unique)

    $matrix = [System.Collections.ArrayList]::new()

    foreach ($table in $tables) {
        $row = [ordered]@{ "テーブル名" = $table }

        foreach ($feature in $features) {
            $ops = ($CrudResults | Where-Object { $_.TableName -eq $table -and $_.FeatureName -eq $feature } |
                ForEach-Object { $_.Operation } | Sort-Object -Unique) -join ""

            $opsUnique = ($ops.ToCharArray() | Sort-Object -Unique) -join ""
            $row[$feature] = if ($opsUnique) { $opsUnique } else { "-" }
        }

        [void]$matrix.Add([PSCustomObject]$row)
    }

    return $matrix
}

function Build-CrudDetailMatrix {
    param([System.Collections.ArrayList]$CrudResults)

    $features = ($CrudResults | ForEach-Object { $_.FeatureName } | Sort-Object -Unique)

    $tableColumnPairs = $CrudResults |
        ForEach-Object { "$($_.TableName)|$($_.ColumnName)" } |
        Sort-Object -Unique

    $matrix = [System.Collections.ArrayList]::new()

    foreach ($pair in $tableColumnPairs) {
        $parts = $pair -split '\|'
        $table = $parts[0]
        $column = $parts[1]

        $row = [ordered]@{
            "テーブル名" = $table
            "項目名"     = $column
        }

        foreach ($feature in $features) {
            $ops = ($CrudResults |
                Where-Object { $_.TableName -eq $table -and $_.ColumnName -eq $column -and $_.FeatureName -eq $feature } |
                ForEach-Object { $_.Operation } | Sort-Object -Unique) -join ""

            $opsUnique = ($ops.ToCharArray() | Sort-Object -Unique) -join ""
            $row[$feature] = if ($opsUnique) { $opsUnique } else { "-" }
        }

        [void]$matrix.Add([PSCustomObject]$row)
    }

    return $matrix
}

function Build-RawDataSheet {
    param([System.Collections.ArrayList]$CrudResults)

    $rows = [System.Collections.ArrayList]::new()

    foreach ($item in $CrudResults) {
        [void]$rows.Add([PSCustomObject][ordered]@{
            "ソース種別"   = $item.SourceType
            "ソースファイル" = $item.SourceFile
            "オブジェクト種別" = $item.ObjectType
            "オブジェクト名"  = $item.ObjectName
            "プロシージャ/メソッド" = $item.ProcName
            "機能名"       = $item.FeatureName
            "テーブル名"   = $item.TableName
            "項目名"       = $item.ColumnName
            "操作"         = $item.Operation
        })
    }

    return $rows
}

function Build-TableDefSheet {
    param([System.Collections.ArrayList]$TableDefinitions)

    $rows = [System.Collections.ArrayList]::new()
    foreach ($def in ($TableDefinitions | Sort-Object { $_.TableName }, { $_.OrdinalPos })) {
        [void]$rows.Add([PSCustomObject][ordered]@{
            "テーブル名" = $def.TableName
            "No"         = $def.OrdinalPos
            "カラム名"   = $def.ColumnName
            "データ型"   = $def.DataType
            "NULL許可"   = $def.Nullable
            "DEFAULT"    = $def.HasDefault
            "ソースファイル" = $def.SourceFile
        })
    }
    return $rows
}

function Build-IndexDefSheet {
    param([System.Collections.ArrayList]$IndexDefinitions)

    $rows = [System.Collections.ArrayList]::new()
    foreach ($def in ($IndexDefinitions | Sort-Object { $_.TableName }, { $_.IndexName }, { $_.ColumnPos })) {
        [void]$rows.Add([PSCustomObject][ordered]@{
            "テーブル名"     = $def.TableName
            "インデックス名" = $def.IndexName
            "一意性"         = $def.Uniqueness
            "カラム位置"     = $def.ColumnPos
            "カラム名"       = $def.ColumnName
            "ソースファイル" = $def.SourceFile
        })
    }
    return $rows
}

function Build-UnusedColumnsSheet {
    param([System.Collections.ArrayList]$UnusedColumns)

    $rows = [System.Collections.ArrayList]::new()
    foreach ($item in ($UnusedColumns | Sort-Object { $_.TableName }, { $_.ColumnName })) {
        [void]$rows.Add([PSCustomObject][ordered]@{
            "テーブル名" = $item.TableName
            "カラム名"   = $item.ColumnName
            "データ型"   = $item.DataType
            "NULL許可"   = $item.Nullable
        })
    }
    return $rows
}

function Export-CrudExcelWithModule {
    param(
        [System.Collections.ArrayList]$CrudResults,
        [string]$ExcelPath,
        [string]$SummarySheetName = "テーブル×機能サマリー",
        [string]$DetailSheetName = "項目別詳細",
        [string]$RawSheetName = "生データ",
        [System.Collections.ArrayList]$TableDefinitions = $null,
        [System.Collections.ArrayList]$IndexDefinitions = $null,
        [System.Collections.ArrayList]$UnusedColumns = $null
    )

    if (-not (Get-Module -ListAvailable -Name ImportExcel)) {
        Write-Host "[Excel] ImportExcelモジュールをインストールします..." -ForegroundColor Yellow
        Install-Module ImportExcel -Force -Scope CurrentUser
    }
    Import-Module ImportExcel

    $outputDir = [System.IO.Path]::GetDirectoryName($ExcelPath)
    if (-not (Test-Path $outputDir)) {
        New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
    }
    if (Test-Path $ExcelPath) { Remove-Item $ExcelPath -Force }

    $hasBaseSheet = $false

    if ($CrudResults.Count -gt 0) {
        Write-Host "[Excel] サマリーシート作成中..." -ForegroundColor Cyan
        $summaryMatrix = Build-CrudSummaryMatrix -CrudResults $CrudResults
        if ($summaryMatrix.Count -gt 0) {
            $summaryMatrix | Export-Excel -Path $ExcelPath -WorksheetName $SummarySheetName `
                -AutoSize -FreezeTopRow -BoldTopRow `
                -ConditionalText $(
                    New-ConditionalText -Text "C" -BackgroundColor LightGreen -ConditionalTextColor DarkGreen
                    New-ConditionalText -Text "R" -BackgroundColor LightBlue -ConditionalTextColor DarkBlue
                    New-ConditionalText -Text "U" -BackgroundColor LightGoldenrodYellow -ConditionalTextColor DarkGoldenrod
                    New-ConditionalText -Text "D" -BackgroundColor LightCoral -ConditionalTextColor DarkRed
                )
            $hasBaseSheet = $true
        }

        Write-Host "[Excel] 詳細シート作成中..." -ForegroundColor Cyan
        $detailMatrix = Build-CrudDetailMatrix -CrudResults $CrudResults
        if ($detailMatrix.Count -gt 0) {
            $detailParams = @{
                Path          = $ExcelPath
                WorksheetName = $DetailSheetName
                AutoSize      = $true
                FreezeTopRow  = $true
                BoldTopRow    = $true
            }
            if ($hasBaseSheet) { $detailParams.Append = $true }
            $detailMatrix | Export-Excel @detailParams
            $hasBaseSheet = $true
        }
    }

    if ($null -ne $TableDefinitions -and $TableDefinitions.Count -gt 0) {
        Write-Host "[Excel] テーブル定義シート作成中..." -ForegroundColor Cyan
        $tableDefData = Build-TableDefSheet -TableDefinitions $TableDefinitions
        if ($tableDefData.Count -gt 0) {
            $tableParams = @{
                Path          = $ExcelPath
                WorksheetName = "テーブル定義"
                AutoSize      = $true
                FreezeTopRow  = $true
                BoldTopRow    = $true
                TableName     = "TableDefinitions"
            }
            if ($hasBaseSheet) { $tableParams.Append = $true }
            $tableDefData | Export-Excel @tableParams
            $hasBaseSheet = $true
        }
    }

    if ($null -ne $IndexDefinitions -and $IndexDefinitions.Count -gt 0) {
        Write-Host "[Excel] インデックス定義シート作成中..." -ForegroundColor Cyan
        $indexDefData = Build-IndexDefSheet -IndexDefinitions $IndexDefinitions
        if ($indexDefData.Count -gt 0) {
            $indexParams = @{
                Path          = $ExcelPath
                WorksheetName = "インデックス定義"
                AutoSize      = $true
                FreezeTopRow  = $true
                BoldTopRow    = $true
                TableName     = "IndexDefinitions"
            }
            if ($hasBaseSheet) { $indexParams.Append = $true }
            $indexDefData | Export-Excel @indexParams
            $hasBaseSheet = $true
        }
    }

    if ($null -ne $UnusedColumns -and $UnusedColumns.Count -gt 0) {
        Write-Host "[Excel] 未使用カラムシート作成中..." -ForegroundColor Cyan
        $unusedData = Build-UnusedColumnsSheet -UnusedColumns $UnusedColumns
        if ($unusedData.Count -gt 0) {
            $unusedParams = @{
                Path          = $ExcelPath
                WorksheetName = "未使用カラム"
                AutoSize      = $true
                FreezeTopRow  = $true
                BoldTopRow    = $true
                TableName     = "UnusedColumns"
            }
            if ($hasBaseSheet) { $unusedParams.Append = $true }
            $unusedData | Export-Excel @unusedParams
            $hasBaseSheet = $true
        }
    }

    if ($CrudResults.Count -gt 0) {
        Write-Host "[Excel] 生データシート作成中..." -ForegroundColor Cyan
        $rawData = Build-RawDataSheet -CrudResults $CrudResults
        if ($rawData.Count -gt 0) {
            $rawParams = @{
                Path          = $ExcelPath
                WorksheetName = $RawSheetName
                AutoSize      = $true
                FreezeTopRow  = $true
                BoldTopRow    = $true
                TableName     = "CrudRawData"
            }
            if ($hasBaseSheet) { $rawParams.Append = $true }
            $rawData | Export-Excel @rawParams
            $hasBaseSheet = $true
        }
    }

    if (-not $hasBaseSheet) {
        Write-Warning "[Excel] 出力対象データがないため、Excelは作成されません。"
        return
    }

    Write-Host "[Excel] 出力完了: $ExcelPath" -ForegroundColor Green
}

function Export-CrudExcelWithCOM {
    param(
        [System.Collections.ArrayList]$CrudResults,
        [string]$ExcelPath,
        [string]$SummarySheetName = "テーブル×機能サマリー",
        [string]$DetailSheetName = "項目別詳細",
        [string]$RawSheetName = "生データ",
        [System.Collections.ArrayList]$TableDefinitions = $null,
        [System.Collections.ArrayList]$IndexDefinitions = $null,
        [System.Collections.ArrayList]$UnusedColumns = $null
    )

    $outputDir = [System.IO.Path]::GetDirectoryName($ExcelPath)
    if (-not (Test-Path $outputDir)) {
        New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
    }

    $excel = $null
    $workbook = $null

    try {
        $excel = New-Object -ComObject Excel.Application
        $excel.Visible = $false
        $excel.DisplayAlerts = $false

        $workbook = $excel.Workbooks.Add()
        $baseSheet = $workbook.Worksheets.Item(1)
        $lastSheet = $baseSheet
        $hasSheet = $false

        if ($CrudResults.Count -gt 0) {
            Write-Host "[Excel/COM] サマリーシート作成中..." -ForegroundColor Cyan
            $summaryMatrix = Build-CrudSummaryMatrix -CrudResults $CrudResults
            if ($summaryMatrix.Count -gt 0) {
                $baseSheet.Name = $SummarySheetName
                Write-MatrixToSheet -Sheet $baseSheet -Data $summaryMatrix -ApplyCrudColoring
                $lastSheet = $baseSheet
                $hasSheet = $true
            }

            Write-Host "[Excel/COM] 詳細シート作成中..." -ForegroundColor Cyan
            $detailMatrix = Build-CrudDetailMatrix -CrudResults $CrudResults
            if ($detailMatrix.Count -gt 0) {
                $detailSheet = $workbook.Worksheets.Add([System.Reflection.Missing]::Value, $lastSheet)
                $detailSheet.Name = $DetailSheetName
                Write-MatrixToSheet -Sheet $detailSheet -Data $detailMatrix -ApplyCrudColoring
                $lastSheet = $detailSheet
                $hasSheet = $true
            }
        }

        if ($null -ne $TableDefinitions -and $TableDefinitions.Count -gt 0) {
            Write-Host "[Excel/COM] テーブル定義シート作成中..." -ForegroundColor Cyan
            $tableDefData = Build-TableDefSheet -TableDefinitions $TableDefinitions
            if ($tableDefData.Count -gt 0) {
                $tableDefSheet = if ($hasSheet) {
                    $workbook.Worksheets.Add([System.Reflection.Missing]::Value, $lastSheet)
                } else {
                    $baseSheet
                }
                $tableDefSheet.Name = "テーブル定義"
                Write-MatrixToSheet -Sheet $tableDefSheet -Data $tableDefData
                $lastSheet = $tableDefSheet
                $hasSheet = $true
            }
        }

        if ($null -ne $IndexDefinitions -and $IndexDefinitions.Count -gt 0) {
            Write-Host "[Excel/COM] インデックス定義シート作成中..." -ForegroundColor Cyan
            $indexDefData = Build-IndexDefSheet -IndexDefinitions $IndexDefinitions
            if ($indexDefData.Count -gt 0) {
                $indexDefSheet = if ($hasSheet) {
                    $workbook.Worksheets.Add([System.Reflection.Missing]::Value, $lastSheet)
                } else {
                    $baseSheet
                }
                $indexDefSheet.Name = "インデックス定義"
                Write-MatrixToSheet -Sheet $indexDefSheet -Data $indexDefData
                $lastSheet = $indexDefSheet
                $hasSheet = $true
            }
        }

        if ($null -ne $UnusedColumns -and $UnusedColumns.Count -gt 0) {
            Write-Host "[Excel/COM] 未使用カラムシート作成中..." -ForegroundColor Cyan
            $unusedData = Build-UnusedColumnsSheet -UnusedColumns $UnusedColumns
            if ($unusedData.Count -gt 0) {
                $unusedSheet = if ($hasSheet) {
                    $workbook.Worksheets.Add([System.Reflection.Missing]::Value, $lastSheet)
                } else {
                    $baseSheet
                }
                $unusedSheet.Name = "未使用カラム"
                Write-MatrixToSheet -Sheet $unusedSheet -Data $unusedData
                $lastSheet = $unusedSheet
                $hasSheet = $true
            }
        }

        if ($CrudResults.Count -gt 0) {
            Write-Host "[Excel/COM] 生データシート作成中..." -ForegroundColor Cyan
            $rawData = Build-RawDataSheet -CrudResults $CrudResults
            if ($rawData.Count -gt 0) {
                $rawSheet = if ($hasSheet) {
                    $workbook.Worksheets.Add([System.Reflection.Missing]::Value, $lastSheet)
                } else {
                    $baseSheet
                }
                $rawSheet.Name = $RawSheetName
                Write-MatrixToSheet -Sheet $rawSheet -Data $rawData
                $lastSheet = $rawSheet
                $hasSheet = $true
            }
        }

        if (-not $hasSheet) {
            Write-Warning "[Excel/COM] 出力対象データがないため、Excelは作成されません。"
            return
        }

        $fullPath = [System.IO.Path]::GetFullPath($ExcelPath)
        $workbook.SaveAs($fullPath)
        Write-Host "[Excel/COM] 出力完了: $fullPath" -ForegroundColor Green
    }
    finally {
        if ($null -ne $workbook) {
            $workbook.Close($false)
            [System.Runtime.Interopservices.Marshal]::ReleaseComObject($workbook) | Out-Null
        }
        if ($null -ne $excel) {
            $excel.Quit()
            [System.Runtime.Interopservices.Marshal]::ReleaseComObject($excel) | Out-Null
        }
    }
}

function Write-MatrixToSheet {
    param(
        $Sheet,
        [System.Collections.ArrayList]$Data,
        [switch]$ApplyCrudColoring
    )

    if ($Data.Count -eq 0) { return }

    $properties = $Data[0].PSObject.Properties.Name
    $col = 1
    foreach ($prop in $properties) {
        $Sheet.Cells.Item(1, $col).Value2 = $prop
        $Sheet.Cells.Item(1, $col).Font.Bold = $true
        $Sheet.Cells.Item(1, $col).Interior.ColorIndex = 15
        $col++
    }

    $row = 2
    foreach ($item in $Data) {
        $col = 1
        foreach ($prop in $properties) {
            $value = $item.$prop
            $Sheet.Cells.Item($row, $col).Value2 = $value

            if ($ApplyCrudColoring -and $col -gt 1) {
                if ($value -match '^[CRUD\-]+$') {
                    switch -Regex ($value) {
                        'C' { $Sheet.Cells.Item($row, $col).Interior.Color = 0xCCFFCC }
                        'D' { $Sheet.Cells.Item($row, $col).Interior.Color = 0xCCCCFF }
                    }
                }
            }

            $col++
        }
        $row++
    }

    $usedRange = $Sheet.UsedRange
    $usedRange.Columns.AutoFit() | Out-Null

    $Sheet.Application.ActiveWindow.FreezePanes = $false
    $Sheet.Cells.Item(2, 1).Select() | Out-Null
    $Sheet.Application.ActiveWindow.FreezePanes = $true
}

function Export-CrudJson {
    param(
        [System.Collections.ArrayList]$CrudResults,
        [string]$JsonPath
    )

    $outputDir = [System.IO.Path]::GetDirectoryName($JsonPath)
    if (-not (Test-Path $outputDir)) {
        New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
    }

    $CrudResults | ConvertTo-Json -Depth 5 | Out-File -FilePath $JsonPath -Encoding UTF8
    Write-Host "[JSON] 出力完了: $JsonPath" -ForegroundColor Green
}
