<#
.SYNOPSIS
    Oracle SQL ソースファイルを解析し、CRUD操作情報を抽出する

.DESCRIPTION
    Oracle PL/SQL パッケージ・トリガー・ビュー等のSQLファイルを読み込み、
    INSERT/SELECT/UPDATE/DELETE/MERGE文からテーブル名・項目名・操作種別を抽出する

.PARAMETER SourcePath
    SQLファイル格納ディレクトリ

.PARAMETER FilePattern
    対象ファイルパターン（デフォルト: *.sql）

.PARAMETER ExcludePatterns
    除外ファイルパターン配列
#>

function Remove-SqlComments {
    param([string]$Content)

    $result = $Content -replace '--[^\r\n]*', ''
    $result = $result -replace '/\*[\s\S]*?\*/', ''
    return $result
}

function Get-OracleObjectInfo {
    param([string]$Content, [string]$FileName)

    $objectName = ""
    $objectType = ""

    if ($Content -match '(?i)CREATE\s+OR\s+REPLACE\s+PACKAGE\s+BODY\s+(?:\w+\.)?(\w+)') {
        $objectName = $Matches[1].ToUpper()
        $objectType = "PACKAGE"
    }
    elseif ($Content -match '(?i)CREATE\s+OR\s+REPLACE\s+TRIGGER\s+(?:\w+\.)?(\w+)') {
        $objectName = $Matches[1].ToUpper()
        $objectType = "TRIGGER"
    }
    elseif ($Content -match '(?i)CREATE\s+OR\s+REPLACE\s+(?:MATERIALIZED\s+)?VIEW\s+(?:\w+\.)?(\w+)') {
        $objectName = $Matches[1].ToUpper()
        $objectType = "VIEW"
    }
    elseif ($Content -match '(?i)CREATE\s+OR\s+REPLACE\s+FUNCTION\s+(?:\w+\.)?(\w+)') {
        $objectName = $Matches[1].ToUpper()
        $objectType = "FUNCTION"
    }
    elseif ($Content -match '(?i)CREATE\s+OR\s+REPLACE\s+PROCEDURE\s+(?:\w+\.)?(\w+)') {
        $objectName = $Matches[1].ToUpper()
        $objectType = "PROCEDURE"
    }
    elseif ($Content -match '(?i)CREATE\s+OR\s+REPLACE\s+PACKAGE\s+(?:\w+\.)?(\w+)') {
        $objectName = $Matches[1].ToUpper()
        $objectType = "PACKAGE_SPEC"
    }
    else {
        $objectName = [System.IO.Path]::GetFileNameWithoutExtension($FileName).ToUpper()
        $objectType = "OTHER"
    }

    return @{
        ObjectName = $objectName
        ObjectType = $objectType
    }
}

function Get-ProcedureBlocks {
    param([string]$Content)

    $blocks = [System.Collections.ArrayList]::new()
    $pattern = '(?i)(?:PROCEDURE|FUNCTION)\s+(\w+)'
    $matches = [regex]::Matches($Content, $pattern)

    if ($matches.Count -eq 0) {
        [void]$blocks.Add(@{
            Name    = "(MAIN)"
            Content = $Content
        })
        return $blocks
    }

    for ($i = 0; $i -lt $matches.Count; $i++) {
        $startIdx = $matches[$i].Index
        $endIdx = if ($i + 1 -lt $matches.Count) { $matches[$i + 1].Index } else { $Content.Length }
        $blockContent = $Content.Substring($startIdx, $endIdx - $startIdx)
        $procName = $matches[$i].Groups[1].Value.ToUpper()

        [void]$blocks.Add(@{
            Name    = $procName
            Content = $blockContent
        })
    }

    return $blocks
}

function Extract-TableAndColumns {
    param([string]$SqlFragment, [string]$OperationType)

    $results = [System.Collections.ArrayList]::new()

    switch ($OperationType) {
        "INSERT" {
            $pattern = '(?i)INSERT\s+INTO\s+(?:(\w+)\.)?(\w+)\s*\(([^)]+)\)'
            $m = [regex]::Matches($SqlFragment, $pattern)
            foreach ($match in $m) {
                $tableName = $match.Groups[2].Value.ToUpper()
                $columnsRaw = $match.Groups[3].Value
                $columns = ($columnsRaw -split ',') | ForEach-Object { $_.Trim().ToUpper() } | Where-Object { $_ -ne '' }
                foreach ($col in $columns) {
                    [void]$results.Add(@{
                        TableName  = $tableName
                        ColumnName = $col
                        Operation  = "C"
                    })
                }
            }
        }
        "SELECT" {
            $pattern = '(?i)SELECT\s+([\s\S]+?)\s+FROM\s+([\s\S]+?)(?:\s+WHERE\b|\s+ORDER\b|\s+GROUP\b|\s+HAVING\b|\s+UNION\b|\s*;|\s*\)|\s+FOR\b|\s*$)'
            $m = [regex]::Matches($SqlFragment, $pattern)
            foreach ($match in $m) {
                $selectClause = $match.Groups[1].Value
                $fromClause = $match.Groups[2].Value

                $tables = Extract-FromTables -FromClause $fromClause
                $columns = Extract-SelectColumns -SelectClause $selectClause

                foreach ($table in $tables) {
                    if ($columns.Count -eq 0 -or ($columns.Count -eq 1 -and $columns[0] -eq "*")) {
                        [void]$results.Add(@{
                            TableName  = $table
                            ColumnName = "*"
                            Operation  = "R"
                        })
                    }
                    else {
                        foreach ($col in $columns) {
                            [void]$results.Add(@{
                                TableName  = $table
                                ColumnName = $col
                                Operation  = "R"
                            })
                        }
                    }
                }
            }
        }
        "UPDATE" {
            $pattern = '(?i)UPDATE\s+(?:(\w+)\.)?(\w+)\s+SET\s+([\s\S]+?)(?:\s+WHERE\b|\s*;|\s*$)'
            $m = [regex]::Matches($SqlFragment, $pattern)
            foreach ($match in $m) {
                $tableName = $match.Groups[2].Value.ToUpper()
                $setClause = $match.Groups[3].Value
                $columns = Extract-SetColumns -SetClause $setClause

                foreach ($col in $columns) {
                    [void]$results.Add(@{
                        TableName  = $tableName
                        ColumnName = $col
                        Operation  = "U"
                    })
                }
            }
        }
        "DELETE" {
            $pattern = '(?i)DELETE\s+FROM\s+(?:(\w+)\.)?(\w+)'
            $m = [regex]::Matches($SqlFragment, $pattern)
            foreach ($match in $m) {
                $tableName = $match.Groups[2].Value.ToUpper()
                [void]$results.Add(@{
                    TableName  = $tableName
                    ColumnName = "(ALL)"
                    Operation  = "D"
                })
            }
        }
        "MERGE" {
            $pattern = '(?i)MERGE\s+INTO\s+(?:(\w+)\.)?(\w+)'
            $m = [regex]::Matches($SqlFragment, $pattern)
            foreach ($match in $m) {
                $tableName = $match.Groups[2].Value.ToUpper()
                [void]$results.Add(@{
                    TableName  = $tableName
                    ColumnName = "(ALL)"
                    Operation  = "CU"
                })
            }
        }
    }

    return $results
}

function Extract-FromTables {
    param([string]$FromClause)

    $tables = [System.Collections.ArrayList]::new()
    $cleaned = $FromClause -replace '(?i)\b(INNER|LEFT|RIGHT|FULL|CROSS|OUTER|NATURAL)\s+JOIN\b', ','
    $cleaned = $cleaned -replace '(?i)\bJOIN\b', ','
    $cleaned = $cleaned -replace '(?i)\bON\b[\s\S]*?(?=,|$)', ''

    $parts = $cleaned -split ','
    foreach ($part in $parts) {
        $trimmed = $part.Trim()
        if ($trimmed -match '(?:(\w+)\.)?(\w+)(?:\s+(\w+))?') {
            $tblName = $Matches[2].ToUpper()
            if ($tblName -notin @('SELECT', 'WHERE', 'ORDER', 'GROUP', 'HAVING', 'SET', 'VALUES', 'INTO', 'FROM', 'AND', 'OR', 'NOT', 'NULL', 'AS')) {
                [void]$tables.Add($tblName)
            }
        }
    }

    return $tables
}

function Extract-SelectColumns {
    param([string]$SelectClause)

    $columns = [System.Collections.ArrayList]::new()

    if ($SelectClause.Trim() -eq '*') {
        [void]$columns.Add("*")
        return $columns
    }

    $cleaned = $SelectClause -replace '(?i)\bDISTINCT\b', ''
    $parts = $cleaned -split ','

    foreach ($part in $parts) {
        $trimmed = $part.Trim()
        if ($trimmed -eq '') { continue }

        if ($trimmed -match '(?i)\bAS\s+(\w+)\s*$') {
            $colExpr = ($trimmed -replace '(?i)\s+AS\s+\w+\s*$', '').Trim()
        }
        elseif ($trimmed -match '^\S+\s+(\w+)$' -and $trimmed -notmatch '\(') {
            $colExpr = ($trimmed -split '\s+')[0].Trim()
        }
        else {
            $colExpr = $trimmed
        }

        if ($colExpr -match '(?:\w+\.)?(\w+)$' -and $colExpr -notmatch '\(') {
            $colName = $Matches[1].ToUpper()
            if ($colName -notin @('SELECT', 'FROM', 'WHERE', 'AND', 'OR', 'NOT', 'NULL', 'CASE', 'WHEN', 'THEN', 'ELSE', 'END')) {
                [void]$columns.Add($colName)
            }
        }
        elseif ($colExpr -match '\(.*\)') {
            if ($colExpr -match '(?i)\bAS\s+(\w+)') {
                [void]$columns.Add($Matches[1].ToUpper())
            }
            else {
                [void]$columns.Add("(EXPR)")
            }
        }
    }

    return $columns
}

function Extract-SetColumns {
    param([string]$SetClause)

    $columns = [System.Collections.ArrayList]::new()
    $depth = 0
    $current = ""
    $parts = [System.Collections.ArrayList]::new()

    foreach ($char in $SetClause.ToCharArray()) {
        if ($char -eq '(') { $depth++ }
        elseif ($char -eq ')') { $depth-- }

        if ($char -eq ',' -and $depth -eq 0) {
            [void]$parts.Add($current)
            $current = ""
        }
        else {
            $current += $char
        }
    }
    if ($current.Trim() -ne '') { [void]$parts.Add($current) }

    foreach ($part in $parts) {
        $trimmed = $part.Trim()
        if ($trimmed -match '^(\w+)\s*=') {
            [void]$columns.Add($Matches[1].ToUpper())
        }
    }

    return $columns
}

function Extract-PackageBodySection {
    param([string]$Content)

    $bodyPattern = '(?i)CREATE\s+OR\s+REPLACE\s+PACKAGE\s+BODY\s+'
    $bodyMatch = [regex]::Match($Content, $bodyPattern)

    if ($bodyMatch.Success) {
        return $Content.Substring($bodyMatch.Index)
    }

    return $Content
}

function Parse-OracleSqlFile {
    param([string]$FilePath)

    $rawContent = Get-Content $FilePath -Raw -Encoding Default
    $content = Remove-SqlComments -Content $rawContent
    $fileName = [System.IO.Path]::GetFileName($FilePath)

    $objectInfo = Get-OracleObjectInfo -Content $content -FileName $fileName

    $parseContent = $content
    if ($objectInfo.ObjectType -eq "PACKAGE") {
        $parseContent = Extract-PackageBodySection -Content $content
    }

    $blocks = Get-ProcedureBlocks -Content $parseContent

    $results = [System.Collections.ArrayList]::new()

    foreach ($block in $blocks) {
        $featureName = "$($objectInfo.ObjectType):$($objectInfo.ObjectName).$($block.Name)"

        foreach ($opType in @("INSERT", "SELECT", "UPDATE", "DELETE", "MERGE")) {
            $extracted = Extract-TableAndColumns -SqlFragment $block.Content -OperationType $opType

            foreach ($item in $extracted) {
                [void]$results.Add(@{
                    SourceType  = "Oracle"
                    SourceFile  = $fileName
                    ObjectType  = $objectInfo.ObjectType
                    ObjectName  = $objectInfo.ObjectName
                    ProcName    = $block.Name
                    FeatureName = $featureName
                    TableName   = $item.TableName
                    ColumnName  = $item.ColumnName
                    Operation   = $item.Operation
                })
            }
        }
    }

    return $results
}

function Parse-OracleSqlDirectory {
    param(
        [string]$SourcePath,
        [string]$FilePattern = "*.sql",
        [string[]]$ExcludePatterns = @(),
        [string[]]$ExcludeTables = @(),
        [string[]]$ExcludeSchemas = @()
    )

    Write-Host "[Oracle] 解析開始: $SourcePath" -ForegroundColor Cyan

    $files = Get-ChildItem -Path $SourcePath -Filter $FilePattern -Recurse -File
    foreach ($pattern in $ExcludePatterns) {
        $files = $files | Where-Object { $_.Name -notlike $pattern }
    }

    Write-Host "[Oracle] 対象ファイル数: $($files.Count)" -ForegroundColor Cyan

    $allResults = [System.Collections.ArrayList]::new()
    $fileCount = 0

    foreach ($file in $files) {
        $fileCount++
        Write-Progress -Activity "Oracle SQL 解析中" -Status "$fileCount / $($files.Count): $($file.Name)" -PercentComplete (($fileCount / $files.Count) * 100)

        try {
            $fileResults = Parse-OracleSqlFile -FilePath $file.FullName

            foreach ($result in $fileResults) {
                $skip = $false
                if ($result.TableName -in $ExcludeTables) { $skip = $true }
                foreach ($schema in $ExcludeSchemas) {
                    if ($result.TableName -like "$schema*") { $skip = $true }
                }
                if (-not $skip) {
                    [void]$allResults.Add($result)
                }
            }
        }
        catch {
            Write-Warning "[Oracle] 解析エラー: $($file.FullName) - $($_.Exception.Message)"
        }
    }

    Write-Progress -Activity "Oracle SQL 解析中" -Completed
    Write-Host "[Oracle] 解析完了: $($allResults.Count) 件のCRUDエントリを検出" -ForegroundColor Green

    return $allResults
}
