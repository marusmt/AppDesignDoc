﻿#Requires -Version 5.1
param(
    [Parameter(Position=0)] [string]$Command = '',
    [Parameter(ValueFromRemainingArguments=$true)] [object[]]$Rest
)
Set-StrictMode -Version Latest

#region CONFIG
$ScriptVersion = '1.0.0'
$DefaultType   = 'ISS'
#endregion CONFIG

#region UTIL

function Get-TmRoot {
    if ($env:TM_ROOT) { return $env:TM_ROOT }
    return Join-Path $PSScriptRoot 'tasks'
}

function Get-DailyFilePath {
    param([datetime]$Date = (Get-Date))
    $yyyy = $Date.ToString('yyyy')
    $mm   = $Date.ToString('MM')
    $file = $Date.ToString('yyyy-MM-dd')
    return Join-Path (Get-TmRoot) "daily\$yyyy\$mm\$file.md"
}

function ConvertTo-RoundedMinutes {
    param([int]$TotalMinutes, [string]$Direction)
    if ($Direction -eq 'Floor') {
        return [Math]::Floor($TotalMinutes / 15) * 15
    }
    return [Math]::Ceiling($TotalMinutes / 15) * 15
}

function Get-SessionBoundaries {
    param([string]$StartHHMM, [string]$StopHHMM)
    $s    = [datetime]::ParseExact($StartHHMM, 'HH:mm', $null)
    $e    = [datetime]::ParseExact($StopHHMM,  'HH:mm', $null)
    $sMin = ConvertTo-RoundedMinutes ($s.Hour * 60 + $s.Minute) 'Floor'
    $eMin = ConvertTo-RoundedMinutes ($e.Hour * 60 + $e.Minute) 'Ceil'
    if ($eMin -le $sMin) { $eMin = $sMin + 15 }
    return [PSCustomObject]@{
        StartRounded = (([datetime]'00:00').AddMinutes($sMin)).ToString('HH:mm')
        StopRounded  = (([datetime]'00:00').AddMinutes($eMin)).ToString('HH:mm')
        Hours        = [Math]::Round(($eMin - $sMin) / 60.0, 2)
    }
}

function Get-RoundedHours {
    param([string]$StartHHMM, [string]$StopHHMM)
    return (Get-SessionBoundaries $StartHHMM $StopHHMM).Hours
}

function Write-TmError {
    param([string]$Msg)
    Write-Host "tm: $Msg" -ForegroundColor Red
    exit 1
}

function Write-TmWarn {
    param([string]$Msg)
    Write-Warning "tm: $Msg"
}

function Write-TmInfo {
    param([string]$Msg)
    Write-Output $Msg
}

#endregion UTIL

#region DAILY

function Read-DailyFile {
    param([string]$Path)

    if (-not (Test-Path $Path)) { return @() }

    $lines = Get-Content -Path $Path -Encoding UTF8
    $tasks = [System.Collections.Generic.List[object]]::new()
    $i = 0
    $total = $lines.Count

    # フロントマターをスキップ（--- で囲まれたブロック）
    if ($i -lt $total -and $lines[$i] -eq '---') {
        $i++
        while ($i -lt $total -and $lines[$i] -ne '---') { $i++ }
        if ($i -lt $total) { $i++ }  # 閉じ --- をスキップ
    }

    $currentTask = $null

    while ($i -lt $total) {
        $line = $lines[$i]

        # タスクヘッダー行: ## [N] タイトル
        if ($line -match '^\#\#\s+\[(\d+)\]\s+(.+)$') {
            if ($null -ne $currentTask) { $tasks.Add($currentTask) }
            $currentTask = [PSCustomObject]@{
                Seq          = [int]$Matches[1]
                Title        = $Matches[2].Trim()
                Type         = 'ISS'
                Status       = 'Stopped'
                Hours        = [double]0.0
                RunningSince = ''
                FormalId     = ''
                RolledFrom   = ''
                SessionLines = [System.Collections.Generic.List[string]]::new()
                MemoLines    = [System.Collections.Generic.List[string]]::new()
            }
            $i++
            continue
        }

        if ($null -ne $currentTask) {
            # メタデータ行: key: value（ASCII小文字とアンダースコアのみ。日本語メモ行を誤検出しないよう [a-z_]+ に限定）
            if ($line -match '^([a-z_]+):\s*(.*)$') {
                $key = $Matches[1]
                $val = $Matches[2].Trim()
                switch ($key) {
                    'type'         { $currentTask.Type         = $val }
                    'status'       { $currentTask.Status       = $val }
                    'hours'        { $currentTask.Hours        = [double]$val }
                    'running_since'{ $currentTask.RunningSince = $val }
                    'formal_id'    { $currentTask.FormalId     = $val }
                    'rolled_from'  { $currentTask.RolledFrom   = $val }
                }
                $i++
                continue
            }

            # セッション行: [HH:MM-HH:MM] (X.XXh) ...
            if ($line -match '^\[\d{2}:\d{2}-\d{2}:\d{2}\]') {
                $currentTask.SessionLines.Add($line)
                $i++
                continue
            }

            # セクション区切り（視覚的区切り、パーサーは依存しない）
            if ($line -eq '---') {
                $i++
                continue
            }

            # 空行はスキップ
            if ($line.Trim() -eq '') {
                $i++
                continue
            }

            # 自由メモ行
            $currentTask.MemoLines.Add($line)
        }

        $i++
    }

    if ($null -ne $currentTask) { $tasks.Add($currentTask) }
    return $tasks.ToArray()
}

function Write-DailyFile {
    param([string]$Path, [object[]]$Tasks, [string]$DateStr = '')

    $dir = Split-Path $Path
    if (-not (Test-Path $dir)) {
        New-Item $dir -ItemType Directory -Force | Out-Null
    }

    if ($DateStr -eq '') {
        $DateStr = [System.IO.Path]::GetFileNameWithoutExtension($Path)
    }

    $lines = [System.Collections.Generic.List[string]]::new()
    $lines.Add('---')
    $lines.Add("date: $DateStr")
    $lines.Add('---')
    $lines.Add('')

    foreach ($task in $Tasks) {
        $lines.Add("## [$($task.Seq)] $($task.Title)")
        $lines.Add("type: $($task.Type)")
        $lines.Add("status: $($task.Status)")
        $lines.Add("hours: $($task.Hours.ToString('0.00'))")
        if ($task.RunningSince -ne '') {
            $lines.Add("running_since: $($task.RunningSince)")
        }
        $lines.Add("formal_id: $($task.FormalId)")
        if ($null -ne $task.PSObject.Properties['RolledFrom'] -and $task.RolledFrom -ne '') {
            $lines.Add("rolled_from: $($task.RolledFrom)")
        }
        $lines.Add('')
        foreach ($sl in $task.SessionLines) { $lines.Add($sl) }
        foreach ($ml in $task.MemoLines)    { $lines.Add($ml) }
        $lines.Add('')
        $lines.Add('---')
        $lines.Add('')
    }

    $content = $lines -join "`r`n"
    Set-Content -Path $Path -Value $content -Encoding UTF8
}

function New-DailyFile {
    param([string]$Path)
    $dir = Split-Path $Path
    if (-not (Test-Path $dir)) {
        New-Item $dir -ItemType Directory -Force | Out-Null
    }
    $dateStr = [System.IO.Path]::GetFileNameWithoutExtension($Path)
    $content = "---`r`ndate: $dateStr`r`n---`r`n"
    Set-Content -Path $Path -Value $content -Encoding UTF8
}

function Get-TaskBySeq {
    param([object[]]$Tasks, [int]$Seq)
    return $Tasks | Where-Object { $_.Seq -eq $Seq } | Select-Object -First 1
}

function Get-RunningTask {
    param([object[]]$Tasks)
    return $Tasks | Where-Object { $_.Status -eq 'Running' } | Select-Object -First 1
}

function Get-TaskLineNumber {
    param([string]$Path, [int]$Seq)
    $lines = Get-Content -Path $Path -Encoding UTF8
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match "^\#\#\s+\[$Seq\]\s+") {
            return $i + 1  # 1始まり
        }
    }
    return 1
}

function Add-SessionLine {
    param(
        [object]$Task,
        [string]$StartRounded,
        [string]$StopRounded,
        [double]$Hours,
        [string]$Comment = ''
    )
    $hoursStr = $Hours.ToString('0.00')
    $entry = "[$StartRounded-$StopRounded] ($($hoursStr)h)"
    if ($Comment -ne '') { $entry += " $Comment" }
    $Task.SessionLines.Add($entry)
}

function Update-TaskMeta {
    param([object]$Task, [hashtable]$Fields)
    foreach ($key in $Fields.Keys) {
        switch ($key) {
            'Status'       { $Task.Status       = $Fields[$key] }
            'Hours'        { $Task.Hours        = $Fields[$key] }
            'RunningSince' { $Task.RunningSince = $Fields[$key] }
            'FormalId'     { $Task.FormalId     = $Fields[$key] }
            'Type'         { $Task.Type         = $Fields[$key] }
        }
    }
}

function Find-LatestWorkingDayPath {
    # 当日の前日から最大90日遡り、日次ファイルが存在する最初のパスを返す。
    # 見つからない場合は $null を返す（AC-24, AC-25）。
    param([datetime]$Today = (Get-Date))
    for ($i = 1; $i -le 90; $i++) {
        $d = $Today.AddDays(-$i)
        $p = Get-DailyFilePath $d
        if (Test-Path $p) { return $p }
    }
    return $null
}

function Test-RolloverAlreadyDone {
    # 当日ファイルに RolledFrom が空でないタスクが1件以上あれば $true を返す（AC-26）。
    param([string]$TodayPath)
    if (-not (Test-Path $TodayPath)) { return $false }
    [object[]]$tasks = @(Read-DailyFile $TodayPath)
    return (@($tasks | Where-Object { $_.RolledFrom -ne '' }).Count -gt 0)
}

function Get-StoppedTasks {
    # タスク配列から status = 'Stopped' のタスクのみを返す（AC-27, AC-28）。
    param([object[]]$Tasks)
    return @($Tasks | Where-Object { $_.Status -eq 'Stopped' })
}

function New-RolledTask {
    # 繰越元タスクから繰越用の新タスクオブジェクトを生成する（AC-30, AC-31, AC-32）。
    param(
        [object]$SourceTask,
        [int]$NewSeq,
        [string]$RolledFromDate
    )
    return [PSCustomObject]@{
        Seq          = $NewSeq
        Title        = $SourceTask.Title
        Type         = $SourceTask.Type
        Status       = 'Stopped'
        Hours        = [double]0.0
        RunningSince = ''
        FormalId     = $SourceTask.FormalId
        RolledFrom   = $RolledFromDate
        SessionLines = [System.Collections.Generic.List[string]]::new()
        MemoLines    = [System.Collections.Generic.List[string]]::new($SourceTask.MemoLines)
    }
}

#endregion DAILY

#region COUNTER

function Invoke-WithCounterLock {
    param([scriptblock]$Action)
    $configDir = Join-Path (Get-TmRoot) 'config'
    if (-not (Test-Path $configDir)) {
        New-Item $configDir -ItemType Directory -Force | Out-Null
    }
    $lock    = Join-Path $configDir 'counters.lock'
    $timeout = 5000
    $elapsed = 0
    while (Test-Path $lock) {
        Start-Sleep -Milliseconds 100
        $elapsed += 100
        if ($elapsed -ge $timeout) {
            Write-TmError 'Counter lock timeout.'
        }
    }
    New-Item $lock -ItemType File -Force | Out-Null
    try   { & $Action }
    finally { Remove-Item $lock -Force -ErrorAction SilentlyContinue }
}

function Read-Counters {
    $configDir = Join-Path (Get-TmRoot) 'config'
    $path = Join-Path $configDir 'counters.json'
    if (-not (Test-Path $path)) {
        return @{ iss = 0; inq = @{} }
    }
    $raw = Get-Content -Path $path -Raw -Encoding UTF8
    $obj = $raw | ConvertFrom-Json
    $inqHt = @{}
    if ($null -ne $obj.inq) {
        $obj.inq.PSObject.Properties | ForEach-Object {
            $inqHt[$_.Name] = [int]$_.Value
        }
    }
    return @{ iss = [int]$obj.iss; inq = $inqHt }
}

function Write-Counters {
    param([hashtable]$Counters)
    $configDir = Join-Path (Get-TmRoot) 'config'
    if (-not (Test-Path $configDir)) {
        New-Item $configDir -ItemType Directory -Force | Out-Null
    }
    $path = Join-Path $configDir 'counters.json'
    $Counters | ConvertTo-Json -Depth 3 | Set-Content -Path $path -Encoding UTF8
}

function Get-NextIssNumber {
    Invoke-WithCounterLock {
        $c = Read-Counters
        $c.iss = $c.iss + 1
        Write-Counters $c
        $c.iss
    }
}

function Get-NextInqId {
    Invoke-WithCounterLock {
        $dk = (Get-Date).ToString('yyyyMMdd')
        $c  = Read-Counters
        $n  = if ($c.inq.ContainsKey($dk)) { [int]$c.inq[$dk] + 1 } else { 1 }
        $c.inq[$dk] = $n
        Write-Counters $c
        "INQ-$dk-$($n.ToString('00'))"
    }
}

#endregion COUNTER

#region COMMANDS

function Invoke-TmNew {
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$Title,
        [string]$Type = $DefaultType
    )
    if ([string]::IsNullOrWhiteSpace($Title)) {
        Write-TmError "tm new: タイトルを指定してください。"
    }

    $validTypes = @('ISS', 'INQ', 'MTG')
    if ($validTypes -notcontains $Type) {
        Write-TmError "-Type '$Type' は無効です。ISS / INQ / MTG のいずれかを指定してください。"
    }

    if ($Type -eq 'INQ') {
        $Title = "$(Get-NextInqId) $Title"
    }

    $path = Get-DailyFilePath
    if (-not (Test-Path $path)) {
        New-DailyFile $path
    }

    try {
        [object[]]$tasks = @(Read-DailyFile $path)
    } catch {
        Write-TmError "日次ファイル読込失敗: $($_.Exception.Message)"
    }

    $seq = ($tasks | Measure-Object).Count + 1

    $newTask = [PSCustomObject]@{
        Seq          = $seq
        Title        = $Title
        Type         = $Type
        Status       = 'Stopped'
        Hours        = [double]0.0
        RunningSince = ''
        FormalId     = ''
        RolledFrom   = ''
        SessionLines = [System.Collections.Generic.List[string]]::new()
        MemoLines    = [System.Collections.Generic.List[string]]::new()
    }

    $allTasks = [System.Collections.Generic.List[object]]::new()
    if ($null -ne $tasks -and $tasks.Count -gt 0) {
        $allTasks.AddRange([object[]]$tasks)
    }
    $allTasks.Add($newTask)

    try {
        Write-DailyFile $path $allTasks.ToArray()
    } catch {
        Write-TmError "日次ファイル書込失敗: $($_.Exception.Message)"
    }

    Write-TmInfo "[$seq] $Type を作成しました: $Title"
}

function Invoke-TmIssueNew {
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$Title
    )
    if ([string]::IsNullOrWhiteSpace($Title)) {
        Write-TmError "tm issue new: タイトルを指定してください。"
    }

    $issNum = Get-NextIssNumber
    $issId  = "ISS-$($issNum.ToString('000'))"
    $issDir = Join-Path (Get-TmRoot) "issues\$issId"

    if (Test-Path $issDir) {
        Write-TmError "$issId のフォルダが既に存在します。"
    }

    New-Item $issDir -ItemType Directory -Force | Out-Null

    $today   = (Get-Date).ToString('yyyy-MM-dd')
    $content = @"
---
id: $issId
title: $Title
status: Open
created: $today
---

## 概要

## 工程

| Phase | 内容 | 担当 | 状態 |
|-------|------|------|------|
| PHASE-01 | 分析 | - | - |
"@

    $issuePath = Join-Path $issDir 'issue.md'
    [System.IO.File]::WriteAllText($issuePath, $content, [System.Text.Encoding]::UTF8)

    Write-TmInfo "作成しました: $issId — $Title"
}

function Invoke-TmStop {
    param([datetime]$Now = (Get-Date))

    $path = Get-DailyFilePath
    if (-not (Test-Path $path)) {
        Write-TmWarn "本日の記録はありません。"
        return
    }

    try { [object[]]$tasks = @(Read-DailyFile $path) } catch {
        Write-TmError "日次ファイル読込失敗: $($_.Exception.Message)"
    }

    $running = Get-RunningTask $tasks
    if ($null -eq $running) {
        Write-TmWarn "現在 Running のタスクはありません。"
        return
    }

    $stopTimeStr  = $Now.ToString('HH:mm')
    $startTimeStr = $running.RunningSince

    $boundary = Get-SessionBoundaries $startTimeStr $stopTimeStr
    Add-SessionLine $running $boundary.StartRounded $boundary.StopRounded $boundary.Hours ''

    $newHours = [Math]::Round($running.Hours + $boundary.Hours, 2)
    Update-TaskMeta $running @{
        Status       = 'Stopped'
        Hours        = $newHours
        RunningSince = ''
    }

    try { Write-DailyFile $path $tasks } catch {
        Write-TmError "日次ファイル書込失敗: $($_.Exception.Message)"
    }

    Write-TmInfo "[$($running.Seq)] 停止: $($running.Title) (+$($boundary.Hours.ToString('0.00'))h / 計 $($newHours.ToString('0.00'))h)"
}

function Invoke-TmStart {
    param(
        [Parameter(Mandatory=$true)] [int]$Seq,
        [datetime]$Now = (Get-Date)
    )

    $path = Get-DailyFilePath
    if (-not (Test-Path $path)) {
        Write-TmError "本日の日次ファイルが存在しません。先に tm new でタスクを作成してください。"
    }

    try { [object[]]$tasks = @(Read-DailyFile $path) } catch {
        Write-TmError "日次ファイル読込失敗: $($_.Exception.Message)"
    }

    $target = Get-TaskBySeq $tasks $Seq
    if ($null -eq $target) {
        Write-TmError "連番 [$Seq] のタスクが見つかりません。"
    }

    if ($target.Status -eq 'Done') {
        Write-TmError "[$Seq] は既に完了（Done）しているため開始できません。"
    }

    if ($target.Status -eq 'Running') {
        Write-TmWarn "[$Seq] は既に Running 中です。"
        return
    }

    # 別の Running タスクを自動停止
    $running = Get-RunningTask $tasks
    if ($null -ne $running) {
        $boundary = Get-SessionBoundaries $running.RunningSince $Now.ToString('HH:mm')
        Add-SessionLine $running $boundary.StartRounded $boundary.StopRounded $boundary.Hours ''
        $newHours = [Math]::Round($running.Hours + $boundary.Hours, 2)
        Update-TaskMeta $running @{
            Status       = 'Stopped'
            Hours        = $newHours
            RunningSince = ''
        }
        Write-TmInfo "[$($running.Seq)] 停止: $($running.Title) (+$($boundary.Hours.ToString('0.00'))h / 計 $($newHours.ToString('0.00'))h)"
    }

    $nowStr = $Now.ToString('HH:mm')
    Update-TaskMeta $target @{
        Status       = 'Running'
        RunningSince = $nowStr
    }

    try { Write-DailyFile $path $tasks } catch {
        Write-TmError "日次ファイル書込失敗: $($_.Exception.Message)"
    }

    Write-TmInfo "[$Seq] 開始: $($target.Title) ($nowStr)"
}

function Invoke-TmDone {
    param([int]$Seq = -1, [datetime]$Now = (Get-Date))

    $path = Get-DailyFilePath
    if (-not (Test-Path $path)) {
        if ($Seq -eq -1) {
            Write-TmWarn "本日の記録はありません。"
            return
        }
        Write-TmError "本日の日次ファイルが存在しません。"
    }

    try { [object[]]$tasks = @(Read-DailyFile $path) } catch {
        Write-TmError "日次ファイル読込失敗: $($_.Exception.Message)"
    }

    if ($Seq -eq -1) {
        # 引数なし: Running タスクを完了
        $target = Get-RunningTask $tasks
        if ($null -eq $target) {
            Write-TmWarn "現在 Running のタスクはありません。"
            return
        }
    } else {
        $target = Get-TaskBySeq $tasks $Seq
        if ($null -eq $target) {
            Write-TmError "連番 [$Seq] のタスクが見つかりません。"
        }
        if ($target.Status -eq 'Done') {
            Write-TmWarn "[$Seq] は既に完了（Done）しています。"
            return
        }
    }

    $addedHours = [double]0.0
    if ($target.Status -eq 'Running') {
        $boundary = Get-SessionBoundaries $target.RunningSince $Now.ToString('HH:mm')
        Add-SessionLine $target $boundary.StartRounded $boundary.StopRounded $boundary.Hours ''
        $addedHours = $boundary.Hours
        Update-TaskMeta $target @{ RunningSince = '' }
    }

    $newHours = [Math]::Round($target.Hours + $addedHours, 2)
    Update-TaskMeta $target @{
        Status = 'Done'
        Hours  = $newHours
    }

    try { Write-DailyFile $path $tasks } catch {
        Write-TmError "日次ファイル書込失敗: $($_.Exception.Message)"
    }

    Write-TmInfo "[$($target.Seq)] 完了: $($target.Title) (+$($addedHours.ToString('0.00'))h / 計 $($newHours.ToString('0.00'))h)"
}

function Invoke-TmList {
    $path = Get-DailyFilePath
    if (-not (Test-Path $path)) {
        Write-TmInfo "本日の記録はありません。"
        return
    }

    try { [object[]]$tasks = @(Read-DailyFile $path) } catch {
        Write-TmError "日次ファイル読込失敗: $($_.Exception.Message)"
    }

    if ($tasks.Count -eq 0) {
        Write-TmInfo "本日の記録はありません。"
        return
    }

    $dateStr = [System.IO.Path]::GetFileNameWithoutExtension($path)
    Write-TmInfo $dateStr

    $runningSeq = $null
    $totalHours = [double]0.0

    foreach ($t in $tasks) {
        $mark = if ($t.Status -eq 'Running') { ' *' } else { '' }
        $statusPad = $t.Status.PadRight(7)
        $hourStr   = $t.Hours.ToString('0.00') + 'h'
        Write-TmInfo ("[$($t.Seq)] $($t.Type.PadRight(3))  $statusPad  $($hourStr.PadLeft(7))  $($t.Title)$mark")
        $totalHours += $t.Hours
        if ($t.Status -eq 'Running') { $runningSeq = $t.Seq }
    }

    Write-TmInfo ('─' * 50)
    $footer = "$($tasks.Count) 件  確定 $($totalHours.ToString('0.00'))h"
    if ($null -ne $runningSeq) { $footer += "  / Running 中 [$runningSeq]" }
    Write-TmInfo $footer
}

function Invoke-TmLog {
    $path = Get-DailyFilePath
    if (-not (Test-Path $path)) {
        Write-TmInfo "本日の記録はありません。"
        return
    }

    try { [object[]]$tasks = @(Read-DailyFile $path) } catch {
        Write-TmError "日次ファイル読込失敗: $($_.Exception.Message)"
    }

    if ($tasks.Count -eq 0) {
        Write-TmInfo "本日の記録はありません。"
        return
    }

    $dateStr = [System.IO.Path]::GetFileNameWithoutExtension($path)
    Write-TmInfo "=== $dateStr ==="

    foreach ($t in $tasks) {
        Write-TmInfo ''
        $runningNote = if ($t.Status -eq 'Running') { "（進行中: $($t.RunningSince)-）" } else { '' }
        Write-TmInfo "[$($t.Seq)] $($t.Title)  $($t.Type) | $($t.Status) | $($t.Hours.ToString('0.00'))h$runningNote"
        foreach ($sl in $t.SessionLines) { Write-TmInfo $sl }
        foreach ($ml in $t.MemoLines)    { Write-TmInfo $ml }
    }
}

function Invoke-TmOpen {
    param([int]$Seq = -1)

    $codeCmd = Get-Command 'code' -ErrorAction SilentlyContinue
    if ($null -eq $codeCmd) {
        Write-TmWarn "'code' コマンドが PATH に見つかりません。VS Code の PATH 設定を確認してください。"
        return
    }

    $path = Get-DailyFilePath
    if (-not (Test-Path $path)) {
        Write-TmInfo "本日の日次ファイルはまだ存在しません。tm new でタスクを作成してください。"
        return
    }

    if ($Seq -eq -1) {
        & code $path
    } else {
        try { [object[]]$tasks = @(Read-DailyFile $path) } catch {
            Write-TmError "日次ファイル読込失敗: $($_.Exception.Message)"
        }
        $target = Get-TaskBySeq $tasks $Seq
        if ($null -eq $target) {
            Write-TmError "連番 [$Seq] のタスクが見つかりません。"
        }
        $line = Get-TaskLineNumber $path $Seq
        & code -g "${path}:${line}"
    }
}

function Invoke-TmReport {
    param(
        [switch]$Csv,
        [string]$Date  = '',
        [string]$Month = ''
    )

    # 期間解決
    $targetFiles = @()
    if ($Date -ne '') {
        try {
            $parsed = [datetime]::ParseExact($Date, 'yyyy-MM-dd', $null)
        } catch {
            Write-TmError "-Date の形式が不正です（YYYY-MM-DD で指定してください）: $Date"
        }
        $filePath = Get-DailyFilePath $parsed
        if (Test-Path $filePath) { $targetFiles = @($filePath) }
    } elseif ($Month -ne '') {
        if ($Month -notmatch '^\d{4}-\d{2}$') {
            Write-TmError "-Month の形式が不正です（YYYY-MM で指定してください）: $Month"
        }
        $root    = Get-TmRoot
        $yyyy    = $Month.Split('-')[0]
        $mm      = $Month.Split('-')[1]
        $dir     = Join-Path $root "daily\$yyyy\$mm"
        if (Test-Path $dir) {
            $targetFiles = Get-ChildItem $dir -Filter '*.md' | Sort-Object Name | Select-Object -ExpandProperty FullName
        }
    } else {
        $filePath = Get-DailyFilePath
        if (Test-Path $filePath) { $targetFiles = @($filePath) }
    }

    if ($targetFiles.Count -eq 0) {
        Write-TmInfo "対象期間に記録がありません。"
        return
    }

    # 集計
    $rows = [System.Collections.Generic.List[object]]::new()
    foreach ($fp in $targetFiles) {
        $dateStr = [System.IO.Path]::GetFileNameWithoutExtension($fp)
        try { [object[]]$tasks = @(Read-DailyFile $fp) } catch { continue }
        foreach ($t in $tasks) {
            $rows.Add([PSCustomObject]@{
                Date  = $dateStr
                Id    = $t.Seq
                Title = $t.Title
                Hours = $t.Hours
                Type  = $t.Type
            })
        }
    }

    if ($rows.Count -eq 0) {
        Write-TmInfo "対象期間に記録がありません。"
        return
    }

    if ($Csv) {
        # TSV 出力（タスク行のみ。カテゴリ別小計・総合計は含めない）
        $header = "日付`tID`tタイトル`t工数`tカテゴリ"
        $lines  = $rows | ForEach-Object {
            "$($_.Date)`t$($_.Id)`t$($_.Title)`t$($_.Hours.ToString('0.00'))`t$($_.Type)"
        }
        $text = ($header + "`r`n" + ($lines -join "`r`n"))
        Set-Clipboard -Value $text
        Write-TmInfo "クリップボードにコピーしました（$($rows.Count) 件）"
    } else {
        # 人間向け表形式
        $label = if ($Date -ne '') { $Date } elseif ($Month -ne '') { $Month } else { (Get-Date).ToString('yyyy-MM-dd') }
        Write-TmInfo "=== $label ==="
        foreach ($r in $rows) {
            Write-TmInfo ("[$($r.Id)] $($r.Title.PadRight(30)) $($r.Type.PadRight(4)) $($r.Hours.ToString('0.00'))h")
        }
        Write-TmInfo ('─' * 44)
        $total = ($rows | Measure-Object -Property Hours -Sum).Sum
        Write-TmInfo ("合計" + ' '.PadRight(38) + $total.ToString('0.00') + 'h')
        Write-TmInfo ''
        Write-TmInfo 'カテゴリ別'
        $rows | Group-Object Type | Sort-Object Name | ForEach-Object {
            $catTotal = ($_.Group | Measure-Object -Property Hours -Sum).Sum
            Write-TmInfo ("  $($_.Name.PadRight(4)) $(' ' * 34) $($catTotal.ToString('0.00'))h")
        }
    }
}

function Invoke-TmFix {
    param(
        [Parameter(Mandatory=$true)] [int]$Seq,
        [int]$Session    = -1,
        [string]$Start   = '',
        [string]$Stop    = '',
        [string]$Date    = ''
    )

    # ステップ1: -Date バリデーション・ファイル取得
    if ($Date -ne '') {
        $parsed = [datetime]::MinValue
        if (-not [datetime]::TryParseExact($Date, 'yyyy-MM-dd', $null,
                [System.Globalization.DateTimeStyles]::None, [ref]$parsed)) {
            Write-TmError "-Date の形式が不正です（YYYY-MM-DD で指定）: $Date"
        }
        if ($parsed.Date -gt (Get-Date).Date) {
            Write-TmError "-Date に未来日は指定できません: $Date"
        }
        $path = Get-DailyFilePath $parsed
    } else {
        $path = Get-DailyFilePath
    }
    if (-not (Test-Path $path)) {
        $dateLabel = if ($Date -ne '') { $Date } else { (Get-Date).ToString('yyyy-MM-dd') }
        Write-TmError "指定日の日次ファイルが存在しません: $dateLabel"
    }

    # ステップ2: タスク読み込みと基本チェック
    try { [object[]]$tasks = @(Read-DailyFile $path) } catch {
        Write-TmError "日次ファイル読込失敗: $($_.Exception.Message)"
    }
    $target = Get-TaskBySeq $tasks $Seq
    if ($null -eq $target) {
        Write-TmError "連番 [$Seq] のタスクが見つかりません。"
    }
    if ($target.Status -eq 'Done') {
        Write-TmError "[$Seq] は完了（Done）済みのため修正できません。"
    }

    # ステップ3: Running + -Session省略 + -Stop指定 チェック
    if ($target.Status -eq 'Running' -and $Session -eq -1 -and $Stop -ne '') {
        Write-TmError "Running 中のタスクは -Stop を指定できません。-Start のみ指定してください。"
    }

    # Running かつ -Session 省略 → running_since 修正フロー（design.md §4.2）
    if ($target.Status -eq 'Running' -and $Session -eq -1) {
        if ($Start -eq '') {
            Write-TmError "-Start または -Stop を少なくとも一方指定してください。"
        }
        $dummy = [datetime]::MinValue
        if (-not [datetime]::TryParseExact($Start, 'HH:mm', $null,
                [System.Globalization.DateTimeStyles]::None, [ref]$dummy)) {
            Write-TmError "時刻フォーマットが不正です（HH:MM で指定）: $Start"
        }
        $oldRunningSince = $target.RunningSince
        $target.RunningSince = $Start
        try { Write-DailyFile $path $tasks } catch {
            Write-TmError "日次ファイル書込失敗: $($_.Exception.Message)"
        }
        Write-TmInfo "[$Seq] 修正: $($target.Title) (Running: $oldRunningSince → $Start)"
        return
    }

    # ステップ4: セッション解決（Stopped / Running + -Session 指定）
    $sessionLines = $target.SessionLines
    $count        = $sessionLines.Count

    if ($Session -ne -1 -and $Session -gt $count) {
        Write-TmError "セッション番号 [$Session] が範囲外です（対象タスクのセッション数: $count）。"
    }

    $targetIdx = if ($Session -eq -1) { $count - 1 } else { $Session - 1 }

    if ($targetIdx -lt 0) {
        Write-TmError "セッション番号 [1] が範囲外です（対象タスクのセッション数: $count）。"
    }

    $pattern = '^\[(\d{2}:\d{2})-(\d{2}:\d{2})\]\s*\(([\d.]+)h\)(.*)$'
    if ($sessionLines[$targetIdx] -notmatch $pattern) {
        Write-TmError "セッション行のパースに失敗しました。"
    }
    $existingStart = $Matches[1]
    $existingStop  = $Matches[2]
    $comment       = $Matches[4]
    $sessionNum    = $targetIdx + 1
    $oldStart      = $existingStart
    $oldStop       = $existingStop

    # ステップ5: 入力バリデーションと丸め後順序チェック
    if ($Start -eq '' -and $Stop -eq '') {
        Write-TmError "-Start または -Stop を少なくとも一方指定してください。"
    }
    $dummy = [datetime]::MinValue
    if ($Start -ne '' -and (-not [datetime]::TryParseExact($Start, 'HH:mm', $null,
            [System.Globalization.DateTimeStyles]::None, [ref]$dummy))) {
        Write-TmError "時刻フォーマットが不正です（HH:MM で指定）: $Start"
    }
    if ($Stop -ne '' -and (-not [datetime]::TryParseExact($Stop, 'HH:mm', $null,
            [System.Globalization.DateTimeStyles]::None, [ref]$dummy))) {
        Write-TmError "時刻フォーマットが不正です（HH:MM で指定）: $Stop"
    }
    $finalStart = if ($Start -ne '') { $Start } else { $existingStart }
    $finalStop  = if ($Stop  -ne '') { $Stop  } else { $existingStop  }

    # 丸め後 start >= stop チェック（Get-SessionBoundaries は auto-correct するため事前確認）
    $fsTime = [datetime]::ParseExact($finalStart, 'HH:mm', $null)
    $feTime = [datetime]::ParseExact($finalStop,  'HH:mm', $null)
    $fsMin  = ConvertTo-RoundedMinutes ($fsTime.Hour * 60 + $fsTime.Minute) 'Floor'
    $feMin  = ConvertTo-RoundedMinutes ($feTime.Hour * 60 + $feTime.Minute) 'Ceil'
    if ($fsMin -ge $feMin) {
        $sRound = (([datetime]'00:00').AddMinutes($fsMin)).ToString('HH:mm')
        $eRound = (([datetime]'00:00').AddMinutes($feMin)).ToString('HH:mm')
        Write-TmError "修正後の開始時刻が終了時刻以降になっています: $sRound >= $eRound"
    }

    $b = Get-SessionBoundaries $finalStart $finalStop

    # ステップ6: セッション行更新・hours 再計算
    $newEntry                 = "[$($b.StartRounded)-$($b.StopRounded)] ($($b.Hours.ToString('0.00'))h)$comment"
    $sessionLines[$targetIdx] = $newEntry

    $newHours = [double]0.0
    foreach ($sl in $sessionLines) {
        if ($sl -match '^\[(\d{2}:\d{2})-(\d{2}:\d{2})\]') {
            $newHours += Get-RoundedHours $Matches[1] $Matches[2]
        }
    }
    $target.Hours = [Math]::Round($newHours, 2)

    # ステップ7: 書き込み・完了メッセージ
    try { Write-DailyFile $path $tasks } catch {
        Write-TmError "日次ファイル書込失敗: $($_.Exception.Message)"
    }
    Write-TmInfo "[$Seq] 修正: $($target.Title) (S${sessionNum}: ${oldStart}-${oldStop} → $($b.StartRounded)-$($b.StopRounded) / 計 $($target.Hours.ToString('0.00'))h)"
}

function Invoke-TmRollover {
    <#
    .SYNOPSIS
        直近の稼働日の Stopped タスクを当日の日次ファイルへ全件繰り越す（v0.3）。
    #>
    param()

    # ステップ1: 二重繰越チェック（AC-26）
    $todayPath = Get-DailyFilePath
    if (Test-RolloverAlreadyDone $todayPath) {
        Write-TmWarn "本日は既に繰越実行済みです。"
        return
    }

    # ステップ2: 直近の稼働日を特定（AC-24, AC-25）
    $srcPath = Find-LatestWorkingDayPath
    if ($null -eq $srcPath) {
        Write-TmWarn "直近の稼働日が見つかりません（過去90日以内にファイルなし）。"
        return
    }
    $srcDateStr = [System.IO.Path]::GetFileNameWithoutExtension($srcPath)

    # ステップ3: Stopped タスク抽出（AC-27, AC-28）
    try {
        [object[]]$srcTasks = @(Read-DailyFile $srcPath)
    } catch {
        Write-TmError "日次ファイル読込失敗: $($_.Exception.Message)"
    }
    [object[]]$stoppedTasks = @(Get-StoppedTasks $srcTasks)

    # ステップ4: 0件チェック（AC-39）
    if ($stoppedTasks.Count -eq 0) {
        Write-TmInfo "繰越対象なし（直近の稼働日: $srcDateStr）"
        return
    }

    # ステップ5: 当日ファイル準備（AC-29）
    if (-not (Test-Path $todayPath)) {
        $todayDateStr = (Get-Date).ToString('yyyy-MM-dd')
        try {
            Write-DailyFile $todayPath @() $todayDateStr
        } catch {
            Write-TmError "日次ファイル書込失敗: $($_.Exception.Message)"
        }
    }
    try {
        [object[]]$todayTasks = @(Read-DailyFile $todayPath)
    } catch {
        Write-TmError "日次ファイル読込失敗: $($_.Exception.Message)"
    }

    # ステップ6: タスクコピーと採番（AC-30, AC-31, AC-32）
    $nextSeq     = $todayTasks.Count + 1
    $rolledTasks = [System.Collections.Generic.List[object]]::new()
    foreach ($t in $stoppedTasks) {
        $rolledTasks.Add((New-RolledTask $t $nextSeq $srcDateStr))
        $nextSeq++
    }

    # ステップ7: 当日ファイル書き込み。$srcPath は変更しない（AC-35）
    $allTasks = [System.Collections.Generic.List[object]]::new()
    if ($null -ne $todayTasks -and $todayTasks.Count -gt 0) {
        $allTasks.AddRange([object[]]$todayTasks)
    }
    $allTasks.AddRange($rolledTasks.ToArray())
    try {
        Write-DailyFile $todayPath $allTasks.ToArray()
    } catch {
        Write-TmError "日次ファイル書込失敗: $($_.Exception.Message)"
    }

    # ステップ8: 完了メッセージ出力（AC-33, AC-34）
    Write-TmInfo "直近の稼働日: $srcDateStr"
    $maxTitleLen = ($rolledTasks | ForEach-Object { $_.Title.Length } | Measure-Object -Maximum).Maximum
    foreach ($t in $rolledTasks) {
        Write-TmInfo "[$($t.Seq)] $($t.Title.PadRight($maxTitleLen))  $($t.Type)"
    }
    Write-TmInfo "$($rolledTasks.Count) 件のタスクを繰り越しました"
}

function Invoke-TmStartByPhase {
    param(
        [Parameter(Mandatory=$true)] [string]$PhaseId,
        [datetime]$Now = (Get-Date)
    )

    if ($PhaseId -notmatch '^ISS-\d{3}/PHASE-\d{2}$') {
        Write-TmError "tm start: 識別子の形式が不正です。整数または ISS-NNN/PHASE-MM 形式で指定してください。"
    }

    $path = Get-DailyFilePath
    $seq  = $null

    if (Test-Path $path) {
        try { [object[]]$tasks = @(Read-DailyFile $path) } catch {
            Write-TmError "日次ファイル読込失敗: $($_.Exception.Message)"
        }
        $existing = $tasks | Where-Object { $_.Title -eq $PhaseId } | Select-Object -First 1
        if ($null -ne $existing) { $seq = $existing.Seq }
    }

    if ($null -eq $seq) {
        Invoke-TmNew -Title $PhaseId -Type 'ISS'
        try { [object[]]$tasks = @(Read-DailyFile $path) } catch {
            Write-TmError "日次ファイル読込失敗: $($_.Exception.Message)"
        }
        $created = $tasks | Where-Object { $_.Title -eq $PhaseId } | Select-Object -First 1
        $seq = $created.Seq
    }

    Invoke-TmStart -Seq $seq -Now $Now
}

#endregion COMMANDS

#region DISPATCH

if ($null -eq $Rest) { [object[]]$Rest = @() }

if ($MyInvocation.InvocationName -ne '.') {
    switch ($Command) {
        'new' {
            $ht = @{}
            for ($i = 0; $i -lt $Rest.Count; $i++) {
                if ($Rest[$i] -eq '-Type' -and $i+1 -lt $Rest.Count) {
                    $ht['Type'] = [string]$Rest[++$i]
                } elseif (-not $ht.ContainsKey('Title')) {
                    $ht['Title'] = [string]$Rest[$i]
                }
            }
            if (-not $ht.ContainsKey('Title') -or [string]::IsNullOrWhiteSpace($ht['Title'])) {
                Write-TmError "tm new: タイトルを指定してください。"
            }
            Invoke-TmNew @ht
        }
        'start' {
            if ($Rest.Count -eq 0) { Write-TmError "tm start: 連番または ISS-NNN/PHASE-MM を指定してください。" }
            $startArg = [string]$Rest[0]
            if ($startArg -match '^\d+$') {
                Invoke-TmStart ([int]$startArg)
            } elseif ($startArg -match '^ISS-\d{3}/PHASE-\d{2}$') {
                Invoke-TmStartByPhase $startArg
            } else {
                Write-TmError "tm start: 引数が不正です。整数または ISS-NNN/PHASE-MM 形式で指定してください。"
            }
        }
        'stop'   { Invoke-TmStop }
        'done'   { if ($Rest.Count -gt 0) { Invoke-TmDone  ([int]$Rest[0]) } else { Invoke-TmDone } }
        'list'   { Invoke-TmList }
        'log'    { Invoke-TmLog }
        'open'   { if ($Rest.Count -gt 0) { Invoke-TmOpen  ([int]$Rest[0]) } else { Invoke-TmOpen } }
        'report' {
            $ht = @{}
            for ($i = 0; $i -lt $Rest.Count; $i++) {
                switch ($Rest[$i]) {
                    '-Csv'   { $ht['Csv']   = $true }
                    '-Date'  { $ht['Date']  = [string]$Rest[++$i] }
                    '-Month' { $ht['Month'] = [string]$Rest[++$i] }
                }
            }
            Invoke-TmReport @ht
        }
        'fix' {
            $ht = @{}
            for ($i = 0; $i -lt $Rest.Count; $i++) {
                switch ($Rest[$i]) {
                    '-Session' { $ht['Session'] = [int]$Rest[++$i] }
                    '-Start'   { $ht['Start']   = [string]$Rest[++$i] }
                    '-Stop'    { $ht['Stop']    = [string]$Rest[++$i] }
                    '-Date'    { $ht['Date']    = [string]$Rest[++$i] }
                    default {
                        if (-not $ht.ContainsKey('Seq')) {
                            $ht['Seq'] = [int]$Rest[$i]
                        }
                    }
                }
            }
            if (-not $ht.ContainsKey('Seq')) { Write-TmError "tm fix: 連番を指定してください。" }
            Invoke-TmFix @ht
        }
        'rollover' {
            if ($Rest.Count -gt 0) {
                Write-TmError "tm rollover: 引数・オプションは受け付けません。"
            }
            Invoke-TmRollover
        }
        'issue' {
            if ($Rest.Count -eq 0) { Write-TmError "tm issue: サブコマンドを指定してください（new）。" }
            switch ([string]$Rest[0]) {
                'new' {
                    $title = if ($Rest.Count -gt 1) { [string]$Rest[1] } else { '' }
                    if ([string]::IsNullOrWhiteSpace($title)) {
                        Write-TmError "tm issue new: タイトルを指定してください。"
                    }
                    Invoke-TmIssueNew $title
                }
                default { Write-TmError "tm issue: 不明なサブコマンド: $([string]$Rest[0])" }
            }
        }
        ''      { Write-TmInfo "tm v$ScriptVersion - 使い方: tm <command> [options]`n  new / start / stop / done / list / log / open / report / fix / rollover / issue" }
        default { Write-TmError "不明なコマンド: $Command" }
    }
}

#endregion DISPATCH
