# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [Unreleased]

---

## [1.0.0] - 2026-05-07

### Added
- `tm issue new "タイトル"` コマンド: ISS-NNN を自動採番し `tasks/issues/ISS-NNN/issue.md` を生成する
  - `counters.json` の `iss` カウンターで採番・ロック管理（3桁ゼロ埋め）
  - issue.md はフロントマター（id / title / status / created）＋ 概要・工程テンプレートで生成
- `tm start ISS-NNN/PHASE-MM` 対応: 課題工程識別子で当日タスクを自動作成＋開始
  - 同識別子のタスクが既存の場合はそのタスクを開始（重複しない）
  - 別タスクが Running 中なら自動停止（既存ロジックを再利用）
  - 不正な識別子（整数でも `ISS-NNN/PHASE-MM` でもない）はエラー終了
- `Read-Counters` / `Write-Counters`: `counters.json` の読み書き実装（スタブ解消）
  - `ConvertFrom-Json` の PSCustomObject → hashtable 変換を含む
- `Get-NextIssNumber` / `Get-NextInqId`: カウンター採番ヘルパー関数
- INQ 自動採番: `tm new -Type INQ` 時に `INQ-YYYYMMDD-NN` をタイトル先頭に自動付与
  - 同日複数件は `01`, `02`... と連番（`counters.json` の `inq.YYYYMMDD` で管理）
  - `-Type MTG` / `-Type ISS` では採番しない
- `tests/manual/scenario-07-v10.ps1`: v1.0 機能の手動テストスクリプト（AC-C1〜C2, AC-I1〜I4, AC-N1〜N4, AC-P1〜P4 の 24 アサーション）

### Changed
- `tm start`: 引数を整数のみから `ISS-NNN/PHASE-MM` 形式も受け付けるよう拡張
- `$ScriptVersion` を `0.3.0` から `1.0.0` へ更新
- `tests/manual/scenario-02-interrupt.ps1`: INQ 自動採番に伴うタイトル照合パターンを更新

---

## [0.3.0] - 2026-05-05

### Added
- `tm rollover` コマンド: 直近の稼働日の Stopped タスクを当日の日次ファイルへ全件繰り越す
  - 直近の稼働日を当日前日から最大90日遡って自動特定（土日・連休を自動スキップ）
  - 繰越タスクは `hours = 0.00` リセット / セッション行 = 空で開始（二重計上防止）
  - `rolled_from: YYYY-MM-DD` フィールドを付与（繰越元の日付 兼 二重繰越チェックフラグ）
  - 繰越元ファイルは一切変更しない（原本を履歴として保持）
  - 2回実行しても安全（`rolled_from:` 付きタスクを検出して早期リターン）
- `tests/manual/scenario-06-rollover.ps1`: tm rollover の手動テストスクリプト（AC-23〜AC-39 を 12 ケース・55 アサーションで網羅）

### Changed
- `Read-DailyFile`: タスクオブジェクトに `RolledFrom` プロパティを追加（後方互換: フィールド不在の場合は `''`）
- `Read-DailyFile`: メタデータ行の正規表現を `^(\w+):` → `^([a-z_]+):` に変更（日本語メモ行の誤パース修正）
- `Write-DailyFile`: `RolledFrom` が空でなければ `rolled_from: YYYY-MM-DD` 行を出力する
- `Invoke-TmNew`: タスクオブジェクトに `RolledFrom = ''` を追加（Write-DailyFile との整合）
- `$ScriptVersion` を `0.2.0` から `0.3.0` へ更新

---

## [0.2.0] - 2026-05-04

### Added
- `tm fix` コマンド: セッションの開始・終了時刻を事後修正し、工数を再計算する
  - Stopped タスク: `-Start`/`-Stop`/`-Session <N>`/`-Date YYYY-MM-DD` の組み合わせで完了済みセッション行を修正
  - Running タスク: `-Session` 省略時に `-Start` のみ指定すると `running_since` だけを更新（hours・セッション行は不変）
  - 工数（hours）はセッション独立の15分丸め→合算で再計算（一括丸め禁止）
  - Done タスクは修正不可（exit 1）
- `tests/manual/scenario-05-fix.ps1`: tm fix の手動テストスクリプト（AC-01〜AC-22 + AC-18 補足を網羅）

### Changed
- `$ScriptVersion` を `0.1.0` から `0.2.0` へ更新

---

## [0.1.0] - 2026-05-04

### Added
- `tm new "タイトル" [-Type ISS|INQ|MTG]`: 日次タスクを作成する
- `tm start <連番>`: タスクの作業を開始する（別タスクが Running 中なら自動停止）
- `tm stop`: Running 中のタスクを一時停止する
- `tm done [<連番>]`: タスクを完了にする（引数なし = Running タスク / 連番 = Stopped タスク）
- `tm list`: 当日タスク一覧を表示する（状態・工数・種別）
- `tm log`: セッション詳細ログを時系列で表示する
- `tm open [<連番>]`: 当日の日次ファイルを VS Code で開く（連番指定でタスク行へジャンプ）
- `tm report [-Date YYYY-MM-DD | -Month YYYY-MM]`: 工数集計を表示する
- `tm report -Csv [-Date YYYY-MM-DD | -Month YYYY-MM]`: 集計をタブ区切りでクリップボードへコピーする（Excel 貼付用）
- 15分丸め工数計算（開始: 直前の15分境界へ切り捨て、終了: 直後の15分境界へ切り上げ）
- セッション独立丸め → 合算による複数セッション工数計算
- `$env:TM_ROOT` によるデータ保存先のカスタマイズ（既定: `$PSScriptRoot\tasks`）
- タスク状態管理: Stopped / Running / Done
- 15分丸め後セッション行 `[HH:MM-HH:MM] (X.XXh)` 形式でのメモ部記録
