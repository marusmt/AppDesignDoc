﻿#Requires -Version 5.1
# scenario-07-v10.ps1
# v1.0 機能をカバーするシナリオテスト
# AC-C1, AC-C2, AC-I1~I4, AC-N1~N4, AC-P1~P4

$ErrorActionPreference = 'Stop'
$env:TM_ROOT = Join-Path $env:TEMP 'tm-test-s07'

# サンドボックス初期化
if (Test-Path $env:TM_ROOT) { Remove-Item $env:TM_ROOT -Recurse -Force }

$tm = Join-Path $PSScriptRoot '..\..\tm.ps1'
$pass = 0; $fail = 0

function Assert {
    param([string]$Label, [scriptblock]$Check)
    try {
        $result = & $Check
        if ($result) { Write-Host "  [OK] $Label" -ForegroundColor Green; $script:pass++ }
        else         { Write-Host "  [NG] $Label" -ForegroundColor Red;   $script:fail++ }
    } catch {
        Write-Host "  [EX] $Label - $($_.Exception.Message)" -ForegroundColor Red
        $script:fail++
    }
}

function AssertExit1 {
    param([string]$Label, [scriptblock]$Cmd)
    try {
        & $Cmd 2>$null
        Write-Host "  [NG] $Label (exit 1 を期待したが成功した)" -ForegroundColor Red
        $script:fail++
    } catch {
        if ($_.Exception.Message -match 'exit' -or $LASTEXITCODE -eq 1) {
            Write-Host "  [OK] $Label" -ForegroundColor Green; $script:pass++
        } else {
            Write-Host "  [NG] $Label (予期しない例外: $($_.Exception.Message))" -ForegroundColor Red
            $script:fail++
        }
    }
}

# tm.ps1 をドットソースして内部関数を使えるようにする
function InvokeInternal {
    param([scriptblock]$Sb)
    & { . $tm; & $Sb }
}

$today = (Get-Date).ToString('yyyyMMdd')
$todayDash = (Get-Date).ToString('yyyy-MM-dd')

# ============================================================
# §1: COUNTER テスト (AC-C1, AC-C2)
# ============================================================
Write-Host "`n=== scenario-07: v1.0 機能テスト ==="
Write-Host "`n--- §1: COUNTER (AC-C1, AC-C2) ---"

# AC-C1: counters.json 不在時のデフォルト返却
Assert "AC-C1: counters.json 不在で Read-Counters がデフォルト値を返す" {
    $c = InvokeInternal { Read-Counters }
    ($c.iss -eq 0) -and ($c.inq -is [hashtable]) -and ($c.inq.Count -eq 0)
}

# AC-C2: Write-Counters → Read-Counters ラウンドトリップ
Assert "AC-C2: Write-Counters で書いた値を Read-Counters で読み取れる" {
    InvokeInternal {
        Write-Counters @{ iss = 5; inq = @{ '20260507' = 3 } }
        $c = Read-Counters
        ($c.iss -eq 5) -and ($c.inq['20260507'] -eq 3)
    }
}

# counters.json をリセットしてからテスト継続
InvokeInternal { Write-Counters @{ iss = 0; inq = @{} } }

# ============================================================
# §2: INQ 採番テスト (AC-I1~I4)
# ============================================================
Write-Host "`n--- §2: INQ 採番 (AC-I1~I4) ---"

# AC-I1: 初回採番で INQ-YYYYMMDD-01 が付く
& $tm new "問い合わせ1件目" -Type INQ
$dailyFile = Get-ChildItem (Join-Path $env:TM_ROOT 'daily') -Recurse -Filter '*.md' | Select-Object -First 1
$content   = Get-Content $dailyFile.FullName -Raw -Encoding UTF8

Assert "AC-I1: 初回 INQ が INQ-$today-01 で採番される" {
    $content -match "INQ-$today-01 問い合わせ1件目"
}

# AC-I2: 同日2回目は INQ-YYYYMMDD-02
& $tm new "問い合わせ2件目" -Type INQ
$content = Get-Content $dailyFile.FullName -Raw -Encoding UTF8

Assert "AC-I2: 同日2回目は INQ-$today-02 で採番される" {
    $content -match "INQ-$today-02 問い合わせ2件目"
}

# AC-I3: MTG は採番なし
& $tm new "定例朝会" -Type MTG
$content = Get-Content $dailyFile.FullName -Raw -Encoding UTF8

Assert "AC-I3: MTG タスクに INQ- プレフィックスがない" {
    ($content -match '定例朝会') -and ($content -notmatch 'INQ-.*定例朝会')
}

# AC-I4: ISS は採番なし
& $tm new "バグ調査" -Type ISS
$content = Get-Content $dailyFile.FullName -Raw -Encoding UTF8

Assert "AC-I4: ISS タスクに INQ- プレフィックスがない" {
    ($content -match 'バグ調査') -and ($content -notmatch 'INQ-.*バグ調査')
}

# ============================================================
# §3: tm issue new テスト (AC-N1~N4)
# ============================================================
Write-Host "`n--- §3: tm issue new (AC-N1~N4) ---"

# AC-N1: 正常採番・フォルダ・ファイル生成
$output = & $tm issue new "バグ調査タスク"
$issDir  = Join-Path $env:TM_ROOT 'issues\ISS-001'
$issFile = Join-Path $issDir 'issue.md'

Assert "AC-N1: ISS-001 フォルダが作成された" { Test-Path $issDir }
Assert "AC-N1: issue.md が生成された"         { Test-Path $issFile }
Assert "AC-N1: 出力に ISS-001 が含まれる"      { $output -match 'ISS-001' }

# AC-N2: 連続採番で ISS-002
& $tm issue new "機能改善タスク"
$issDir2 = Join-Path $env:TM_ROOT 'issues\ISS-002'

Assert "AC-N2: ISS-002 フォルダが作成された" { Test-Path $issDir2 }

# AC-N3: タイトル省略でエxit 1
$exitCode = 0
try {
    & $tm issue new 2>$null
} catch { }
$exitCode = $LASTEXITCODE
Assert "AC-N3: タイトル省略で exit 1" { $exitCode -eq 1 }

# AC-N4: issue.md のフォーマット確認
$issContent = Get-Content $issFile -Raw -Encoding UTF8

Assert "AC-N4: id フィールドが正しい"       { $issContent -match 'id: ISS-001' }
Assert "AC-N4: title フィールドが正しい"    { $issContent -match 'title: バグ調査タスク' }
Assert "AC-N4: status: Open が含まれる"     { $issContent -match 'status: Open' }
Assert "AC-N4: created フィールドが今日"    { $issContent -match "created: $todayDash" }
Assert "AC-N4: ## 概要 セクションがある"    { $issContent -match '## 概要' }
Assert "AC-N4: ## 工程 セクションがある"    { $issContent -match '## 工程' }
Assert "AC-N4: PHASE-01 行がある"          { $issContent -match 'PHASE-01' }

# ============================================================
# §4: ISS-NNN/PHASE-MM テスト (AC-P1~P4)
# ============================================================
Write-Host "`n--- §4: ISS-NNN/PHASE-MM (AC-P1~P4) ---"

# AC-P1: 当日タスクが存在しない場合、自動生成して開始
Start-Sleep -Seconds 1
& $tm start ISS-001/PHASE-01
$content = Get-Content $dailyFile.FullName -Raw -Encoding UTF8

Assert "AC-P1: ISS-001/PHASE-01 タスクが自動生成された"  { $content -match 'ISS-001/PHASE-01' }
Assert "AC-P1: 自動生成タスクが Running 状態"            { $content -match 'status: Running' }

# AC-P2: 既存タスクを開始（タスク重複なし）
& $tm stop
Start-Sleep -Seconds 1
$beforeCount = ([regex]::Matches((Get-Content $dailyFile.FullName -Raw -Encoding UTF8), 'ISS-001/PHASE-01')).Count
& $tm start ISS-001/PHASE-01
$afterCount  = ([regex]::Matches((Get-Content $dailyFile.FullName -Raw -Encoding UTF8), 'ISS-001/PHASE-01')).Count

Assert "AC-P2: 再 start で同タスクが Running になる（重複しない）" {
    ($afterCount -eq $beforeCount) -and
    ((Get-Content $dailyFile.FullName -Raw -Encoding UTF8) -match 'status: Running')
}

# AC-P3: 別タスクが Running 中のときに自動停止される
Start-Sleep -Seconds 1
& $tm start ISS-001/PHASE-02
$content = Get-Content $dailyFile.FullName -Raw -Encoding UTF8
$runningCount = ([regex]::Matches($content, 'status: Running')).Count

Assert "AC-P3: PHASE-02 開始で PHASE-01 が自動停止される（Running は1件）" {
    ($runningCount -eq 1) -and ($content -match 'ISS-001/PHASE-02')
}

# AC-P4: 不正識別子でエラー終了
& $tm stop 2>$null

$exitCode = 0
try { & $tm start 'ISS-001' 2>$null } catch { }
$exitCode = $LASTEXITCODE
Assert "AC-P4: ISS-001 単体（PHASE なし）は exit 1" { $exitCode -eq 1 }

$exitCode = 0
try { & $tm start 'abc-xxx' 2>$null } catch { }
$exitCode = $LASTEXITCODE
Assert "AC-P4: abc-xxx は exit 1" { $exitCode -eq 1 }

# ============================================================
# サマリ
# ============================================================
Write-Host "`n=== 結果 ==="
$total = $pass + $fail
Write-Host "PASS: $pass / $total"
if ($fail -gt 0) {
    Write-Host "FAIL: $fail" -ForegroundColor Red
    exit 1
} else {
    Write-Host "全テスト通過" -ForegroundColor Green
}
