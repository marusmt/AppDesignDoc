﻿#Requires -Version 5.1
# scenario-06-rollover.ps1
# v0.3 tm rollover コマンドのテスト
# 対象 AC: AC-23 / AC-24 / AC-25 / AC-26 / AC-27 / AC-28 / AC-29 / AC-30 / AC-31
#          AC-32 / AC-33 / AC-34 / AC-35 / AC-36 / AC-37 / AC-38 / AC-39

$ErrorActionPreference = 'Stop'
$env:TM_ROOT = Join-Path $env:TEMP 'tm-test-s06'

if (Test-Path $env:TM_ROOT) { Remove-Item $env:TM_ROOT -Recurse -Force }

$tm   = Join-Path $PSScriptRoot '..\..\tm.ps1'
$pass = 0; $fail = 0

function Assert {
    param([string]$Label, [scriptblock]$Check)
    try {
        $result = & $Check
        if ($result) { Write-Host "  [OK] $Label" -ForegroundColor Green; $script:pass++ }
        else         { Write-Host "  [NG] $Label" -ForegroundColor Red;   $script:fail++ }
    } catch {
        Write-Host "  [EX] $Label - $($_.Exception.Message)" -ForegroundColor Red
        $script:fail++
    }
}

# サブプロセスで実行して ExitCode と Output を取得
function RunTm {
    param([string[]]$ArgList)
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $result = powershell.exe -NoProfile -File $tm @ArgList 2>&1
    $ec = $LASTEXITCODE
    $ErrorActionPreference = $prev
    return [PSCustomObject]@{
        All      = $result
        Output   = @($result | Where-Object { $_ -isnot [System.Management.Automation.ErrorRecord] })
        ExitCode = $ec
    }
}

# 指定日の日次ファイルを直接書き込む
function Write-TestDailyFile {
    param([string]$DateStr, [string]$Content)
    $yyyy = $DateStr.Substring(0, 4)
    $mm   = $DateStr.Substring(5, 2)
    $dir  = Join-Path $env:TM_ROOT "daily\$yyyy\$mm"
    New-Item $dir -ItemType Directory -Force | Out-Null
    $path = Join-Path $dir "$DateStr.md"
    Set-Content -Path $path -Value $Content -Encoding UTF8
    return $path
}

# 指定日の日次ファイル内容を文字列で返す
function Get-TestDailyContent {
    param([string]$DateStr)
    $yyyy = $DateStr.Substring(0, 4)
    $mm   = $DateStr.Substring(5, 2)
    $path = Join-Path $env:TM_ROOT "daily\$yyyy\$mm\$DateStr.md"
    if (-not (Test-Path $path)) { return '' }
    return Get-Content -Path $path -Raw
}

# 指定日の日次ファイルが存在するか確認
function Test-DailyFileExists {
    param([string]$DateStr)
    $yyyy = $DateStr.Substring(0, 4)
    $mm   = $DateStr.Substring(5, 2)
    return Test-Path (Join-Path $env:TM_ROOT "daily\$yyyy\$mm\$DateStr.md")
}

# テスト環境をリセット（TM_ROOT を削除）
function Reset-TestEnv {
    if (Test-Path $env:TM_ROOT) { Remove-Item $env:TM_ROOT -Recurse -Force }
}

# ファイル内の ## [N] ヘッダ行数（タスク件数）を返す
function Count-Tasks {
    param([string]$Content)
    return ($Content -split "`r?`n" | Where-Object { $_ -match '^\#\# \[' }).Count
}

$today  = (Get-Date).ToString('yyyy-MM-dd')
$yday   = (Get-Date).AddDays(-1).ToString('yyyy-MM-dd')
$yday3  = (Get-Date).AddDays(-3).ToString('yyyy-MM-dd')
$yday95 = (Get-Date).AddDays(-95).ToString('yyyy-MM-dd')

Write-Host "`n=== scenario-06: tm rollover コマンドテスト ==="

# ============================================================
# ケース1: 標準ケース
# AC-23, AC-24, AC-27, AC-30, AC-31, AC-32, AC-33, AC-34, AC-35
# ============================================================
Write-Host "`n--- ケース1: 標準ケース ---"
Reset-TestEnv

$src1 = @"
---
date: $yday
---

## [1] ログイン障害の調査 (#11234)
type: ISS
status: Stopped
hours: 1.50
formal_id:

[09:00-10:30] (1.50h)

前日メモ: セッションタイムアウトが原因と判明

---

## [2] 設計レビュー対応
type: ISS
status: Stopped
hours: 0.50
formal_id:

[10:30-11:00] (0.50h)

---

## [3] 定例朝会
type: MTG
status: Done
hours: 0.50
formal_id:

[09:00-09:30] (0.50h)

---
"@

$srcPath   = Write-TestDailyFile $yday $src1
$srcBefore = Get-Content -Path $srcPath -Raw

$out1     = RunTm 'rollover'
$srcAfter = Get-Content -Path $srcPath -Raw
$c1       = Get-TestDailyContent $today
$txt1     = $out1.Output -join "`n"

Assert "ケース1-01: exit 0 (AC-23)"                                   { $out1.ExitCode -eq 0 }
Assert "ケース1-02: 出力1行目に直近の稼働日 (AC-33)"                  { $out1.Output[0] -eq "直近の稼働日: $yday" }
Assert "ケース1-03: タスク行に [N] タイトル TYPE が出力された (AC-33)" { $txt1 -match '\[\d+\] ログイン障害の調査 \(#11234\)' -and $txt1 -match 'ISS' }
Assert "ケース1-04: 最終行に件数メッセージ (AC-33)"                   { $out1.Output[-1] -eq '2 件のタスクを繰り越しました' }
Assert "ケース1-05: hours が出力に含まれない (AC-34)"                  { $txt1 -notmatch '1\.50' -and $txt1 -notmatch '0\.50h' }
Assert "ケース1-06: 当日ファイルが生成された"                          { Test-DailyFileExists $today }
Assert "ケース1-07: rolled_from に昨日の日付が設定された (AC-30,32)"   { $c1 -match "rolled_from: $yday" }
Assert "ケース1-08: 当日タスクの hours が 0.00 (AC-30)" {
    ($c1 -split "`r?`n" | Where-Object { $_ -match '^hours:' } | Where-Object { $_ -match '0\.00' }).Count -ge 1
}
Assert "ケース1-09: セッション行なし (AC-30)"                          { $c1 -notmatch '\[\d{2}:\d{2}-\d{2}:\d{2}\]' }
Assert "ケース1-10: タイトルが引き継がれた (AC-31)"                    { $c1 -match 'ログイン障害の調査 \(#11234\)' }
Assert "ケース1-11: type が引き継がれた (AC-31)"                       { $c1 -match 'type: ISS' }
Assert "ケース1-12: status: Stopped が引き継がれた (AC-31)"            { $c1 -match 'status: Stopped' }
Assert "ケース1-13: メモ行が引き継がれた (AC-31)"                      { $c1 -match '前日メモ: セッションタイムアウトが原因と判明' }
Assert "ケース1-14: rolled_from が formal_id の直後 (AC-32)" {
    $lines = $c1 -split "`r?`n"
    $found = $false
    for ($i = 0; $i -lt ($lines.Count - 1); $i++) {
        if ($lines[$i] -match '^formal_id:' -and $lines[$i + 1] -match '^rolled_from:') {
            $found = $true; break
        }
    }
    $found
}
Assert "ケース1-15: 繰越元ファイルが変更されていない (AC-35)"           { $srcBefore -eq $srcAfter }
Assert "ケース1-16: 当日ファイルのタスク数が2件（Stopped 2件のみ）(AC-27)" { (Count-Tasks $c1) -eq 2 }
Assert "ケース1-17: Done タスク（定例朝会）が繰越されていない (AC-27)" { $c1 -notmatch '定例朝会' }

# ============================================================
# ケース2: 連休明け（AC-24）
# ============================================================
Write-Host "`n--- ケース2: 連休明け ---"
Reset-TestEnv

$src2 = @"
---
date: $yday3
---

## [1] 連休前の未完タスク
type: ISS
status: Stopped
hours: 1.00
formal_id:

[14:00-15:00] (1.00h)

---
"@

Write-TestDailyFile $yday3 $src2 | Out-Null
# yday と yday2 にはファイルを作らない（連休中）

$out2  = RunTm 'rollover'
$txt2  = $out2.Output -join "`n"
$c2    = Get-TestDailyContent $today

Assert "ケース2-01: exit 0 (AC-24)"                                    { $out2.ExitCode -eq 0 }
Assert "ケース2-02: 3日前が直近稼働日として出力された (AC-24)"          { $txt2 -match "直近の稼働日: $yday3" }
Assert "ケース2-03: 当日ファイルの rolled_from が3日前 (AC-24)"         { $c2 -match "rolled_from: $yday3" }

# ============================================================
# ケース3: 二重実行（AC-26）
# ============================================================
Write-Host "`n--- ケース3: 二重実行 ---"
Reset-TestEnv

$src3 = @"
---
date: $yday
---

## [1] 未完タスク
type: ISS
status: Stopped
hours: 0.50
formal_id:

---
"@

Write-TestDailyFile $yday $src3 | Out-Null

$out3a         = RunTm 'rollover'
$out3b         = RunTm 'rollover'
$c3After2nd    = Get-TestDailyContent $today

Assert "ケース3-01: 1回目 exit 0"                                      { $out3a.ExitCode -eq 0 }
Assert "ケース3-02: 2回目 exit 0 (AC-26)"                              { $out3b.ExitCode -eq 0 }
Assert "ケース3-03: タスクが重複していない (AC-26)"                    { (Count-Tasks $c3After2nd) -eq 1 }
Assert "ケース3-04: 2回目の出力に繰越実行済みメッセージ (AC-26)" {
    ($out3b.All | ForEach-Object { "$_" }) -match '繰越実行済み'
}

# ============================================================
# ケース4: 90日上限（AC-25）
# ============================================================
Write-Host "`n--- ケース4: 90日上限 ---"
Reset-TestEnv

$src4 = @"
---
date: $yday95
---

## [1] 大昔のタスク
type: ISS
status: Stopped
hours: 1.00
formal_id:

---
"@

Write-TestDailyFile $yday95 $src4 | Out-Null

$out4 = RunTm 'rollover'

Assert "ケース4-01: exit 0 (AC-25)"                                    { $out4.ExitCode -eq 0 }
Assert "ケース4-02: 当日ファイルが生成されていない (AC-25)"             { -not (Test-DailyFileExists $today) }
Assert "ケース4-03: 警告メッセージに90日が含まれる (AC-25)" {
    ($out4.All | ForEach-Object { "$_" }) -match '90日'
}

# ============================================================
# ケース5: Stopped 0件（AC-39）
# ============================================================
Write-Host "`n--- ケース5: Stopped 0件 ---"
Reset-TestEnv

$src5 = @"
---
date: $yday
---

## [1] 完了済みタスク
type: ISS
status: Done
hours: 2.00
formal_id:

[09:00-11:00] (2.00h)

---

## [2] 進行中タスク（stop し忘れ）
type: INQ
status: Running
hours: 0.00
running_since: 14:00
formal_id:

---
"@

Write-TestDailyFile $yday $src5 | Out-Null

$out5  = RunTm 'rollover'
$txt5  = $out5.Output -join "`n"

Assert "ケース5-01: exit 0 (AC-39)"                                    { $out5.ExitCode -eq 0 }
Assert "ケース5-02: 繰越対象なしメッセージ (AC-39)"                    { $txt5 -match "繰越対象なし（直近の稼働日: $yday）" }
Assert "ケース5-03: 当日ファイルが生成されていない"                     { -not (Test-DailyFileExists $today) }

# ============================================================
# ケース6: Running 混在（AC-27, AC-28）
# ============================================================
Write-Host "`n--- ケース6: Running 混在 ---"
Reset-TestEnv

$src6 = @"
---
date: $yday
---

## [1] Stopped タスク（繰越対象）
type: ISS
status: Stopped
hours: 1.00
formal_id:

[09:00-10:00] (1.00h)

---

## [2] Running タスク（stop し忘れ・繰越対象外）
type: INQ
status: Running
hours: 0.00
running_since: 10:00
formal_id:

---
"@

Write-TestDailyFile $yday $src6 | Out-Null

$out6 = RunTm 'rollover'
$c6   = Get-TestDailyContent $today

Assert "ケース6-01: exit 0 (AC-27)"                                    { $out6.ExitCode -eq 0 }
Assert "ケース6-02: 当日ファイルに1件のみ (AC-27, AC-28)"              { (Count-Tasks $c6) -eq 1 }
Assert "ケース6-03: Stopped タスクが繰越された (AC-27)"                { $c6 -match 'Stopped タスク（繰越対象）' }
Assert "ケース6-04: Running タスクが繰越されていない (AC-28)"           { $c6 -notmatch 'Running タスク（stop し忘れ' }

# ============================================================
# ケース7: 当日ファイルなし（AC-29）
# ＋ ステップ5とステップ1の連動確認（重点確認）
# ============================================================
Write-Host "`n--- ケース7: 当日ファイルなし ---"
Reset-TestEnv

$src7 = @"
---
date: $yday
---

## [1] 前日タスク
type: ISS
status: Stopped
hours: 0.75
formal_id:

[09:00-09:45] (0.75h)

---
"@

Write-TestDailyFile $yday $src7 | Out-Null

$out7 = RunTm 'rollover'
$c7   = Get-TestDailyContent $today

Assert "ケース7-01: exit 0 (AC-29)"                                    { $out7.ExitCode -eq 0 }
Assert "ケース7-02: 当日ファイルが自動生成された (AC-29)"               { Test-DailyFileExists $today }
Assert "ケース7-03: 繰越タスクが当日ファイルに存在する (AC-29)"         { $c7 -match '前日タスク' }

# 重点確認: ファイル自動生成後に再実行しても AC-26 が正常発火すること
$out7b = RunTm 'rollover'
Assert "ケース7-04: 再実行で AC-26 警告（step5→step1 連動）" {
    $out7b.ExitCode -eq 0 -and
    (($out7b.All | ForEach-Object { "$_" }) -match '繰越実行済み')
}

# ============================================================
# ケース8: 不正引数（AC-23）
# ============================================================
Write-Host "`n--- ケース8: 不正引数 ---"
Reset-TestEnv

$out8 = RunTm 'rollover', 'extra_arg'

Assert "ケース8-01: exit 1 (AC-23)"                                    { $out8.ExitCode -eq 1 }
Assert "ケース8-02: エラーメッセージに rollover が含まれる (AC-23)"     {
    ($out8.All | ForEach-Object { "$_" }) -match 'rollover'
}

# ============================================================
# ケース9: 後方互換 — v0.2 形式（rolled_from 行なし）（AC-37）
# ============================================================
Write-Host "`n--- ケース9: 後方互換（v0.2形式ファイル） ---"
Reset-TestEnv

# rolled_from フィールドが存在しない v0.2 形式のファイル
$src9 = @"
---
date: $yday
---

## [1] 旧形式タスク
type: ISS
status: Stopped
hours: 1.25
formal_id:

[09:00-10:15] (1.25h)

---
"@

Write-TestDailyFile $yday $src9 | Out-Null

$out9 = RunTm 'rollover'
$c9   = Get-TestDailyContent $today

Assert "ケース9-01: エラーなし exit 0 (AC-37)"                         { $out9.ExitCode -eq 0 }
Assert "ケース9-02: v0.2形式ファイルからも繰越成功 (AC-37)"            { $c9 -match '旧形式タスク' }
Assert "ケース9-03: 繰越後ファイルに rolled_from が付与された (AC-37)" { $c9 -match "rolled_from: $yday" }

# ============================================================
# ケース10: tm report 影響なし（AC-36）
# ============================================================
Write-Host "`n--- ケース10: tm report 影響なし ---"
Reset-TestEnv

$month = (Get-Date).ToString('yyyy-MM')

$src10 = @"
---
date: $yday
---

## [1] 昨日の作業
type: ISS
status: Stopped
hours: 1.50
formal_id:

[09:00-10:30] (1.50h)

---
"@

Write-TestDailyFile $yday $src10 | Out-Null
RunTm 'rollover' | Out-Null

$c10        = Get-TestDailyContent $today
$outReport  = RunTm 'report', '-Month', $month
$reportText = $outReport.Output -join "`n"

Assert "ケース10-01: report exit 0 (AC-36)"                            { $outReport.ExitCode -eq 0 }
Assert "ケース10-02: 当日の繰越タスクは hours 0.00 (AC-36)"            {
    ($c10 -split "`r?`n" | Where-Object { $_ -match '^hours:' } | Where-Object { $_ -match '0\.00' }).Count -ge 1
}
Assert "ケース10-03: 月次合計が二重計上なし（3.00h が現れない）(AC-36)" {
    $reportText -match '合計' -and $reportText -notmatch '3\.00'
}

# ============================================================
# ケース11: rolled_from 出力確認（AC-38）
# ============================================================
Write-Host "`n--- ケース11: rolled_from 出力確認 ---"
Reset-TestEnv

# 当日ファイルに既存タスク1件（rolled_from なし）
$today11 = @"
---
date: $today
---

## [1] 当日の新規タスク
type: ISS
status: Stopped
hours: 0.00
formal_id:

---
"@

Write-TestDailyFile $today $today11 | Out-Null

# 昨日のファイルに Stopped 2件
$src11 = @"
---
date: $yday
---

## [1] 繰越対象タスクA
type: ISS
status: Stopped
hours: 0.75
formal_id:

---

## [2] 繰越対象タスクB
type: MTG
status: Stopped
hours: 0.50
formal_id:

---
"@

Write-TestDailyFile $yday $src11 | Out-Null
RunTm 'rollover' | Out-Null

$c11 = Get-TestDailyContent $today

Assert "ケース11-01: 当日ファイルに3件（既存1件＋繰越2件）"             { (Count-Tasks $c11) -eq 3 }
Assert "ケース11-02: 繰越タスクに rolled_from: が2行ある (AC-38)" {
    ($c11 -split "`r?`n" | Where-Object { $_ -match "^rolled_from: $yday" }).Count -eq 2
}
Assert "ケース11-03: 既存タスク [1] に rolled_from: がない (AC-38)" {
    # [1] タスクブロック（## [2] 出現前まで）に rolled_from が含まれない
    $task1Block = ($c11 -split '## \[2\]')[0]
    $task1Block -notmatch 'rolled_from:'
}
Assert "ケース11-04: 繰越タスクが [2][3] に採番された (AC-30)" {
    $c11 -match '\[2\] 繰越対象タスクA' -and $c11 -match '\[3\] 繰越対象タスクB'
}

# ============================================================
# ケース12: 再繰越（AC-32）
# 注: MemoLines は仕様としてコピーされる（AC-31）。
#     3日連続で繰越すると MemoLines が多重化するが、これは仕様どおり。
# ============================================================
Write-Host "`n--- ケース12: 再繰越 ---"
Reset-TestEnv

$oldDate = '2026-04-01'

# 昨日のファイルに、すでに rolled_from が設定済みのタスクを配置
$src12 = @"
---
date: $yday
---

## [1] 再繰越対象タスク
type: ISS
status: Stopped
hours: 0.00
formal_id:
rolled_from: $oldDate

作業メモ: 調査継続中（2日目）

---
"@

Write-TestDailyFile $yday $src12 | Out-Null

$out12 = RunTm 'rollover'
$c12   = Get-TestDailyContent $today

Assert "ケース12-01: exit 0"                                           { $out12.ExitCode -eq 0 }
Assert "ケース12-02: rolled_from が昨日の日付で上書きされた (AC-32)"   { $c12 -match "rolled_from: $yday" }
Assert "ケース12-03: 古い rolled_from 値が残っていない (AC-32)"         { $c12 -notmatch "rolled_from: $oldDate" }
Assert "ケース12-04: rolled_from 行が1行のみ (AC-32)" {
    ($c12 -split "`r?`n" | Where-Object { $_ -match '^rolled_from:' }).Count -eq 1
}
Assert "ケース12-05: MemoLines が引き継がれた（仕様 AC-31）" {
    $c12 -match '作業メモ: 調査継続中（2日目）'
}

# ============================================================
# サマリ
# ============================================================
Write-Host "`n=== 結果 ==="
Write-Host "PASS: $pass" -ForegroundColor Green
if ($fail -eq 0) {
    Write-Host "FAIL: $fail" -ForegroundColor Green
} else {
    Write-Host "FAIL: $fail" -ForegroundColor Red
}
