﻿#Requires -Version 5.1
# scenario-03-counter-lock.ps1
# Invoke-WithCounterLock のロック生成・解放・例外時クリーンアップを確認

$ErrorActionPreference = 'Stop'
$env:TM_ROOT = Join-Path $env:TEMP 'tm-test-s03'

if (Test-Path $env:TM_ROOT) { Remove-Item $env:TM_ROOT -Recurse -Force }

# tm.ps1 を dot-source して関数を読み込む
. (Join-Path $PSScriptRoot '..\..\tm.ps1') 'list' 2>$null   # DISPATCH を無害コマンドで空打ち
# 再度 dot-source で関数を取り込む
. (Join-Path $PSScriptRoot '..\..\tm.ps1')

$pass = 0; $fail = 0
$lockPath = Join-Path (Get-TmRoot) 'config\counters.lock'

function Assert {
    param([string]$Label, [scriptblock]$Check)
    try {
        $result = & $Check
        if ($result) { Write-Host "  [OK] $Label" -ForegroundColor Green; $script:pass++ }
        else         { Write-Host "  [NG] $Label" -ForegroundColor Red;   $script:fail++ }
    } catch {
        Write-Host "  [EX] $Label - $($_.Exception.Message)" -ForegroundColor Red
        $script:fail++
    }
}

Write-Host "`n=== scenario-03: Invoke-WithCounterLock 動作確認 ==="

# 呼び出し前: ロックファイルが存在しない
Write-Host "`n--- 呼び出し前 ---"
Assert "counters.lock が存在しない（初期状態）" { -not (Test-Path $lockPath) }

# ロック中: スクリプトブロック内で Test-Path を実行
Write-Host "`n--- ロック中の確認 ---"
$lockExistedDuring = $false
Invoke-WithCounterLock {
    $script:lockExistedDuring = Test-Path $script:lockPath
}
Assert "呼び出し中はロックファイルが存在した" { $lockExistedDuring }

# 呼び出し後: ロックファイルが削除されている
Write-Host "`n--- 呼び出し後 ---"
Assert "呼び出し後は counters.lock が削除されている" { -not (Test-Path $lockPath) }

# 例外発生時: finally でロックが解放される
Write-Host "`n--- 例外発生時のクリーンアップ ---"
$exceptionThrown = $false
try {
    Invoke-WithCounterLock {
        throw "テスト用例外"
    }
} catch {
    $exceptionThrown = ($_.Exception.Message -eq "テスト用例外")
}
Assert "例外が正しく伝播した"                         { $exceptionThrown }
Assert "例外発生後もロックファイルが削除されている"   { -not (Test-Path $lockPath) }

Write-Host "`n=== 結果: PASS $pass / FAIL $fail ==="
if ($fail -gt 0) { exit 1 }
