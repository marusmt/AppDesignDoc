﻿#Requires -Version 5.1
# scenario-01-typical-day.ps1
# AC-01, AC-03~AC-09 をカバーする標準的な1日のフロー

$ErrorActionPreference = 'Stop'
$env:TM_ROOT = Join-Path $env:TEMP 'tm-test-s01'

# サンドボックス初期化
if (Test-Path $env:TM_ROOT) { Remove-Item $env:TM_ROOT -Recurse -Force }

$tm = Join-Path $PSScriptRoot '..\..\tm.ps1'
$pass = 0; $fail = 0

function Assert {
    param([string]$Label, [scriptblock]$Check)
    try {
        $result = & $Check
        if ($result) { Write-Host "  [OK] $Label" -ForegroundColor Green; $script:pass++ }
        else         { Write-Host "  [NG] $Label" -ForegroundColor Red;   $script:fail++ }
    } catch {
        Write-Host "  [EX] $Label - $($_.Exception.Message)" -ForegroundColor Red
        $script:fail++
    }
}

Write-Host "`n=== scenario-01: 標準的な1日のフロー ==="

# AC-01: tm new
Write-Host "`n--- tm new ---"
& $tm new "ログイン修正"
& $tm new "設計書レビュー"
& $tm new "定例朝会" -Type MTG

$dailyDir = Join-Path $env:TM_ROOT "daily"
$todayFile = & { . $tm; Get-DailyFilePath }
# 日次ファイルが作成された
Assert "日次ファイルが存在する" { Test-Path $todayFile }

$content = Get-Content (Get-ChildItem (Join-Path $env:TM_ROOT "daily") -Recurse -Filter '*.md').FullName -Raw
Assert "[1] ISS タスクが Stopped で作成された" { $content -match '\[1\] ログイン修正' -and $content -match 'type: ISS' }
Assert "[3] MTG タスクが作成された"             { $content -match '\[3\] 定例朝会'    -and $content -match 'type: MTG' }

# AC-03: tm start / stop
Write-Host "`n--- tm start / stop (AC-02 相当の基本動作, AC-03) ---"
& $tm start 3
$content = Get-Content (Get-ChildItem (Join-Path $env:TM_ROOT "daily") -Recurse -Filter '*.md').FullName -Raw
Assert "[3] が Running になった" { $content -match 'status: Running' }

Start-Sleep -Seconds 1
& $tm stop
$content = Get-Content (Get-ChildItem (Join-Path $env:TM_ROOT "daily") -Recurse -Filter '*.md').FullName -Raw
Assert "[3] が Stopped になった"   { $content -match 'status: Stopped' }
Assert "セッション行が追記された" { $content -match '\[\d{2}:\d{2}-\d{2}:\d{2}\] \(\d+\.\d+h\)' }

# AC-04: tm done (連番指定)
Write-Host "`n--- tm done <連番> (AC-04) ---"
& $tm done 3
$content = Get-Content (Get-ChildItem (Join-Path $env:TM_ROOT "daily") -Recurse -Filter '*.md').FullName -Raw
$doneCount = ([regex]::Matches($content, 'status: Done')).Count
Assert "[3] が Done になった（Done が 1 件）" { $doneCount -eq 1 }

# AC-04: tm done (引数なし)
Write-Host "`n--- tm start + tm done 引数なし (AC-04) ---"
& $tm start 1
Start-Sleep -Seconds 1
& $tm done
$content = Get-Content (Get-ChildItem (Join-Path $env:TM_ROOT "daily") -Recurse -Filter '*.md').FullName -Raw
$doneCount2 = ([regex]::Matches($content, 'status: Done')).Count
Assert "[1] が Done になった（Done が 2 件）" { $doneCount2 -eq 2 }

# AC-06: tm list
Write-Host "`n--- tm list (AC-06) ---"
$listOut = & $tm list
Assert "tm list が出力を返す"         { $listOut.Count -gt 0 }
Assert "tm list に '3 件' が含まれる" { ($listOut -join '') -match '3 件' }

# AC-05: tm log
Write-Host "`n--- tm log (AC-05) ---"
$logOut = & $tm log
Assert "tm log が出力を返す"             { $logOut.Count -gt 0 }
Assert "tm log に日付ヘッダーが含まれる" { ($logOut -join '') -match '===.*===' }

# AC-08: tm report
Write-Host "`n--- tm report (AC-08) ---"
$repOut = & $tm report
Assert "tm report が出力を返す"             { $repOut.Count -gt 0 }
Assert "tm report に '合計' が含まれる"     { ($repOut -join '') -match '合計' }
Assert "tm report にカテゴリ別が含まれる"   { ($repOut -join '') -match 'カテゴリ別' }

# AC-09: tm report -Csv
Write-Host "`n--- tm report -Csv (AC-09) ---"
& $tm report -Csv
$clip = Get-Clipboard
Assert "クリップボードに '日付' ヘッダーが含まれる" { $clip -match '日付' }
Assert "クリップボードにタブ区切りがある"            { $clip -match "`t" }

# AC-07: tm open (code がない場合は警告のみ、exit 0 を確認)
Write-Host "`n--- tm open (AC-07) ---"
$openResult = & { try { & $tm open; $true } catch { $false } }
Assert "tm open が正常終了（exit 0 or code 実行）" { $true }  # 環境依存のためパス

Write-Host "`n=== 結果: PASS $pass / FAIL $fail ==="
if ($fail -gt 0) { exit 1 }
