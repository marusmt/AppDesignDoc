﻿#Requires -Version 5.1
# scenario-02-interrupt.ps1
# AC-02 をカバーする割り込み対応フロー（自動 Stopped の確認）

$ErrorActionPreference = 'Stop'
$env:TM_ROOT = Join-Path $env:TEMP 'tm-test-s02'

if (Test-Path $env:TM_ROOT) { Remove-Item $env:TM_ROOT -Recurse -Force }

$tm = Join-Path $PSScriptRoot '..\..\tm.ps1'
$pass = 0; $fail = 0

function Assert {
    param([string]$Label, [scriptblock]$Check)
    try {
        $result = & $Check
        if ($result) { Write-Host "  [OK] $Label" -ForegroundColor Green; $script:pass++ }
        else         { Write-Host "  [NG] $Label" -ForegroundColor Red;   $script:fail++ }
    } catch {
        Write-Host "  [EX] $Label - $($_.Exception.Message)" -ForegroundColor Red
        $script:fail++
    }
}

function GetContent {
    $f = (Get-ChildItem (Join-Path $env:TM_ROOT "daily") -Recurse -Filter '*.md' | Select-Object -First 1).FullName
    Get-Content -Path $f -Raw
}

Write-Host "`n=== scenario-02: 割り込み対応フロー ==="

# セットアップ
Write-Host "`n--- セットアップ: タスク作成 ---"
& $tm new "作業中タスク"
& $tm new "割り込みタスク" -Type INQ

# [1] を Running にする
Write-Host "`n--- [1] を start ---"
& $tm start 1
$c = GetContent
Assert "[1] が Running になった" { $c -match '## \[1\][\s\S]*?status: Running' }
Assert "[2] が Stopped のまま"   { $c -match '## \[2\][\s\S]*?status: Stopped' }

# [2] を start → [1] が自動 Stopped になる（AC-02）
Write-Host "`n--- [2] を start → [1] が自動 Stopped (AC-02) ---"
Start-Sleep -Seconds 1
& $tm start 2
$c = GetContent

# [1] が Stopped になったことを確認
Assert "[1] が自動 Stopped になった" {
    $c -match '## \[1\] 作業中タスク\r?\ntype: ISS\r?\nstatus: Stopped'
}
Assert "[2] が Running になった" {
    # v1.0: -Type INQ により INQ-YYYYMMDD-NN プレフィックスが付くためタイトル部分のみ照合
    $c -match '## \[2\] INQ-\d{8}-\d{2} 割り込みタスク\r?\ntype: INQ\r?\nstatus: Running'
}
Assert "[1] にセッション行が追記された" {
    # [1] セクション内にセッション行がある（[2] のタイトルは INQ プレフィックス付き）
    $c -match '\[1\] 作業中タスク[\s\S]*?\[\d{2}:\d{2}-\d{2}:\d{2}\][\s\S]*?\[2\] INQ-\d{8}-\d{2} 割り込みタスク'
}

# [2] を完了
Write-Host "`n--- [2] を done ---"
& $tm done
$c = GetContent
Assert "[2] が Done になった" { $c -match '## \[2\][\s\S]*?status: Done' }

# [1] を再開
Write-Host "`n--- [1] を再開 (start 1) ---"
& $tm start 1
$c = GetContent
Assert "[1] が Running に戻った" { $c -match '## \[1\][\s\S]*?status: Running' }

# [1] を完了
Write-Host "`n--- [1] を done 1 ---"
Start-Sleep -Seconds 1
& $tm done 1
$c = GetContent
$doneCount = ([regex]::Matches($c, 'status: Done')).Count
Assert "[1] が Done になった（Done 2件）" { $doneCount -eq 2 }

# [1] のセッション行が2件あることを確認（start→stop→start→done）
$task1Section = [regex]::Match($c, '## \[1\] 作業中タスク([\s\S]*?)(?=## \[2\]|$)').Groups[1].Value
$sessionCount = ([regex]::Matches($task1Section, '\[\d{2}:\d{2}-\d{2}:\d{2}\]')).Count
Assert "[1] にセッション行が2件ある（割り込み前後）" { $sessionCount -eq 2 }

Write-Host "`n=== 結果: PASS $pass / FAIL $fail ==="
if ($fail -gt 0) { exit 1 }
