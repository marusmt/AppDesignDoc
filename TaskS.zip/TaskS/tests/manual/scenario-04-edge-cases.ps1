﻿#Requires -Version 5.1
# scenario-04-edge-cases.ps1
# T-21 エッジケース 7 件を網羅（M1・S2 対応含む）

$ErrorActionPreference = 'Stop'
$env:TM_ROOT = Join-Path $env:TEMP 'tm-test-edge'

if (Test-Path $env:TM_ROOT) { Remove-Item $env:TM_ROOT -Recurse -Force }

$tm   = Join-Path $PSScriptRoot '..\..\tm.ps1'
$pass = 0; $fail = 0

function Assert {
    param([string]$Label, [scriptblock]$Check)
    try {
        $result = & $Check
        if ($result) { Write-Host "  [OK] $Label" -ForegroundColor Green; $script:pass++ }
        else         { Write-Host "  [NG] $Label" -ForegroundColor Red;   $script:fail++ }
    } catch {
        Write-Host "  [EX] $Label - $($_.Exception.Message)" -ForegroundColor Red
        $script:fail++
    }
}

function RunTm {
    param([string[]]$ArgList)
    # $ErrorActionPreference を一時的に下げて native command の stderr を受け取る
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $result = powershell.exe -NoProfile -File $tm @ArgList 2>&1
    $ec = $LASTEXITCODE
    $ErrorActionPreference = $prev
    return [PSCustomObject]@{
        All      = $result
        Output   = @($result | Where-Object { $_ -isnot [System.Management.Automation.ErrorRecord] })
        Errors   = @($result | Where-Object { $_ -is  [System.Management.Automation.ErrorRecord] })
        ExitCode = $ec
    }
}

Write-Host "`n=== scenario-04: エッジケース検証 ==="

# ケース 1: tm stop（Running なし）→ exit 0（警告は Warning ストリームなのでキャプチャ不可）
Write-Host "`n--- Case 1: tm stop (Running なし) ---"
$r = RunTm @('stop')
Assert "exit 0（Warn + return）" { $r.ExitCode -eq 0 }

# ケース 2: tm done（Running なし）→ exit 0
Write-Host "`n--- Case 2: tm done (Running なし) ---"
$r = RunTm @('done')
Assert "exit 0（Warn + return）" { $r.ExitCode -eq 0 }

# ケース 3: tm start（引数なし）→ Error + exit 1（S2 対応）
Write-Host "`n--- Case 3: tm start (引数なし) ---"
$r = RunTm @('start')
Assert "exit 1"               { $r.ExitCode -eq 1 }
Assert "エラーメッセージあり" { ($r.Output -join '') -match 'tm:' }

# ケース 4: tm start 999（存在しない連番）→ Error + exit 1
Write-Host "`n--- Case 4: tm start 999 (存在しない連番) ---"
$r = RunTm @('start', '999')
Assert "exit 1"               { $r.ExitCode -eq 1 }
Assert "エラーメッセージあり" { ($r.Output -join '') -match 'tm:' }

# セットアップ: 以降のケース用にタスクを作成して Done にしておく
& $tm new "テストタスク" 2>$null
$r = RunTm @('done', '1')   # Stopped → Done（工数 0 で直接 Done）
# ケース 5: tm done <Done タスクの連番> → Warning + exit 0
Write-Host "`n--- Case 5: tm done <Done タスク> ---"
$r = RunTm @('done', '1')
Assert "exit 0（既に Done）"  { $r.ExitCode -eq 0 }

# ケース 6: tm new（タイトル省略）→ Error + exit 1（M1 対応）
Write-Host "`n--- Case 6a: tm new (タイトル省略) ---"
$r = RunTm @('new')
Assert "exit 1"               { $r.ExitCode -eq 1 }
Assert "エラーメッセージあり" { ($r.Output -join '') -match 'tm:' }

Write-Host "`n--- Case 6b: tm new -Type MTG (タイトルなし) ---"
$r = RunTm @('new', '-Type', 'MTG')
Assert "exit 1"               { $r.ExitCode -eq 1 }
Assert "エラーメッセージあり" { ($r.Output -join '') -match 'tm:' }

# ケース 7: tm new "x" -Type INVALID → Error + exit 1
Write-Host "`n--- Case 7: tm new -Type INVALID ---"
$r = RunTm @('new', 'テスト', '-Type', 'INVALID')
Assert "exit 1"               { $r.ExitCode -eq 1 }
Assert "エラーメッセージあり" { ($r.Output -join '') -match 'tm:' }

# ケース 8: 日次ファイルなしで tm list / tm log → Info + exit 0
Write-Host "`n--- Case 8: 日次ファイルなし → tm list / tm log ---"
$env:TM_ROOT = Join-Path $env:TEMP 'tm-test-edge-empty'
if (Test-Path $env:TM_ROOT) { Remove-Item $env:TM_ROOT -Recurse -Force }

$r = RunTm @('list')
Assert "tm list exit 0"             { $r.ExitCode -eq 0 }
Assert "tm list '記録はありません'" { ($r.Output -join '') -match '記録.*ありません' }

$r = RunTm @('log')
Assert "tm log exit 0"              { $r.ExitCode -eq 0 }
Assert "tm log '記録はありません'"  { ($r.Output -join '') -match '記録.*ありません' }

Write-Host "`n=== 結果: PASS $pass / FAIL $fail ==="
if ($fail -gt 0) { exit 1 }
