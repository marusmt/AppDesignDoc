﻿#Requires -Version 5.1
# scenario-05-fix.ps1
# v0.2 tm fix コマンドのテスト
# AC-01 / AC-02 / AC-03 / AC-04 / AC-05 / AC-06 / AC-07 / AC-08 / AC-09 / AC-10
# AC-11 / AC-12 / AC-13 / AC-14 / AC-15 / AC-16 / AC-17 / AC-18 / AC-18補足
# AC-19 / AC-20 / AC-21 / AC-22 + AC-06 report 波及確認

$ErrorActionPreference = 'Stop'
$env:TM_ROOT = Join-Path $env:TEMP 'tm-test-s05'

if (Test-Path $env:TM_ROOT) { Remove-Item $env:TM_ROOT -Recurse -Force }

$tm   = Join-Path $PSScriptRoot '..\..\tm.ps1'
$pass = 0; $fail = 0

function Assert {
    param([string]$Label, [scriptblock]$Check)
    try {
        $result = & $Check
        if ($result) { Write-Host "  [OK] $Label" -ForegroundColor Green; $script:pass++ }
        else         { Write-Host "  [NG] $Label" -ForegroundColor Red;   $script:fail++ }
    } catch {
        Write-Host "  [EX] $Label - $($_.Exception.Message)" -ForegroundColor Red
        $script:fail++
    }
}

# サブプロセスで実行してExitCodeとOutputを取得（エラーケース用）
function RunTm {
    param([string[]]$ArgList)
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $result = powershell.exe -NoProfile -File $tm @ArgList 2>&1
    $ec = $LASTEXITCODE
    $ErrorActionPreference = $prev
    return [PSCustomObject]@{
        All      = $result
        Output   = @($result | Where-Object { $_ -isnot [System.Management.Automation.ErrorRecord] })
        ExitCode = $ec
    }
}

# 指定日の日次ディレクトリ＆ファイルを直接書き込む
function Write-TestDailyFile {
    param([string]$DateStr, [string]$Content)
    $yyyy = $DateStr.Substring(0, 4)
    $mm   = $DateStr.Substring(5, 2)
    $dir  = Join-Path $env:TM_ROOT "daily\$yyyy\$mm"
    New-Item $dir -ItemType Directory -Force | Out-Null
    $path = Join-Path $dir "$DateStr.md"
    Set-Content -Path $path -Value $Content -Encoding UTF8
    return $path
}

# 指定日の日次ファイルを文字列で返す
function Get-TestDailyContent {
    param([string]$DateStr)
    $yyyy = $DateStr.Substring(0, 4)
    $mm   = $DateStr.Substring(5, 2)
    $path = Join-Path $env:TM_ROOT "daily\$yyyy\$mm\$DateStr.md"
    return Get-Content -Path $path -Raw
}

# 標準テストファイル内容（タスク3件）
# [1] Stopped 2セッション: hours=2.50
# [2] Running running_since=10:07: hours=0.00
# [3] Done 1セッション: hours=1.00
function Get-StandardContent {
    param([string]$DateStr)
    return @"
---
date: $DateStr
---

## [1] ログイン修正対応
type: ISS
status: Stopped
hours: 2.50
formal_id:

[09:00-10:30] (1.50h) 朝の作業
[13:00-14:00] (1.00h) 午後の作業

---

## [2] Aさんからの問い合わせ
type: INQ
status: Running
hours: 0.00
running_since: 10:07
formal_id:

---

## [3] 定例朝会
type: MTG
status: Done
hours: 1.00
formal_id:

[09:00-10:00] (1.00h)

---
"@
}

$today     = (Get-Date).ToString('yyyy-MM-dd')
$yesterday = (Get-Date).AddDays(-1).ToString('yyyy-MM-dd')
$tomorrow  = (Get-Date).AddDays(1).ToString('yyyy-MM-dd')

Write-Host "`n=== scenario-05: tm fix コマンドテスト ==="

# ============================================================
# 正常系テスト
# ============================================================

# --- AC-01/06/07/08/09/18/19: -Start -Stop 両方指定で最終セッション修正 ---
Write-Host "`n--- 正常系1: -Start -Stop 両方指定 (AC-01/06/07/08/09/18/19) ---"
Write-TestDailyFile $today (Get-StandardContent $today) | Out-Null
# S2（最終）を 13:00-14:00 → 13:00-14:30 に修正（-Session 省略）
$out = & $tm fix 1 -Start 13:00 -Stop 14:30
$c = Get-TestDailyContent $today

Assert "AC-01: fix が完了した"                          { ($out -join '') -match '修正' }
Assert "AC-07: セッション行の時刻が更新された"          { $c -match '\[13:00-14:30\] \(1\.50h\) 午後の作業' }
Assert "AC-08: コメントが保持された"                    { $c -match '午後の作業' }
Assert "AC-09: セッション1の順序が維持された"           { $c -match '朝の作業[\s\S]*?午後の作業' }
Assert "AC-06: hours が 3.00h に更新された"             { $c -match 'hours: 3\.00' }
Assert "AC-18: 完了メッセージ S2 フォーマット"          {
    ($out -join '') -match '\[1\] 修正: ログイン修正対応 \(S2: 13:00-14:00 → 13:00-14:30 / 計 3\.00h\)'
}
Assert "AC-19: status が Stopped のまま"                { $c -match 'status: Stopped' }

# --- AC-02: -Session N で特定セッションのみ修正 ---
Write-Host "`n--- 正常系2: -Session N 指定 (AC-02) ---"
Write-TestDailyFile $today (Get-StandardContent $today) | Out-Null
# S1 のみ修正（09:00-10:30 → 09:00-11:00）
$out = & $tm fix 1 -Session 1 -Stop 11:00
$c = Get-TestDailyContent $today

Assert "AC-02: S1 が更新された"                         { $c -match '\[09:00-11:00\] \(2\.00h\) 朝の作業' }
Assert "AC-02: S2 が変更されていない"                   { $c -match '\[13:00-14:00\] \(1\.00h\) 午後の作業' }
Assert "AC-02: hours が 3.00h"                          { $c -match 'hours: 3\.00' }

# --- AC-03: -Session 省略で最終セッション対象 ---
Write-Host "`n--- 正常系3: -Session 省略 → 最終セッション (AC-03) ---"
Write-TestDailyFile $today (Get-StandardContent $today) | Out-Null
$out = & $tm fix 1 -Stop 15:00
$c = Get-TestDailyContent $today

# S1 は不変、S2（最終）が修正される
Assert "AC-03: S1 が不変"                               { $c -match '\[09:00-10:30\] \(1\.50h\) 朝の作業' }
Assert "AC-03: S2（最終）が修正された"                  { $c -match '\[13:00-15:00\] \(2\.00h\) 午後の作業' }

# --- AC-04: -Start のみ指定 ---
Write-Host "`n--- 正常系4a: -Start のみ指定 (AC-04/AC-07) ---"
Write-TestDailyFile $today (Get-StandardContent $today) | Out-Null
# S2: 既存 stop 14:00 を維持、start を 13:30 に変更
$out = & $tm fix 1 -Start 13:30
$c = Get-TestDailyContent $today

Assert "AC-04: -Start のみ → start が更新された"        { $c -match '\[13:30-14:00\]' }
Assert "AC-07: セッション行が書き換わった"              { $c -match '\[13:30-14:00\] \(0\.50h\) 午後の作業' }
Assert "AC-06: hours が 2.00h"                          { $c -match 'hours: 2\.00' }

# --- AC-04: -Stop のみ指定 ---
Write-Host "`n--- 正常系4b: -Stop のみ指定 (AC-04/AC-07) ---"
Write-TestDailyFile $today (Get-StandardContent $today) | Out-Null
# S2: 既存 start 13:00 を維持、stop を 14:30 に変更
$out = & $tm fix 1 -Stop 14:30
$c = Get-TestDailyContent $today

Assert "AC-04: -Stop のみ → stop が更新された"          { $c -match '\[13:00-14:30\]' }
Assert "AC-06: hours が 3.00h"                          { $c -match 'hours: 3\.00' }

# --- AC-05 / AC-18補足: Running タスクに -Start のみ → running_since のみ更新 ---
Write-Host "`n--- 正常系5: Running + -Start のみ (AC-05/AC-18補足) ---"
Write-TestDailyFile $today (Get-StandardContent $today) | Out-Null
$out = & $tm fix 2 -Start 10:00
$c = Get-TestDailyContent $today

Assert "AC-05: running_since が 10:00 に更新された"     { $c -match 'running_since: 10:00' }
Assert "AC-05: hours が 0.00 のまま不変"               {
    $c -match '## \[2\] Aさんからの問い合わせ[\s\S]*?hours: 0\.00'
}
Assert "AC-05: セッション行が追加されていない"          {
    # [2] セクションにセッション行がない（running 状態で確定セッションなし）
    $task2 = [regex]::Match($c, '## \[2\] Aさんからの問い合わせ([\s\S]*?)(?=## \[3\]|$)').Groups[1].Value
    -not ($task2 -match '\[\d{2}:\d{2}-\d{2}:\d{2}\]')
}
Assert "AC-18補足: Running 修正メッセージ"              {
    ($out -join '') -match '\[2\] 修正: Aさんからの問い合わせ \(Running: 10:07 → 10:00\)'
}

# --- AC-10: -Date 過去日で修正 ---
Write-Host "`n--- 正常系6: -Date 過去日 (AC-10) ---"
Write-TestDailyFile $yesterday (Get-StandardContent $yesterday) | Out-Null
$out = RunTm @('fix', '1', '-Stop', '14:30', '-Date', $yesterday)
$c = Get-TestDailyContent $yesterday

Assert "AC-10: -Date 過去日 exit 0"                     { $out.ExitCode -eq 0 }
Assert "AC-10: 過去日のセッションが修正された"          { $c -match '\[13:00-14:30\]' }

# --- AC-06 波及: tm report に修正後 hours が反映される ---
Write-Host "`n--- 正常系7: tm report 波及確認 (AC-06波及) ---"
Write-TestDailyFile $today (Get-StandardContent $today) | Out-Null
& $tm fix 1 -Stop 14:30 | Out-Null   # hours を 2.50 → 3.00 に変更
$repOut = RunTm @('report')

Assert "AC-06波及: tm report が 3.00h を反映している"   {
    ($repOut.Output -join '') -match '3\.00h'
}

# ============================================================
# 異常系テスト（RunTm でサブプロセス実行）
# ============================================================

# 各テスト前にファイルをリセット
Write-Host "`n--- 異常系テスト ---"
Write-TestDailyFile $today (Get-StandardContent $today) | Out-Null

# AC-11: 存在しない連番
Write-Host "`n--- AC-11: 存在しない連番 ---"
$r = RunTm @('fix', '999', '-Stop', '14:00')
Assert "AC-11: exit 1"                                  { $r.ExitCode -eq 1 }
Assert "AC-11: エラーメッセージに '999' が含まれる"     { ($r.Output -join '') -match '999' }

# AC-12: 存在しないセッション番号
Write-Host "`n--- AC-12: 存在しないセッション番号 ---"
$r = RunTm @('fix', '1', '-Session', '99', '-Stop', '14:00')
Assert "AC-12: exit 1"                                  { $r.ExitCode -eq 1 }
Assert "AC-12: エラーメッセージに 'セッション番号' が含まれる" { ($r.Output -join '') -match 'セッション番号' }

# AC-13: -Start / -Stop 両方省略
Write-Host "`n--- AC-13: -Start -Stop 両方省略 ---"
$r = RunTm @('fix', '1', '-Session', '2')
Assert "AC-13: exit 1"                                  { $r.ExitCode -eq 1 }
Assert "AC-13: エラーメッセージに '一方' が含まれる"    { ($r.Output -join '') -match '一方' }

# AC-14: Running + -Session 省略 + -Stop 指定
Write-Host "`n--- AC-14: Running + -Stop 指定 ---"
$r = RunTm @('fix', '2', '-Stop', '11:00')
Assert "AC-14: exit 1"                                  { $r.ExitCode -eq 1 }
Assert "AC-14: エラーメッセージに '-Stop' が含まれる"   { ($r.Output -join '') -match '\-Stop' }

# AC-15: Done タスク
Write-Host "`n--- AC-15: Done タスク ---"
$r = RunTm @('fix', '3', '-Stop', '10:30')
Assert "AC-15: exit 1"                                  { $r.ExitCode -eq 1 }
Assert "AC-15: エラーメッセージに 'Done' が含まれる"    { ($r.Output -join '') -match 'Done' }

# AC-16: 不正な時刻フォーマット（9:00）
Write-Host "`n--- AC-16: 不正な時刻フォーマット (9:00) ---"
$r = RunTm @('fix', '1', '-Start', '9:00')
Assert "AC-16a: exit 1"                                 { $r.ExitCode -eq 1 }
Assert "AC-16a: エラーメッセージに 'フォーマット' が含まれる" { ($r.Output -join '') -match 'フォーマット' }

# AC-16: 不正な時刻フォーマット（25:00）
Write-Host "`n--- AC-16: 不正な時刻フォーマット (25:00) ---"
$r = RunTm @('fix', '1', '-Stop', '25:00')
Assert "AC-16b: exit 1"                                 { $r.ExitCode -eq 1 }
Assert "AC-16b: エラーメッセージに 'フォーマット' が含まれる" { ($r.Output -join '') -match 'フォーマット' }

# AC-17: 丸め後 finalStart >= finalStop
Write-Host "`n--- AC-17: finalStart >= finalStop ---"
$r = RunTm @('fix', '1', '-Start', '11:00', '-Stop', '10:00')
Assert "AC-17: exit 1"                                  { $r.ExitCode -eq 1 }
Assert "AC-17: エラーメッセージに '以降' が含まれる"    { ($r.Output -join '') -match '以降' }

# AC-22: -Date 未来日
Write-Host "`n--- AC-22: -Date 未来日 ---"
$r = RunTm @('fix', '1', '-Stop', '14:00', '-Date', $tomorrow)
Assert "AC-22: exit 1"                                  { $r.ExitCode -eq 1 }
Assert "AC-22: エラーメッセージに '未来日' が含まれる"  { ($r.Output -join '') -match '未来日' }

# AC-20: -Date 指定のファイルが存在しない
Write-Host "`n--- AC-20: 存在しない -Date ---"
$r = RunTm @('fix', '1', '-Stop', '14:00', '-Date', '2020-01-01')
Assert "AC-20: exit 1"                                  { $r.ExitCode -eq 1 }
Assert "AC-20: エラーメッセージに 'ファイルが存在しません' が含まれる" { ($r.Output -join '') -match 'ファイルが存在しません' }

# AC-21: -Date 不正フォーマット
Write-Host "`n--- AC-21: -Date 不正フォーマット ---"
$r = RunTm @('fix', '1', '-Stop', '14:00', '-Date', '2026-13-45')
Assert "AC-21a: exit 1 (不正日付)"                      { $r.ExitCode -eq 1 }
Assert "AC-21a: エラーメッセージに '形式が不正' が含まれる" { ($r.Output -join '') -match '形式が不正' }

$r = RunTm @('fix', '1', '-Stop', '14:00', '-Date', '20260504')
Assert "AC-21b: exit 1 (不正フォーマット)"              { $r.ExitCode -eq 1 }
Assert "AC-21b: エラーメッセージに '形式が不正' が含まれる" { ($r.Output -join '') -match '形式が不正' }

# tm fix 連番未指定
Write-Host "`n--- DISPATCH: 連番未指定 ---"
$r = RunTm @('fix', '-Stop', '14:00')
Assert "DISPATCH: 連番なし → exit 1"                    { $r.ExitCode -eq 1 }

Write-Host "`n=== 結果: PASS $pass / FAIL $fail ==="
if ($fail -gt 0) { exit 1 }
