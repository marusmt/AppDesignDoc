# design.md — v0.2 fix コマンド

> 実装仕様の詳細は [docs/functional-design-v02.md](../../docs/functional-design-v02.md) を参照してください。
> 本ドキュメントは「今回どう実装するか」の作業計画です。

---

## 1. 変更するコンポーネント

| ファイル | 変更種別 | 内容 |
|---|---|---|
| `tm.ps1` (#region CONFIG) | 更新 | `$ScriptVersion` を `'0.1.0'` → `'0.2.0'` に変更 |
| `tm.ps1` (#region COMMANDS) | 追加 | `Invoke-TmFix` 関数を追加 |
| `tm.ps1` (#region DISPATCH) | 更新 | `'fix'` ケースのコメントアウトを有効化 |

既存の `Read-DailyFile` / `Write-DailyFile` / `Get-SessionBoundaries` / `Get-TaskBySeq` / `Write-TmError` / `Write-TmInfo` をそのまま利用するため、UTIL / DAILY リージョンへの変更はない。

---

## 2. 関数シグネチャ

```powershell
function Invoke-TmFix {
    param(
        [Parameter(Mandatory=$true)] [int]$Seq,
        [int]$Session    = -1,
        [string]$Start   = '',
        [string]$Stop    = '',
        [string]$Date    = ''
    )
}
```

- `-Session` の既定値 `-1` は「省略」を表す（セッション行の 1 始まり番号と衝突しない）
- `-Start` / `-Stop` の既定値 `''` は「省略」を表す

---

## 3. セッション行のパース

`SessionLines` の各要素は `Add-SessionLine` が生成した丸め済み文字列。以下の正規表現で分解する。

```powershell
$pattern = '^\[(\d{2}:\d{2})-(\d{2}:\d{2})\]\s*\(([\d.]+)h\)(.*)$'
```

| キャプチャグループ | 意味 | 例 |
|---|---|---|
| `$Matches[1]` | 開始時刻（丸め済み） | `09:00` |
| `$Matches[2]` | 終了時刻（丸め済み） | `10:30` |
| `$Matches[3]` | 工数文字列 | `1.50` |
| `$Matches[4]` | コメント（空でも可） | ` セッション判定ロジック修正` |

修正後のセッション行の組み立て：

```powershell
$newEntry = "[$($b.StartRounded)-$($b.StopRounded)] ($($b.Hours.ToString('0.00'))h)$comment"
# $b = Get-SessionBoundaries $finalStart $finalStop
# $comment = $Matches[4]（既存コメントをそのまま引き継ぐ）
```

---

## 4. 実装フロー

### 4.1 Stopped タスクの通常修正

```
[ステップ1] -Date バリデーション・ファイル取得
  - $Date が空でなければ TryParseExact で検証
  - 未来日チェック: $parsed.Date -gt (Get-Date).Date → エラー
  - Get-DailyFilePath $parsed で $path を取得
  - Test-Path $path → 存在しなければエラー

[ステップ2] タスク読み込みと基本チェック
  - Read-DailyFile $path → $tasks
  - Get-TaskBySeq $tasks $Seq → $target
  - $target が $null → エラー
  - $target.Status -eq 'Done' → エラー

[ステップ3] Running + -Session省略 + -Stop指定チェック
  - $target.Status -eq 'Running' -and $Session -eq -1 -and $Stop -ne '' → エラー

[ステップ4] セッション解決
  - $sessionLines = $target.SessionLines（List<string>）
  - $count = $sessionLines.Count
  - $Session -ne -1 かつ $Session -gt $count → エラー
  - $targetIdx = if ($Session -eq -1) { $count - 1 } else { $Session - 1 }
  - $sessionLines[$targetIdx] を $pattern でパース → 既存 start / stop / comment を取得

[ステップ5] 入力バリデーション
  - $Start -eq '' -and $Stop -eq '' → エラー
  - $Start -ne '' の場合: TryParseExact 'HH:mm' → 不正 → エラー
  - $Stop  -ne '' の場合: TryParseExact 'HH:mm' → 不正 → エラー
  - $finalStart = ($Start -ne '') ? $Start : $existingStart
  - $finalStop  = ($Stop  -ne '') ? $Stop  : $existingStop
  - $b = Get-SessionBoundaries $finalStart $finalStop で丸め後の値 $b.StartRounded / $b.StopRounded を取得
  - $b.StartRounded ≧ $b.StopRounded → エラー
    エラーメッセージには丸め後の値を出力（例: `tm: 修正後の開始時刻が終了時刻以降になっています: $($b.StartRounded) ≧ $($b.StopRounded)`）

[ステップ6] セッション行更新・hours 再計算
  - ステップ5 で取得した $b を使って新セッション行文字列を組み立て
  - $sessionLines[$targetIdx] を新文字列で置き換え
  - 全セッション行に Get-RoundedHours を独立適用して合算 → $newHours
  - $target.Hours = [Math]::Round($newHours, 2)

[ステップ7] 書き込み・出力
  - Write-DailyFile $path $tasks
  - $oldStart = ステップ4 でパースした既存開始時刻（セッション行から読み取った丸め済み値）
  - $oldStop  = ステップ4 でパースした既存終了時刻（セッション行から読み取った丸め済み値）
  - 完了メッセージを Write-TmInfo で出力（AC-18 フォーマット、旧時刻・新時刻ともに丸め済み値）
```

### 4.2 Running タスクの running_since 修正

```
[ステップ1〜3] 同上（ただしステップ3でエラーにならない条件: -Stop が空）

[ステップ4] バリデーション
  - $Start -eq '' → エラー（-Start/-Stop 両方省略ケース）
  - $Start の TryParseExact 検証

[ステップ4.5] 旧 running_since の保存
  - $oldRunningSince = $target.RunningSince  ← 上書き前に保持

[ステップ5] running_since 更新のみ
  - $target.RunningSince = $Start（生時刻・丸めなし）
  - hours フィールドは変更しない
  - SessionLines は変更しない

[ステップ6] 書き込み・出力
  - Write-DailyFile $path $tasks
  - 完了メッセージ: [N] 修正: タイトル (Running: $oldRunningSince → $Start)
```

---

## 5. ディスパッチ変更

`#region DISPATCH` の switch 文を以下のように変更する。

**変更前（コメントアウト）:**

```powershell
# 'fix'     { Invoke-TmFix    ... }   # v0.2
```

**変更後（有効化）:**

```powershell
'fix' {
    $ht = @{}
    for ($i = 0; $i -lt $Rest.Count; $i++) {
        switch ($Rest[$i]) {
            '-Session' { $ht['Session'] = [int]$Rest[++$i] }
            '-Start'   { $ht['Start']   = [string]$Rest[++$i] }
            '-Stop'    { $ht['Stop']    = [string]$Rest[++$i] }
            '-Date'    { $ht['Date']    = [string]$Rest[++$i] }
            default {
                if (-not $ht.ContainsKey('Seq')) {
                    $ht['Seq'] = [int]$Rest[$i]
                }
            }
        }
    }
    if (-not $ht.ContainsKey('Seq')) { Write-TmError "tm fix: 連番を指定してください。" }
    Invoke-TmFix @ht
}
```

> **型キャスト方針（修正5 確認結果）:** `[int]$Rest[++$i]` の直接キャストは `tm start` / `tm done` 等の既存コマンドと同じパターン（案 A 現状維持）。`-Session abc` などの誤入力時は PowerShell 例外が出力されるが、他コマンドと統一した挙動として許容する。
>
> **-Help サポート（修正6 確認結果）:** 既存コマンド全てで `-Help` 未サポートのため、`tm fix` も追加しない。

---

## 6. 影響範囲

| 対象 | 影響 |
|---|---|
| `tm report` / `tm report -Csv` | `hours` フィールドを直接読むだけなので、`tm fix` 後の変更は自動反映される。変更不要 |
| `tm list` | 同上 |
| `Read-DailyFile` | 変更なし。SessionLines は `List<string>` なので index アクセスで書き換え可能 |
| `Write-DailyFile` | 変更なし。SessionLines をそのまま書き出す |
| `tests/manual/` | 新規シナリオスクリプトを追加（tasklist.md で管理） |

---

## 7. テスト計画

`tests/manual/scenario-04-fix.ps1` を新規作成する。

| シナリオ | 確認する AC |
|---|---|
| Stopped タスクの最終セッションを -Start / -Stop 両方で修正 | AC-01, AC-06, AC-07, AC-08, AC-09, AC-18 |
| -Session N で特定セッションを修正 | AC-02 |
| -Session 省略 → 最終セッションが対象 | AC-03 |
| -Start のみ指定、-Stop のみ指定 | AC-04 |
| Running タスクに -Start のみ指定 | AC-05, AC-18 補足 |
| -Date YYYY-MM-DD で過去日ファイルを修正 | AC-10 |
| 存在しない連番 → エラー | AC-11 |
| 存在しないセッション番号 → エラー | AC-12 |
| -Start / -Stop 両方省略 → エラー | AC-13 |
| Running タスクに -Stop 指定 → エラー | AC-14 |
| Done タスク → エラー | AC-15 |
| 不正な時刻フォーマット → エラー | AC-16 |
| finalStart ≧ finalStop → エラー | AC-17 |
| -Date 未来日 → エラー | AC-22 |
| Stopped タスクを修正しても status が Stopped のまま維持される | AC-19 |
| -Date 指定の日次ファイルが存在しない → エラー | AC-20 |
| -Date が不正なフォーマット / 不正な日付 → エラー | AC-21 |
| tm fix 後に tm report で工数が反映されている | AC-06 の report 波及確認 |
