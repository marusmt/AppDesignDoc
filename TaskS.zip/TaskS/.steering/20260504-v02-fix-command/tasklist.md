# tasklist.md — v0.2 fix コマンド

> 作業計画と進捗管理。実装・テスト・ドキュメント更新のチェックリスト。
> 仕様は `.steering/20260504-v02-fix-command/requirements.md` と `design.md`、及び `docs/functional-design-v02.md` を参照。

> 進捗凡例: `[ ]` 未着手 / `[~]` 進行中 / `[x]` 完了

---

## 1. 作業スコープ

- **追加するもの:** `Invoke-TmFix` 関数（`#region COMMANDS`）と `fix` ディスパッチケース（`#region DISPATCH`）
- **連動更新するもの:** `$ScriptVersion`（0.1.0 → 0.2.0）、CHANGELOG.md（新規作成）、必要に応じて README 相当ファイル
- **変更しないもの:** UTIL / DAILY / COUNTER リージョン、`tm new` / `tm start` / `tm stop` / `tm done` / `tm list` / `tm log` / `tm open` / `tm report` の各コマンド実装、report 集計ロジック
- **仕様の源泉:** `docs/functional-design-v02.md` と `design.md`（ともにフリーズ済み）
- **テスト方針:** `tests/manual/scenario-05-fix.ps1` を新規作成し、AC-01〜AC-22 + AC-18 補足の全件をカバーする（`scenario-04-edge-cases.ps1` が既存のため 05 採番）

---

## 2. 実装タスク

### 2.1 事前準備

- [x] `design.md §1 〜 §5` を通読し、実装のイメージを固める
- [x] `tm.ps1` の `Invoke-TmStart` / `Invoke-TmStop` / `Invoke-TmDone` の実装スタイル（エラー処理・メッセージフォーマット・関数分割）を確認し、`Invoke-TmFix` でも同じスタイルに揃える方針を確認する

### 2.2 CONFIG リージョン

- [x] `$ScriptVersion` を `'0.1.0'` → `'0.2.0'` に更新（参照: design.md §1）

### 2.3 COMMANDS リージョン — Invoke-TmFix 実装

- [x] **関数骨格:** `Invoke-TmFix` の `param` ブロックと空実装を追加。`Invoke-TmStop` と同じスタイルで関数コメントを付ける（参照: design.md §2）

- [x] **ステップ1 — -Date バリデーション・ファイル取得:**
  - `$Date` が空でなければ `[datetime]::TryParseExact` で検証。失敗 → `Write-TmError`
  - 未来日チェック: `$parsed.Date -gt (Get-Date).Date` → `Write-TmError`
  - `Get-DailyFilePath $parsed` で `$path` を決定。`Test-Path` でファイル存在確認 → なければ `Write-TmError`
  - `$Date` が空の場合は `Get-DailyFilePath`（当日）を使用
  - （参照: design.md §4.1 ステップ1、AC-10 / AC-20 / AC-21 / AC-22）

- [x] **ステップ2 — タスク読み込みと基本チェック:**
  - `Read-DailyFile $path` → `$tasks`
  - `Get-TaskBySeq $tasks $Seq` → `$target`。`$null` → `Write-TmError`
  - `$target.Status -eq 'Done'` → `Write-TmError`
  - （参照: design.md §4.1 ステップ2、AC-11 / AC-15）

- [x] **ステップ3 — Running + -Session省略 + -Stop指定チェック:**
  - `$target.Status -eq 'Running' -and $Session -eq -1 -and $Stop -ne ''` → `Write-TmError`
  - （参照: design.md §4.1 ステップ3、AC-14）

- [x] **ステップ4 — セッション解決:**
  - `$sessionLines = $target.SessionLines`。`$count = $sessionLines.Count`
  - `-Session N` 指定時: `$Session -gt $count` → `Write-TmError`
  - `$targetIdx` 決定: `-Session` 省略 → `$count - 1`、指定あり → `$Session - 1`
  - `$pattern = '^\[(\d{2}:\d{2})-(\d{2}:\d{2})\]\s*\(([\d.]+)h\)(.*)$'` で `$sessionLines[$targetIdx]` をパース
  - `$existingStart`（Matches[1]）/ `$existingStop`（Matches[2]）/ `$comment`（Matches[4]）を取得
  - （参照: design.md §3 / §4.1 ステップ4、AC-02 / AC-03 / AC-12）

- [x] **ステップ5 — 入力バリデーションと丸め後順序チェック:**
  - `-Start` / `-Stop` 両方 `''` → `Write-TmError`
  - `-Start` / `-Stop` 各々 `TryParseExact 'HH:mm'` で検証。失敗 → `Write-TmError`
  - `$finalStart` / `$finalStop` を決定（指定値 or 既存値）
  - `$b = Get-SessionBoundaries $finalStart $finalStop` で丸め後の値を取得（事前に丸め後 start >= stop を手動チェックして AC-17 エラー）
  - （参照: design.md §4.1 ステップ5、AC-04 / AC-13 / AC-16 / AC-17）

- [x] **ステップ6 — セッション行更新・hours 再計算:**
  - ステップ5 の `$b` を使って新セッション行文字列を組み立て（コメントはそのまま引き継ぐ）
  - `$sessionLines[$targetIdx]` を新文字列で置き換え
  - 全セッション行に `Get-RoundedHours` を独立適用して合算 → `$newHours`
  - `$target.Hours = [Math]::Round($newHours, 2)`
  - （参照: design.md §4.1 ステップ6、AC-06 / AC-07 / AC-08 / AC-09）

- [x] **ステップ7 — ファイル書き込みと完了メッセージ出力:**
  - `Write-DailyFile $path $tasks`
  - `$oldStart`（ステップ4 でパースした丸め済み値）/ `$oldStop` を使って AC-18 フォーマットで `Write-TmInfo` 出力
  - フォーマット: `[N] 修正: タイトル (S<N>: 旧Start-旧Stop → 新Start-新Stop / 計 X.XXh)`
  - （参照: design.md §4.1 ステップ7、AC-01 / AC-18）

- [x] **Running 分岐（ステップ4.5 〜 ステップ6）:**
  - `$oldRunningSince = $target.RunningSince` を上書き前に保持（ステップ4.5）
  - `-Start` 未指定 → `Write-TmError`
  - `-Start` の `TryParseExact 'HH:mm'` 検証
  - `$target.RunningSince = $Start`（生時刻・丸めなし）。`hours` / `SessionLines` は変更しない
  - `Write-DailyFile $path $tasks`
  - `Write-TmInfo` 出力: `[N] 修正: タイトル (Running: $oldRunningSince → $Start)`
  - （参照: design.md §4.2、AC-05 / AC-18 補足）

- [x] **status 不変の確認:** `Invoke-TmFix` の実装全体で `$target.Status` を変更している箇所がないことをコードレビューで確認（参照: AC-19）

### 2.4 DISPATCH リージョン

- [x] `# 'fix'     { Invoke-TmFix    ... }   # v0.2` のコメントアウトを削除し、`design.md §5` の実装例に従って `fix` ケースを有効化（参照: design.md §5）
- [x] 連番未指定時の早期エラーチェック（`if (-not $ht.ContainsKey('Seq'))`）が実装済みであることを確認

---

## 3. テストタスク

### 3.1 シナリオスクリプト骨格作成

- [x] `tests/manual/scenario-05-fix.ps1` を新規作成し、以下を `scenario-01〜03` と揃える（`scenario-04-edge-cases.ps1` が既存のため 05 を採番）
  - `#Requires -Version 5.1` / ヘッダコメント（対象 AC の一覧）
  - `$env:TM_ROOT` をサンドボックスディレクトリに向ける
  - `Assert` ヘルパー関数（`scenario-01〜03` と同一の定義）
  - テスト完了後の `PASS/FAIL` サマリ出力

### 3.2 正常系シナリオ

- [x] Stopped タスクの最終セッションを `-Start` / `-Stop` 両方で修正（参照: AC-01 / AC-06 / AC-07 / AC-08 / AC-09 / AC-18）
- [x] `-Session N` で特定セッションのみ修正。他セッションが不変であること（参照: AC-02）
- [x] `-Session` 省略 → 最終セッション行が対象（参照: AC-03）
- [x] `-Start` のみ指定・`-Stop` のみ指定（参照: AC-04 / AC-06 / AC-07）
- [x] Running タスクに `-Start` のみ指定 → `running_since` のみ更新。`hours` / セッション行は不変（参照: AC-05 / AC-18 補足）
- [x] `-Date YYYY-MM-DD` で過去日ファイルを修正（参照: AC-10）
- [x] Stopped タスクを修正後も `status` が `Stopped` のまま維持される（参照: AC-19）
- [x] `tm fix` 後に `tm report` / `tm report -Csv` を実行し、更新後の `hours` が集計に反映されている（参照: AC-06 波及確認）

### 3.3 異常系シナリオ

- [x] 存在しない連番を指定 → `exit 1`（参照: AC-11）
- [x] 存在しないセッション番号を指定 → `exit 1`（参照: AC-12）
- [x] `-Start` / `-Stop` 両方省略 → `exit 1`（参照: AC-13）
- [x] Running タスクに `-Session` 省略で `-Stop` を指定 → `exit 1`（参照: AC-14）
- [x] Done タスクを指定 → `exit 1`（参照: AC-15）
- [x] 不正な時刻フォーマット（例: `9:00` / `25:00`）→ `exit 1`（参照: AC-16）
- [x] 修正後の `finalStart ≧ finalStop` となる指定 → `exit 1`（参照: AC-17）
- [x] `-Date` に未来日を指定 → `exit 1`（参照: AC-22）
- [x] `-Date` 指定の日次ファイルが存在しない → `exit 1`（参照: AC-20）
- [x] `-Date` が不正フォーマット / 不正な日付（例: `2026-13-45`）→ `exit 1`（参照: AC-21）

### 3.4 手動テスト実行・受け入れ

- [x] `tests/manual/scenario-05-fix.ps1` をクリーン状態で実行し、全シナリオが意図通りの出力・exit code を返すことを確認（PASS 49 / FAIL 0）
- [x] `scenario-01` → `scenario-02` → `scenario-03` → `scenario-05` を連続実行し、相互にコンフリクトがないことを確認（各スクリプトが独立した `$env:TM_ROOT` を使用することを前提）
  - scenario-01: PASS 18 / FAIL 0
  - scenario-02: PASS 9 / FAIL 0
  - scenario-03: PASS 5 / FAIL 0
  - scenario-04: PASS 12 / FAIL 5（v0.2 実装前から存在する既存の失敗。tm fix とは無関係）
  - scenario-05: PASS 49 / FAIL 0

---

## 4. ドキュメント更新タスク

- [x] `CHANGELOG.md` を新規作成し、`v0.2.0` エントリを追加（追加機能: `tm fix` コマンド）。`v0.1.0` のエントリも遡及して記載する
- [x] `docs/usage.md`（既存）に `tm fix` の使い方例を追記する（`tm start` / `tm stop` と同じスタイルで）
- [x] `docs/repository-structure.md` に `Invoke-TmFix` と `scenario-05-fix.ps1` の記載を追記した
- [x] 本ステアリングディレクトリ完了記録: 下記「完了日」欄に日付を記入する

**完了日:** 2026-05-04

---

## 5. リリース手順

- [ ] `§3.4` の全テストグリーンを確認してから進む
- [ ] `CHANGELOG.md` の `v0.2.0` にリリース日を記入して確定する
- [ ] `git tag v0.2.0` を付与する（`docs/development-guidelines.md §9` のバージョン表参照）
- [ ] ユーザー（丸山さん）に完了を報告し、v0.2 スプリントをクローズする

---

## 6. スコープ外（v0.2 でやらない）

- `formal_id` フィールドの活用・`tm promote` の実装（v1.0 で対応）
- `ISS-NNN / PHASE-MM` 体系の採番、INQ / MTG の自動採番化（v1.0）
- `tm rollover` の実装（v1.0）
- `-Help` オプションの全体導入（現状全コマンド未サポート。v0.2 でも追加しない）
- ディスパッチ層の型キャスト厳密化（`[int]::TryParse` 等。現行コマンドと統一して v0.2 では現状維持）
- `tm fix` による過去複数日の一括修正（今回は 1 コマンド実行 = 1 日次ファイルのみ）
