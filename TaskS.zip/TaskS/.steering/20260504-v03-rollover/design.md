# design.md — v0.3 rollover コマンド

> 実装仕様の詳細は [docs/functional-design-v03.md](../../docs/functional-design-v03.md) を参照してください。
> 本ドキュメントは「今回どう実装するか」の作業計画です。

---

## 1. 概要

### 機能スコープ（v0.3）

| コマンド | 機能 |
| --- | --- |
| `tm rollover` | 直近の稼働日の Stopped タスクを当日の日次ファイルへ全件繰り越す |

### 上位入力との関係

| 入力 | 役割 |
| --- | --- |
| `.steering/20260504-v03-rollover/requirements.md` | 受け入れ条件 AC-23〜AC-39 の定義（実装ゴーサイン基準） |
| `docs/functional-design-v03.md` | 仕様の確定版（真実の源）。本 design.md はこれを実装方針に変換する |

### 本 design.md の目的・読者

- **実装担当者:** §3 関数シグネチャ・§4 AC対応表・§5 データ構造変更を参照して実装する
- **scenario テスト作成者:** §6 テストケース一覧を参照して `scenario-06-rollover.ps1` を作成する

---

## 2. アーキテクチャ概要

### 呼び出しチェーン

```
tm rollover
  └─ DISPATCH 'rollover' ケース (AC-23 不正引数チェック)
       └─ Invoke-TmRollover
            ├─ Test-RolloverAlreadyDone        (AC-26)
            ├─ Find-LatestWorkingDayPath        (AC-24, AC-25)
            ├─ Read-DailyFile [拡張]            (AC-27, AC-28, AC-37)
            ├─ Get-StoppedTasks                (AC-27, AC-28)
            ├─ Write-DailyFile [拡張] @()      (AC-29) ← 当日ファイル生成
            ├─ Read-DailyFile [拡張]            (当日タスク読込)
            ├─ New-RolledTask × N              (AC-30, AC-31, AC-32)
            └─ Write-DailyFile [拡張]           (AC-35, AC-38)
```

### フロー図

```mermaid
graph TD
    D["DISPATCH 'rollover'"] -->|"$Rest.Count > 0"| E1["Write-TmError + exit 1 (AC-23)"]
    D -->|"引数なし"| ITR["Invoke-TmRollover"]
    ITR --> TRAD["Test-RolloverAlreadyDone (AC-26)"]
    TRAD -->|"rolled_from付きあり"| W1["Write-TmWarn + return (exit 0)"]
    TRAD -->|"なし"| FLWD["Find-LatestWorkingDayPath (AC-24,25)"]
    FLWD -->|"90日以内なし"| W2["Write-TmWarn + return (exit 0)"]
    FLWD -->|"パス取得"| GST["Get-StoppedTasks (AC-27,28)"]
    GST -->|"0件"| I1["Write-TmInfo + return (AC-39, exit 0)"]
    GST -->|"1件以上"| PREP["当日ファイル準備 (AC-29)"]
    PREP --> NRT["New-RolledTask × N (AC-30,31,32)"]
    NRT --> WDF["Write-DailyFile (AC-35,38)"]
    WDF --> OUT["完了メッセージ (AC-33,34) → exit 0"]
```

### 既存関数との位置づけ

| 関数 | v0.3 での変更 |
| --- | --- |
| `Read-DailyFile` | **変更あり** — タスクオブジェクトに `RolledFrom` プロパティ追加（AC-37） |
| `Write-DailyFile` | **変更あり** — `RolledFrom` 非空時に `rolled_from:` 行を出力（AC-38）|
| `Get-DailyFilePath` | 変更なし |
| `Write-TmWarn` / `Write-TmInfo` / `Write-TmError` | 変更なし |
| `Invoke-TmReport` | 変更なし（AC-36） |

---

## 3. 実装する関数 / 処理

### 3.1 Invoke-TmRollover（#region COMMANDS）

```powershell
function Invoke-TmRollover {
    param()
}
```

**責務:** rollover コマンド全体フローの統括（§2 フロー図参照）。

**実装フロー:**

```
[ステップ1] 二重繰越チェック (AC-26)
  - $todayPath = Get-DailyFilePath
  - Test-RolloverAlreadyDone $todayPath が $true
      → Write-TmWarn "本日は既に繰越実行済みです。" / return

[ステップ2] 直近の稼働日を特定 (AC-24, AC-25)
  - $srcPath = Find-LatestWorkingDayPath
  - $srcPath が $null
      → Write-TmWarn "直近の稼働日が見つかりません（過去90日以内にファイルなし）。" / return
  - $srcDateStr = [System.IO.Path]::GetFileNameWithoutExtension($srcPath)

[ステップ3] Stopped タスク抽出 (AC-27, AC-28)
  - try { [object[]]$srcTasks = @(Read-DailyFile $srcPath) } catch {
        Write-TmError "日次ファイル読込失敗: $($_.Exception.Message)"
    }
  - [object[]]$stoppedTasks = @(Get-StoppedTasks $srcTasks)
    ※ Running タスクは Get-StoppedTasks が silently skip（AC-28）

[ステップ4] 0件チェック (AC-39)
  - $stoppedTasks.Count -eq 0
      → Write-TmInfo "繰越対象なし（直近の稼働日: $srcDateStr）" / return

[ステップ5] 当日ファイル準備 (AC-29)
  - Test-Path $todayPath が $false
      → $todayDateStr = (Get-Date).ToString('yyyy-MM-dd')
        try { Write-DailyFile $todayPath @() $todayDateStr } catch {
            Write-TmError "日次ファイル書込失敗: $($_.Exception.Message)"
        }
  - try { [object[]]$todayTasks = @(Read-DailyFile $todayPath) } catch {
        Write-TmError "日次ファイル読込失敗: $($_.Exception.Message)"
    }

[ステップ6] タスクコピーと採番 (AC-30, AC-31, AC-32)
  - $nextSeq = $todayTasks.Count + 1
  - $rolledTasks = List[object]::new()
  - foreach $t in $stoppedTasks:
      New-RolledTask $t $nextSeq $srcDateStr → $rolledTasks.Add(...)
      $nextSeq++

[ステップ7] 当日ファイル書き込み (AC-35)
  - 元ファイル ($srcPath) は一切変更しない
  - $allTasks = [System.Collections.Generic.List[object]]::new()
    if ($null -ne $todayTasks -and $todayTasks.Count -gt 0) {
        $allTasks.AddRange([object[]]$todayTasks)
    }
    $allTasks.AddRange($rolledTasks.ToArray())
  - try { Write-DailyFile $todayPath $allTasks.ToArray() } catch {
        Write-TmError "日次ファイル書込失敗: $($_.Exception.Message)"
    }

[ステップ8] 完了メッセージ (AC-33, AC-34)
  - Write-TmInfo "直近の稼働日: $srcDateStr"
  - $maxLen = max(title lengths) for padding
  - foreach $t in $rolledTasks:
      Write-TmInfo "[$($t.Seq)] $($t.Title.PadRight($maxLen))  $($t.Type)"
  - Write-TmInfo "$($rolledTasks.Count) 件のタスクを繰り越しました"
```

**パディング規則（AC-33 確定）:**

繰越タスク群のタイトル最大長を動的に取得し `PadRight($maxTitleLen)` で揃える。
タイトルと TYPE の間は最低 2 スペースを保証する。最大長 0 の場合は PadRight(0) で
実質的にスペースなし（起こりえないが安全のため）。

```powershell
$maxTitleLen = ($rolledTasks | ForEach-Object { $_.Title.Length } | Measure-Object -Maximum).Maximum
```

### 3.2 Find-LatestWorkingDayPath（#region DAILY）

```powershell
function Find-LatestWorkingDayPath {
    param([datetime]$Today = (Get-Date))
    for ($i = 1; $i -le 90; $i++) {
        $d = $Today.AddDays(-$i)
        $p = Get-DailyFilePath $d
        if (Test-Path $p) { return $p }
    }
    return $null
}
```

**責務:** 当日の前日（-1日）から最大90日遡り、日次ファイルが存在する最初のパスを返す。
90日以内に見つからない場合は `$null` を返す。

**注記:**
- 探索開始は当日ではなく **前日（$i = 1）** から（AC-24: 「実行日の前日から」）
- `Get-DailyFilePath` を流用することで月・年の境界処理を自動化
- 返値: 見つかったファイルのフルパス文字列 or `$null`

### 3.3 Test-RolloverAlreadyDone（#region DAILY）

```powershell
function Test-RolloverAlreadyDone {
    param([string]$TodayPath)
    if (-not (Test-Path $TodayPath)) { return $false }
    [object[]]$tasks = @(Read-DailyFile $TodayPath)
    return ($tasks | Where-Object { $_.RolledFrom -ne '' }).Count -gt 0
}
```

**責務:** 当日ファイルに `RolledFrom` が空でないタスクが 1件以上あるかを判定する（AC-26）。

**注記:**
- 当日ファイルが存在しない場合は `$false` を返す（繰越未実行とみなす）
- `Read-DailyFile` の拡張（§3.6）で `RolledFrom` プロパティが付与されることを前提とする

### 3.4 Get-StoppedTasks（#region DAILY）

```powershell
function Get-StoppedTasks {
    param([object[]]$Tasks)
    return @($Tasks | Where-Object { $_.Status -eq 'Stopped' })
}
```

**責務:** タスク配列から `status = 'Stopped'` のタスクのみを返す。

**注記:**
- `Running` タスクは Where-Object により暗黙的に除外される（AC-28: silently skip）
- `Done` タスクも同様に除外される（AC-27）
- 結果は元の配列順（ファイル内の出現順）を維持する

### 3.5 New-RolledTask（#region DAILY）

```powershell
function New-RolledTask {
    param(
        [object]$SourceTask,
        [int]$NewSeq,
        [string]$RolledFromDate
    )
    return [PSCustomObject]@{
        Seq          = $NewSeq
        Title        = $SourceTask.Title
        Type         = $SourceTask.Type
        Status       = 'Stopped'
        Hours        = [double]0.0
        RunningSince = ''
        FormalId     = $SourceTask.FormalId
        RolledFrom   = $RolledFromDate
        SessionLines = [System.Collections.Generic.List[string]]::new()
        MemoLines    = [System.Collections.Generic.List[string]]::new($SourceTask.MemoLines)
    }
}
```

**責務:** 繰越元タスクから繰越用の新タスクオブジェクトを生成する。

**フィールドコピー仕様（AC-30, AC-31, AC-32）:**

| フィールド | 値 | 根拠 |
| --- | --- | --- |
| `Seq` | `$NewSeq`（当日の次の連番） | AC-30 |
| `Title` | `$SourceTask.Title` そのまま | AC-31 |
| `Type` | `$SourceTask.Type` そのまま | AC-31 |
| `Status` | `'Stopped'` 固定 | AC-31 |
| `Hours` | `0.00` リセット | AC-30 |
| `RunningSince` | `''`（Stopped のため不要） | — |
| `FormalId` | `$SourceTask.FormalId` そのまま | AC-31 |
| `RolledFrom` | `$RolledFromDate`（直近稼働日 `YYYY-MM-DD`） | AC-30, AC-32 |
| `SessionLines` | 空の List | AC-30 |
| `MemoLines` | `$SourceTask.MemoLines` をコピー | AC-31 |

**MemoLines の扱い（確定）:**
前日の調査メモ・参照先などは翌日の作業でも参照できるよう繰越元の `MemoLines` をコピーして
引き継ぐ（AC-31）。`SessionLines`（作業時刻の記録）は空にするが、自由記述メモは
前日のコンテキストとして保持する。ユーザーがメモに日付を手書きする運用を前提とし、
ツールによる日付の自動付与は行わない。

**再繰越時の挙動（AC-32）:**
既に `RolledFrom` が付いているタスクを繰越する場合も、本関数を呼び出すだけで
`$RolledFromDate`（今回の直近稼働日）が上書きされる。特別な処理不要。

### 3.6 Read-DailyFile の拡張（#region DAILY）

**変更点 1: タスクオブジェクト初期化に `RolledFrom = ''` を追加（AC-37）**

```powershell
# 変更前
$currentTask = [PSCustomObject]@{
    Seq          = [int]$Matches[1]
    ...
    FormalId     = ''
    SessionLines = ...
    MemoLines    = ...
}

# 変更後
$currentTask = [PSCustomObject]@{
    Seq          = [int]$Matches[1]
    ...
    FormalId     = ''
    RolledFrom   = ''       # ← 追加
    SessionLines = ...
    MemoLines    = ...
}
```

**変更点 2: `switch` 内に `rolled_from` キーの解析を追加（AC-37）**

```powershell
# 変更前
switch ($key) {
    'type'          { $currentTask.Type         = $val }
    'status'        { $currentTask.Status       = $val }
    'hours'         { $currentTask.Hours        = [double]$val }
    'running_since' { $currentTask.RunningSince = $val }
    'formal_id'     { $currentTask.FormalId     = $val }
}

# 変更後（rolled_from を追加）
switch ($key) {
    'type'          { $currentTask.Type         = $val }
    'status'        { $currentTask.Status       = $val }
    'hours'         { $currentTask.Hours        = [double]$val }
    'running_since' { $currentTask.RunningSince = $val }
    'formal_id'     { $currentTask.FormalId     = $val }
    'rolled_from'   { $currentTask.RolledFrom   = $val }  # ← 追加
}
```

**後方互換保証（AC-37）:**
`rolled_from:` 行が存在しない既存 v0.2 ファイルを読む際、`RolledFrom` プロパティは
初期値 `''` のまま維持される。既存コードへの影響なし。

### 3.7 Write-DailyFile の拡張（#region DAILY）

**変更点: `formal_id:` 行の直後に `rolled_from:` 行を条件付き出力（AC-32, AC-38）**

```powershell
# 変更前
$lines.Add("formal_id: $($task.FormalId)")
$lines.Add('')

# 変更後
$lines.Add("formal_id: $($task.FormalId)")
if ($null -ne $task.PSObject.Properties['RolledFrom'] -and $task.RolledFrom -ne '') {
    $lines.Add("rolled_from: $($task.RolledFrom)")
}
$lines.Add('')
```

**`PSObject.Properties['RolledFrom']` 防御チェックの理由:**
`Invoke-TmNew` が生成するタスクオブジェクトには現在 `RolledFrom` プロパティが存在しない。
`Write-DailyFile` は `Invoke-TmNew` 後の書き込みでも呼ばれるため、プロパティ存在チェックが必要。

**追加対応（推奨）:** `Invoke-TmNew` のタスクオブジェクト生成にも `RolledFrom = ''` を追加すると
防御チェックが不要になり、コードが簡潔になる。本 v0.3 実装時に合わせて修正する。

**空配列渡し時の挙動確認（AC-29, B-2）:**
現行 `Write-DailyFile` に `@()` を渡すと `foreach ($task in $Tasks)` が 0 回ループし、
フロントマター（`date:` のみ）だけのファイルが生成される。**追加変更不要。**

```
出力例（空配列渡し時）:
---
date: 2026-05-05
---

```

### 3.8 DISPATCH 層の変更（#region DISPATCH）

**変更前（コメントアウト）:**

```powershell
# 'rollover'{ Invoke-TmRollover ... } # v1.0
```

**変更後（有効化 + AC-23 不正引数チェック）:**

```powershell
'rollover' {
    if ($Rest.Count -gt 0) {
        Write-TmError "tm rollover: 引数・オプションは受け付けません。"
    }
    Invoke-TmRollover
}
```

**注記:** `$Rest.Count -gt 0` であれば内容を問わず `Write-TmError`（exit 1）。
`tm rollover` に他コマンドと同様 `''` 空文字コマンド時の挙動は変更なし。

また、CONFIG リージョンのバージョン番号を更新する:

```powershell
# 変更前
$ScriptVersion = '0.2.0'

# 変更後
$ScriptVersion = '0.3.0'
```

---

## 4. AC との対応表

| AC | 該当関数 / 処理ステップ | 出力ヘルパー | exit |
| --- | --- | --- | --- |
| AC-23 | DISPATCH 'rollover' ケース（$Rest.Count > 0 チェック） | `Write-TmError` | 1 |
| AC-24 | `Find-LatestWorkingDayPath`（-1 日から 90 日遡り） | — | — |
| AC-25 | `Find-LatestWorkingDayPath` → `$null` 返却 / `Invoke-TmRollover` ステップ2 | `Write-TmWarn` | 0 |
| AC-26 | `Test-RolloverAlreadyDone` / `Invoke-TmRollover` ステップ1 | `Write-TmWarn` | 0 |
| AC-27 | `Get-StoppedTasks`（Stopped のみフィルタ） | — | — |
| AC-28 | `Get-StoppedTasks`（Running は暗黙除外・出力なし） | なし（silently skip） | — |
| AC-29 | `Invoke-TmRollover` ステップ5（`Write-DailyFile @()`） | — | — |
| AC-30 | `New-RolledTask`（Seq 採番 / Hours=0.00 / SessionLines 空 / RolledFrom 設定） | — | — |
| AC-31 | `New-RolledTask`（Title / Type / Status='Stopped' / FormalId 引き継ぎ） | — | — |
| AC-32 | `New-RolledTask`（RolledFrom 上書き） / `Write-DailyFile` 拡張（formal_id 直後に配置） | — | — |
| AC-33 | `Invoke-TmRollover` ステップ8（N≥1 時の完了メッセージ出力） | `Write-TmInfo` | 0 |
| AC-34 | `Invoke-TmRollover` ステップ8（hours を含めない出力フォーマット） | `Write-TmInfo` | 0 |
| AC-35 | `Invoke-TmRollover` ステップ7（$srcPath には一切書き込まない） | — | — |
| AC-36 | `Invoke-TmReport` は変更なし（hours=0.00 により二重計上が原理的に発生しない） | — | — |
| AC-37 | `Read-DailyFile` 拡張（RolledFrom='' 初期化 / rolled_from: パース追加） | — | — |
| AC-38 | `Write-DailyFile` 拡張（RolledFrom 非空時のみ rolled_from: 行出力） | — | — |
| AC-39 | `Invoke-TmRollover` ステップ4（Stopped 0件分岐） | `Write-TmInfo` | 0 |

---

## 5. データ構造の変更

### 5.1 タスクオブジェクト（PSCustomObject）

| プロパティ | v0.2 | v0.3 | 備考 |
| --- | --- | --- | --- |
| `Seq` | ✅ | ✅ | |
| `Title` | ✅ | ✅ | |
| `Type` | ✅ | ✅ | |
| `Status` | ✅ | ✅ | |
| `Hours` | ✅ | ✅ | |
| `RunningSince` | ✅ | ✅ | |
| `FormalId` | ✅ | ✅ | |
| `RolledFrom` | — | **追加** `''` or `'YYYY-MM-DD'` | AC-37 後方互換あり |
| `SessionLines` | ✅ | ✅ | |
| `MemoLines` | ✅ | ✅ | |

### 5.2 日次ファイルのタスクブロック形式変更

**変更前（v0.2 まで / 繰越元ファイルの原本 / rolled_from なしの通常タスク）:**

```markdown
## [2] ログイン障害の調査 (#11234)
type: ISS
status: Stopped
hours: 1.50
formal_id:

[09:00-10:30] (1.50h)

---
```

**変更後（v0.3 以降 / 繰越タスク）:**

```markdown
## [3] ログイン障害の調査 (#11234)
type: ISS
status: Stopped
hours: 0.00
formal_id:
rolled_from: 2026-05-02

---
```

フィールド配置順: `type` → `status` → `hours` → `running_since`（任意） → `formal_id` → `rolled_from`（任意）

### 5.3 日次ファイルの frontmatter 形式（B-2 確認）

現行 `Write-DailyFile` の実装を確認した結果、frontmatter は `date:` フィールドのみ出力する。
AC-29 の「frontmatter（`date:` のみ）」は実装と一致している。追加変更不要。

```markdown
---
date: 2026-05-05
---

```

---

## 6. テスト方針（tests/manual/scenario-06-rollover.ps1）

| # | シナリオ | 確認する AC |
| --- | --- | --- |
| 1 | 標準ケース: 前日に Stopped 2件 → 翌朝 rollover → 当日ファイルに繰越済みタスク2件が追加（繰越元ファイルが変更されていないことも確認） | AC-23, AC-24, AC-27, AC-30, AC-31, AC-32, AC-33, AC-34, AC-35 |
| 2 | 連休明け: 前日・前々日はなし、3日前のファイルに Stopped 1件 → rollover で3日前から繰越 | AC-24 |
| 3 | 二重実行: rollover を 2 回 → 2回目は「本日は既に繰越実行済みです」警告 + exit 0、タスク重複なし | AC-26 |
| 4 | 90日上限: 95日前のファイルのみ存在（直近90日にファイルなし） → 「見つかりません」警告 + exit 0 | AC-25 |
| 5 | Stopped 0件: 直近稼働日に Done / Running のみ → 「繰越対象なし（直近の稼働日: YYYY-MM-DD）」 + exit 0 | AC-27, AC-39 |
| 6 | Running 混在: Stopped と Running が混在 → Stopped のみ繰越。Running タスクは当日ファイルに現れない | AC-27, AC-28 |
| 7 | 当日ファイル無し: 当日ファイルが存在しない状態で rollover → ファイル自動生成 + 繰越完了 | AC-29 |
| 8 | 不正引数: `tm rollover x` → exit 1（エラーメッセージあり） | AC-23 |
| 9 | 後方互換: v0.2 形式（rolled_from 不在）の日次ファイルを Read-DailyFile で読み込んでもエラーなし | AC-37 |
| 10 | tm report 影響なし: 繰越前後で月次合計が変わらない（前日 1.50h + 当日 0.00h = 1.50h） | AC-36 |
| 11 | rolled_from 出力: 繰越タスクにのみ `rolled_from:` 行が存在。当日ファイルの既存タスクには不在 | AC-38 |
| 12 | 再繰越: rolled_from 付きタスクをさらに翌日に rollover → `rolled_from:` が新しい直近稼働日で上書きされる | AC-32 |

---

## 7. functional-design-v03.md への波及修正（B章対応）

**本 design.md 作成タイミングで functional-design-v03.md にも以下を反映する。**

### B-1: §2.1 末尾に不正引数時 exit 1 の補足を追加（AC-23 連動）

```markdown
# 変更前（§2.1 末尾）
パラメータ・オプションなし。

# 変更後
パラメータ・オプションなし。
※ 不正な引数・オプションを渡された場合は `Write-TmError` でエラーメッセージを出力し exit 1 で終了する（AC-23）。
```

### B-2: §2.3 ステップ4 末尾に frontmatter 形式の補記を追加（AC-29 連動）

```markdown
# 変更前（§2.3 ステップ4）
   - 当日のファイルが存在しない → Write-DailyFile に空配列を渡して frontmatter のみのファイルを生成する

# 変更後
   - 当日のファイルが存在しない → Write-DailyFile に空配列を渡して frontmatter のみのファイルを生成する
     ※ 生成される frontmatter は `date:` フィールドのみ（Write-DailyFile の既定形式。tm.ps1 実装確認済み）。
```

---

## 8. リスク・移行・運用注意

| 項目 | 内容 |
| --- | --- |
| **既存ファイルとの後方互換** | v0.2 以前の日次ファイルには `rolled_from:` 行が存在しない。`Read-DailyFile` の拡張（§3.6）で `RolledFrom = ''` を初期値とすることで、既存ファイル読み込み時にエラーは発生しない |
| **tm fix との相互作用** | 繰越タスクは `hours = 0.00` / セッション行が空のため、`tm fix` でセッション行を指定する操作は「セッションが存在しない」エラーとなる。繰越後に `tm start` / `tm stop` を実行してからでないと `tm fix` は使えない。これは AC-30 の意図通りの挙動 |
| **セッション行が空のタスクへの tm start** | 繰越直後のタスクは `status = Stopped` / `SessionLines` 空。`tm start` すると `running_since` がセットされ、`tm stop` で初めてセッション行が追加される。通常運用フローと同じため問題なし |
| **誤って繰越されたタスクを削除したい場合** | `tm rollover` の「繰越取り消し」コマンドは v0.3 スコープ外。当日の日次ファイルを `tm open` で開き、該当タスクセクション（`## [N]` 行から次の `---` まで）を手動削除する。連番の再採番は不要（`tm list` が連番ベースで表示するため、歯抜け連番になるがツール動作には影響しない） |
| **`Invoke-TmNew` への RolledFrom 追加** | §3.7 で推奨した `RolledFrom = ''` の追加を忘れると、`Invoke-TmNew` 後に `Write-DailyFile` を呼ぶパスで PSObject プロパティチェックが必須になる。必ず合わせて修正すること |

---

## 9. 受け入れ条件カバレッジチェック表

| AC | 該当関数（§3） | scenario-06 ケース（§6） |
| --- | --- | --- |
| AC-23 | DISPATCH + §3.8 | ケース 1, 8 |
| AC-24 | §3.2 `Find-LatestWorkingDayPath` | ケース 1, 2 |
| AC-25 | §3.2 `Find-LatestWorkingDayPath` | ケース 4 |
| AC-26 | §3.3 `Test-RolloverAlreadyDone` | ケース 3 |
| AC-27 | §3.4 `Get-StoppedTasks` | ケース 1, 5, 6 |
| AC-28 | §3.4 `Get-StoppedTasks` | ケース 6 |
| AC-29 | §3.1 ステップ5 + §3.7 B-2 確認 | ケース 7 |
| AC-30 | §3.5 `New-RolledTask` | ケース 1 |
| AC-31 | §3.5 `New-RolledTask` | ケース 1 |
| AC-32 | §3.5 `New-RolledTask` + §3.7 | ケース 1, 12 |
| AC-33 | §3.1 ステップ8 | ケース 1 |
| AC-34 | §3.1 ステップ8 | ケース 1 |
| AC-35 | §3.1 ステップ7（$srcPath 不変） | ケース 1（繰越元ファイルの変更なし確認） |
| AC-36 | Invoke-TmReport 変更なし | ケース 10 |
| AC-37 | §3.6 `Read-DailyFile` 拡張 | ケース 9 |
| AC-38 | §3.7 `Write-DailyFile` 拡張 | ケース 11 |
| AC-39 | §3.1 ステップ4 | ケース 5 |
