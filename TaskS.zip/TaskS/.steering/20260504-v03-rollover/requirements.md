# requirements — v0.3 rollover コマンド

## 1. 概要

### 背景・目的

v0.1/v0.2 では翌日の作業開始時に前日の未完了タスクを手動で `tm new` し直す必要があった。
v0.3 では `tm rollover` コマンドを追加し、直近の稼働日の Stopped タスクを当日の日次ファイルへ
ワンコマンドで全件繰り越せるようにする。

繰越タスクは `hours = 0.00` / セッション行 = 空でスタートし、当日分の作業のみを計上する。
これにより `tm report` の期間集計に二重計上は発生しない。

### 参照ドキュメント

- 機能仕様の確定版: [docs/functional-design-v03.md](../../docs/functional-design-v03.md)
- プロダクト要求定義: [docs/product-requirements.md](../../docs/product-requirements.md)

### 本ドキュメントの位置づけ

PRD と機能設計書の橋渡しとして、実装ゴーサインの基準となる受け入れ条件（AC）を正式化する。
実装担当者はすべての AC が scenario テストで検証されることを確認してから v0.3 をリリースする。

PRD §7 の AC は機能ごとの高レベル AC（粒度: 機能単位）であり、本ファイルの AC（粒度: 実装条件単位）とは階層が異なる**別系統**である。本ファイルの AC-23〜AC-39 は PRD §7 AC-13 の詳細展開に位置づけられる。

---

## 2. ユーザーストーリー

| ID | ストーリー |
| --- | --- |
| US-15 | 開発者として、翌朝 `tm rollover` を実行することで、前日の Stopped タスクをそのまま当日の日次ファイルへ引き継ぎ、すぐに作業を再開できるようにしたい。 |
| US-16 | 開発者として、連休明けや数日間の休暇明けでも、最も近い稼働日（日次ファイルが存在する日）のタスクだけが繰り越されるようにしたい。土日・祝日の有無を意識せずに使いたい。 |
| US-17 | 開発者として、誤って `tm rollover` を 2 回実行しても、タスクの重複や上書きが発生しないようにしたい。 |
| US-18 | 開発者として、繰越タスクが `tm report` の集計で前日分と二重計上されないようにしたい。当日に作業した分だけが今日の工数として記録されてほしい。 |
| US-19 | 開発者として、90 日以上日次ファイルが途絶えていた場合は警告で処理を止め、意図しない遠すぎる日付のタスクが繰り越されないようにしたい。 |
| US-20 | 開発者として、繰越元ファイル（過去日の日次ファイル）の内容が変更されず、原本として履歴に保たれることを期待する。後から `tm fix -Date YYYY-MM-DD` で過去の記録を修正できる状態を維持したい。 |

---

## 3. 受け入れ条件

> **出力ヘルパー規約:** 各 AC に出力ヘルパー名の指定がない場合は `development-guidelines.md §7` の規約（`Write-TmError` → exit 1 / `Write-TmWarn` → exit 0 / `Write-TmInfo` → 通常情報）に従う。

| ID | 条件 |
| --- | --- |
| AC-23 | `tm rollover` は引数・オプションを取らない。パラメータを渡しても無視されるのではなく、ディスパッチ層でエラー（exit 1）とする |
| AC-24 | 「直近の稼働日」は実行日の前日から 1 日ずつ過去へ遡り、`$TM_ROOT/daily/YYYY/MM/YYYY-MM-DD.md` が存在する最初の日付として決定される |
| AC-25 | 遡り探索の上限は過去 90 日。90 日以内に日次ファイルが見つからない場合は `Write-TmWarn` でメッセージを出力し exit 0 で終了する |
| AC-26 | 当日の日次ファイルが存在し、かつ `rolled_from:` フィールドを持つタスクが 1 件以上ある場合は `Write-TmWarn` で「本日は既に繰越実行済みです。」を出力し exit 0 で終了する（二重繰越防止） |
| AC-27 | 繰越対象は直近の稼働日のファイル内で `status: Stopped` のタスクのみ。`Running` / `Done` は対象外 |
| AC-28 | 直近の稼働日に `Running` タスクが残っていた場合、警告メッセージなしで silently skip する |
| AC-29 | 当日の日次ファイルが存在しない場合、`Write-DailyFile` に空配列を渡して frontmatter（`date:` のみ）のファイルを自動生成してから繰越処理を進める |
| AC-30 | 各 Stopped タスクをコピーする際、以下のフィールドを上書きする: 連番 `## [N]`（当日の次の連番）/ `hours:` を `0.00` にリセット / セッション行を空にする / `rolled_from:` に直近の稼働日の日付（`YYYY-MM-DD`）を設定する |
| AC-31 | タイトル / `type:` / `status: Stopped` / `formal_id:` / メモ行は繰越元の値をそのまま引き継ぐ |
| AC-32 | `rolled_from:` フィールドは `formal_id:` の直後に配置する。既に `rolled_from:` が付いているタスクを再度繰り越す場合は直近の稼働日の日付で上書きする。想定例: 連休中に毎日 rollover を実行する場合、各日の `rolled_from:` は前回の直近稼働日で上書きされていく |
| AC-33 | （繰越タスクが 1 件以上ある場合）完了メッセージは以下の順で出力する: 1行目「`直近の稼働日: YYYY-MM-DD`」/ 続く行「`[連番] タイトル  TYPE`」（繰り越したタスクを 1 件 1 行）/ 最終行「`N 件のタスクを繰り越しました`」。※ タイトルと TYPE の間のパディング規則（コラム揃えの方法）は design.md で確定する。N=0 の場合は AC-39 を参照 |
| AC-34 | 完了メッセージの各タスク行には `hours` を含めない（繰越後は `0.00` になるため） |
| AC-35 | 繰越元ファイル（直近の稼働日の日次ファイル）は一切変更しない |
| AC-36 | `Invoke-TmReport` は変更しない。`hours = 0.00` リセット（AC-30）により二重計上は発生しない |
| AC-37 | `Read-DailyFile` は `rolled_from:` フィールドが存在しない既存タスクを読み込む際、`RolledFrom = ''`（空文字列）として扱う（後方互換） |
| AC-38 | `Write-DailyFile` はタスクの `RolledFrom` が空でなければ `rolled_from: YYYY-MM-DD` 行を出力し、空の場合はその行を出力しない |
| AC-39 | 直近の稼働日に Stopped タスクが 0 件の場合は「`繰越対象なし（直近の稼働日: YYYY-MM-DD）`」を出力して exit 0 で終了する |

---

## 4. スコープ外（v0.3 で扱わないこと）

| 項目 | 理由・予定 |
| --- | --- |
| 当日中に複数の繰越元から繰り越す | `rolled_from:` が「実行済みフラグ」を兼用するため（AC-26）。複数繰越元対応は v1.0 以降の検討対象 |
| 繰越チェーンの履歴追跡（`rolled_from` 多段保持） | v0.3 では再繰越時に `rolled_from:` を上書きする（AC-32）。チェーン追跡は v1.0 以降 |
| 繰越タスクへの `tm fix` の意味論 | AC-30 により繰越タスクのセッション行は空のため、`tm fix` との不整合は発生しない。過去日セッションの修正は `tm fix -Date YYYY-MM-DD` で繰越元ファイルに対して行う運用を推奨 |
| `-Date` / `-Days` 等のオプション追加 | v1.0 以降の検討対象 |
| ISS 採番 / `tm issue new` / `tm promote` / `formal_id` 連動 | v1.0 スコープ |
| `tm rollover` の Running タスクへの警告出力 | v0.3 では silently skip と確定（AC-28）。v1.0 での明示的な警告追加は再検討可 |

---

## 5. 依存関係 / 連動更新ドキュメント

下記ドキュメントへの連動更新が v0.3 リリースまでに必要。

| ドキュメント | 更新内容 | 更新タイミング |
| --- | --- | --- |
| [docs/functional-design-v03.md](../../docs/functional-design-v03.md) | 仕様の確定版。本 requirements の主入力。フリーズ済み | 完了 |
| [docs/product-requirements.md](../../docs/product-requirements.md) | §3 機能一覧に rollover を v0.3 列でチェック / §4 成功の定義に v0.3 追加 / §6 に US-15〜US-20 追加 / §7 に AC-13（rollover 高レベル AC）追加 | v0.3 requirements.md 確定後 |
| [docs/glossary.md](../../docs/glossary.md) | 稼働日 / 繰越（Rollover）/ `rolled_from:` / 繰越元・繰越先 の用語追加 | 本 requirements.md 確定後 |
| [docs/repository-structure.md](../../docs/repository-structure.md) | COMMANDS 表に `Invoke-TmRollover` 追加 / `tests/manual/` に scenario-06 追記 / ステアリング命名例に追記 | v0.3 実装フェーズ |
| [docs/usage.md](../../docs/usage.md) | コマンドリファレンス表に `tm rollover` 追加 / §3「1日の流れ」に rollover を組み込む / 新節「tm rollover」追加 | v0.3 実装完了後 |
| [docs/architecture.md](../../docs/architecture.md) | §10 に rollover の正常系・警告系の出力先・exit コードを追記 / フィールド一覧に `rolled_from:` 追記 | v0.3 design.md 確定時 |
| [CHANGELOG.md](../../CHANGELOG.md) | `[0.3.0]` エントリ追加（tm rollover / `rolled_from:` / Read-DailyFile・Write-DailyFile の変更） | v0.3 リリース手順時 |
