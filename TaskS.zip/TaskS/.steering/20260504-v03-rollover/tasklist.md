# tasklist.md — v0.3 rollover コマンド

> 作業計画と進捗管理。実装・テスト・ドキュメント更新のチェックリスト。
> 仕様は `.steering/20260504-v03-rollover/requirements.md` と `design.md`、及び `docs/functional-design-v03.md` を参照。

> 進捗凡例: `[ ]` 未着手 / `[~]` 進行中 / `[x]` 完了

---

## 1. 作業スコープ

- **追加するもの:** `Invoke-TmRollover` 関数（`#region COMMANDS`）/ `Find-LatestWorkingDayPath` / `Test-RolloverAlreadyDone` / `Get-StoppedTasks` / `New-RolledTask`（`#region DAILY`）/ `rollover` ディスパッチケース（`#region DISPATCH`）
- **変更するもの:** `Read-DailyFile`（`RolledFrom` プロパティ追加）/ `Write-DailyFile`（`rolled_from:` フィールド出力対応）/ `Invoke-TmNew`（`RolledFrom = ''` 追加）/ `$ScriptVersion`（0.2.0 → 0.3.0）
- **変更しないもの:** `Invoke-TmReport` / `COUNTER` リージョン / `tm new` / `tm start` / `tm stop` / `tm done` / `tm list` / `tm log` / `tm open` / `tm fix` の各コマンド実装
- **仕様の源泉:** `docs/functional-design-v03.md` と `design.md`（ともにフリーズ済み）
- **テスト方針:** `tests/manual/scenario-06-rollover.ps1` を新規作成し、AC-23〜AC-39 の全件をカバーする（12 ケース）

---

## 2. 実装タスク

### 2.1 事前準備

- [x] `design.md §1 〜 §9` を通読し、実装のイメージを固める
- [x] `tm.ps1` の `Read-DailyFile` / `Write-DailyFile` / `Invoke-TmNew` の実装スタイル（PSCustomObject 構造・switch パース・Set-Content 書き出し）を確認し、v0.3 変更箇所との整合を確認する

### 2.2 CONFIG リージョン

- [x] `$ScriptVersion` を `'0.2.0'` → `'0.3.0'` に更新（参照: design.md §3.8）

### 2.3 DAILY リージョン — 既存関数の変更

- [x] **Read-DailyFile — RolledFrom 初期化追加（AC-37）:**
  - タスクオブジェクト（PSCustomObject）の初期化ブロックに `RolledFrom = ''` を追加する
  - `FormalId = ''` の直後に配置する（design.md §3.6 変更点1 参照）

- [x] **Read-DailyFile — rolled_from キーの解析追加（AC-37）:**
  - フロントマターパース用 `switch ($key)` に `'rolled_from' { $currentTask.RolledFrom = $val }` を追加する
  - `'formal_id'` ケースの直後に配置する（design.md §3.6 変更点2 参照）

- [x] **Write-DailyFile — rolled_from 行の条件付き出力（AC-32, AC-38）:**
  - `$lines.Add("formal_id: $($task.FormalId)")` の直後に以下を追加する:
    ```powershell
    if ($null -ne $task.PSObject.Properties['RolledFrom'] -and $task.RolledFrom -ne '') {
        $lines.Add("rolled_from: $($task.RolledFrom)")
    }
    ```
  - （design.md §3.7 参照）

- [x] **Invoke-TmNew — RolledFrom = '' を追加（推奨対応）:**
  - `Invoke-TmNew` のタスクオブジェクト生成部に `RolledFrom = ''` を追加し、Write-DailyFile の PSObject 防御チェックを自明に通るようにする
  - （design.md §3.7 追加対応 参照）

### 2.4 DAILY リージョン — 新規関数の追加

- [x] **Find-LatestWorkingDayPath（AC-24, AC-25）:**
  - 当日の前日（`$i = 1`）から最大 90 日遡り、日次ファイルが存在する最初のフルパスを返す
  - 90 日以内に見つからない場合は `$null` を返す
  - `Get-StoppedTasks` の前に DAILY リージョン内に配置する
  - （design.md §3.2 の関数コードをそのまま実装）

- [x] **Test-RolloverAlreadyDone（AC-26）:**
  - 当日ファイルが存在しない場合は `$false` を返す
  - 存在する場合は `Read-DailyFile` で読み込み、`RolledFrom -ne ''` のタスクが 1 件以上あれば `$true` を返す
  - （design.md §3.3 の関数コードをそのまま実装）

- [x] **Get-StoppedTasks（AC-27, AC-28）:**
  - `$Tasks | Where-Object { $_.Status -eq 'Stopped' }` で Stopped タスクのみを返す
  - Running / Done は暗黙的に除外（silently skip）
  - （design.md §3.4 の関数コードをそのまま実装）

- [x] **New-RolledTask（AC-30, AC-31, AC-32）:**
  - `$SourceTask`・`$NewSeq`・`$RolledFromDate` の 3 パラメータを取る
  - `Hours = [double]0.0` / `SessionLines = List::new()` / `MemoLines = List::new($SourceTask.MemoLines)` / `RolledFrom = $RolledFromDate` を設定する
  - Title / Type / FormalId は繰越元の値をそのまま引き継ぐ
  - （design.md §3.5 の関数コードをそのまま実装）

### 2.5 COMMANDS リージョン — Invoke-TmRollover 実装

- [x] **関数骨格:** `Invoke-TmRollover` の `param()` ブロックと空実装を追加する。`Invoke-TmFix` と同じスタイルでコメントを付ける

- [x] **ステップ1 — 二重繰越チェック（AC-26）:**
  - `$todayPath = Get-DailyFilePath`
  - `Test-RolloverAlreadyDone $todayPath` が `$true` → `Write-TmWarn "本日は既に繰越実行済みです。"` / `return`

- [x] **ステップ2 — 直近の稼働日を特定（AC-24, AC-25）:**
  - `$srcPath = Find-LatestWorkingDayPath`
  - `$srcPath -eq $null` → `Write-TmWarn "直近の稼働日が見つかりません（過去90日以内にファイルなし）。"` / `return`
  - `$srcDateStr = [System.IO.Path]::GetFileNameWithoutExtension($srcPath)`

- [x] **ステップ3 — Stopped タスク抽出（AC-27, AC-28）:**
  - `try { [object[]]$srcTasks = @(Read-DailyFile $srcPath) } catch { Write-TmError ... }`
  - `[object[]]$stoppedTasks = @(Get-StoppedTasks $srcTasks)`

- [x] **ステップ4 — 0件チェック（AC-39）:**
  - `$stoppedTasks.Count -eq 0` → `Write-TmInfo "繰越対象なし（直近の稼働日: $srcDateStr）"` / `return`

- [x] **ステップ5 — 当日ファイル準備（AC-29）:**
  - `Test-Path $todayPath` が `$false` → `Write-DailyFile $todayPath @() (Get-Date).ToString('yyyy-MM-dd')` を try/catch で実行
  - `try { [object[]]$todayTasks = @(Read-DailyFile $todayPath) } catch { Write-TmError ... }`

- [x] **ステップ6 — タスクコピーと採番（AC-30, AC-31, AC-32）:**
  - `$nextSeq = $todayTasks.Count + 1`
  - `$rolledTasks = [System.Collections.Generic.List[object]]::new()`
  - `foreach ($t in $stoppedTasks)` で `New-RolledTask $t $nextSeq $srcDateStr` を呼び出し `$rolledTasks.Add(...)` / `$nextSeq++`

- [x] **ステップ7 — 当日ファイル書き込み（AC-35）:**
  - `$srcPath` には一切書き込まない
  - `$allTasks = [System.Collections.Generic.List[object]]::new()`
  - `$todayTasks.Count -gt 0` の場合 `$allTasks.AddRange([object[]]$todayTasks)` を実行
  - `$allTasks.AddRange($rolledTasks.ToArray())`
  - `try { Write-DailyFile $todayPath $allTasks.ToArray() } catch { Write-TmError ... }`

- [x] **ステップ8 — 完了メッセージ出力（AC-33, AC-34）:**
  - `Write-TmInfo "直近の稼働日: $srcDateStr"`
  - `$maxTitleLen` を `$rolledTasks | ForEach-Object { $_.Title.Length } | Measure-Object -Maximum` で算出し `PadRight` で揃える
  - 各タスク行: `Write-TmInfo "[$($t.Seq)] $($t.Title.PadRight($maxTitleLen))  $($t.Type)"`（hours を含めない）
  - `Write-TmInfo "$($rolledTasks.Count) 件のタスクを繰り越しました"`

- [x] **Invoke-TmRollover 実装全体コードレビュー:** `$srcPath` を書き込む処理が存在しないことを確認（AC-35）

### 2.6 DISPATCH リージョン

- [x] `# 'rollover'{ Invoke-TmRollover ... } # v1.0` のコメントアウトを削除し、design.md §3.8 の実装例に従って `rollover` ケースを有効化する
- [x] `$Rest.Count -gt 0` 時の `Write-TmError` チェックが `Invoke-TmRollover` 呼び出しの前に置かれていることを確認（AC-23）

---

## 3. テストタスク

### 3.1 シナリオスクリプト骨格作成

- [x] `tests/manual/scenario-06-rollover.ps1` を新規作成し、以下を `scenario-01〜05` と揃える
  - `#Requires -Version 5.1` / ヘッダコメント（対象 AC の一覧）
  - `$env:TM_ROOT` をサンドボックスディレクトリに向ける
  - `Assert` ヘルパー関数（`scenario-01〜05` と同一の定義）
  - テスト完了後の `PASS/FAIL` サマリ出力

### 3.2 正常系シナリオ

- [x] ケース1: 標準ケース — 前日に Stopped 2件 → rollover → 当日ファイルに繰越タスク2件。繰越元ファイルが変更されていないことも確認（参照: AC-23, AC-24, AC-27, AC-30, AC-31, AC-32, AC-33, AC-34, AC-35）
- [x] ケース2: 連休明け — 前日・前々日はなし、3日前のファイルに Stopped 1件 → rollover で3日前から繰越（参照: AC-24）
- [x] ケース5: Stopped 0件 — 直近稼働日に Done / Running のみ → 「繰越対象なし（直近の稼働日: YYYY-MM-DD）」出力 + exit 0（参照: AC-27, AC-39）
- [x] ケース6: Running 混在 — Stopped と Running が混在 → Stopped のみ繰越。Running タスクは当日ファイルに現れない（参照: AC-27, AC-28）
- [x] ケース7: 当日ファイルなし — 当日ファイルが存在しない状態で rollover → ファイル自動生成 + 繰越完了（参照: AC-29）
- [x] ケース9: 後方互換 — v0.2 形式（rolled_from 不在）のファイルを Read-DailyFile で読み込んでもエラーなし（参照: AC-37）
- [x] ケース10: tm report 影響なし — 繰越前後で月次合計が変わらない（前日 1.50h + 当日 0.00h = 1.50h）（参照: AC-36）
- [x] ケース11: rolled_from 出力 — 繰越タスクにのみ `rolled_from:` 行が存在。当日ファイルの既存タスクには不在（参照: AC-38）
- [x] ケース12: 再繰越 — rolled_from 付きタスクをさらに翌日に rollover → `rolled_from:` が新しい直近稼働日で上書きされる（参照: AC-32）

### 3.3 異常系シナリオ

- [x] ケース3: 二重実行 — rollover を 2 回 → 2 回目は「本日は既に繰越実行済みです。」警告 + exit 0、タスク重複なし（参照: AC-26）
- [x] ケース4: 90日上限 — 直近 90 日以内に日次ファイルなし → 「見つかりません」警告 + exit 0（参照: AC-25）
- [x] ケース8: 不正引数 — `tm rollover x` → exit 1（エラーメッセージあり）（参照: AC-23）

### 3.4 手動テスト実行・受け入れ

- [x] `tests/manual/scenario-06-rollover.ps1` をクリーン状態で実行し、全 12 ケースが意図通りの出力・exit code を返すことを確認（55/55 PASS）
- [x] `scenario-01` → `scenario-02` → `scenario-03` → `scenario-05` → `scenario-06` を連続実行し、相互にコンフリクトがないことを確認（全 FAIL 0）

---

## 4. ドキュメント更新タスク

> **更新タイミング:** requirements.md §5 の「更新タイミング」列を参照。

- [x] `docs/glossary.md` に以下の用語を追加する（requirements.md §5 確定後）: 稼働日 / 繰越（Rollover）/ `rolled_from:` / 繰越元・繰越先
- [x] `docs/repository-structure.md` に追記する（v0.3 実装フェーズ）: COMMANDS 表に `Invoke-TmRollover` 追加 / `tests/manual/` に `scenario-06-rollover.ps1` 追記
- [x] `docs/product-requirements.md` に追記する（v0.3 requirements.md 確定後）: §3 機能一覧 v0.3 列にチェック / §4 成功の定義に v0.3 追加 / §6 に US-15〜US-20 追加 / §7 に AC-13（rollover 高レベル AC）追加
- [x] `docs/usage.md` にコマンドリファレンス表・§3「1日の流れ」・新節「tm rollover」を追記する（v0.3 実装完了後）
- [x] `docs/architecture.md` に追記する（v0.3 design.md 確定時）: §10 に rollover の正常系・警告系の出力先・exit コードを追記 / フィールド一覧に `rolled_from:` 追記
- [x] `CHANGELOG.md` に `[0.3.0]` エントリを追加する（v0.3 リリース手順時）: tm rollover / `rolled_from:` / Read-DailyFile・Write-DailyFile の変更
- [x] 本ステアリングディレクトリ完了記録: 下記「完了日」欄に日付を記入する

**完了日:** 2026-05-05

---

## 5. リリース手順

- [ ] `§3.4` の全テストグリーンを確認してから進む
- [ ] `CHANGELOG.md` の `[0.3.0]` にリリース日を記入して確定する
- [ ] `git tag v0.3.0` を付与する（`docs/development-guidelines.md §9` のバージョン表参照）
- [ ] ユーザー（丸山さん）に完了を報告し、v0.3 スプリントをクローズする

---

## 6. スコープ外（v0.3 でやらない）

- 当日中に複数の繰越元から繰り越す機能（`rolled_from:` が実行済みフラグを兼用するため。v1.0 以降の検討対象）
- 繰越チェーンの履歴追跡（`rolled_from` の多段保持。v1.0 以降）
- `-Date` / `-Days` 等のオプション追加（v1.0 以降）
- `tm rollover` の Running タスクへの明示的な警告出力（v0.3 では silently skip と確定）
- `tm rollover` の「繰越取り消し」コマンド（手動削除で対応）
- ISS 採番 / `tm issue new` / `tm promote` / `formal_id` 連動（v1.0 スコープ）
