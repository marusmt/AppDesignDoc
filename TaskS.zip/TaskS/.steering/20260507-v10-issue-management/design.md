# design.md — v1.0 Issue Management & ID Numbering

> 実装アプローチと変更内容の詳細設計。仕様の源泉は `requirements.md` と `docs/functional-design-v10.md`。

---

## §1 変更対象の洗い出し

### 変更するもの

| 場所 | 変更種別 | 内容 |
|------|---------|------|
| `#region COUNTER` — `Read-Counters` | スタブ解消 | `counters.json` 読み取りを実装 |
| `#region COUNTER` — `Write-Counters` | スタブ解消 | `counters.json` 書き込みを実装 |
| `#region COMMANDS` — `Invoke-TmNew` | 機能追加 | `-Type INQ` 時に `INQ-YYYYMMDD-NN` を自動採番しタイトル先頭に付与 |
| `#region DISPATCH` — `'start'` ケース | 機能拡張 | 整数以外に `ISS-NNN/PHASE-MM` 形式を受け付ける分岐を追加 |
| `#region DISPATCH` — `''` ケース（ヘルプ） | 表示更新 | `issue` コマンドを追加表示 |
| `$ScriptVersion` | 値更新 | `'0.3.0'` → `'1.0.0'` |

### 追加するもの

| 場所 | 追加種別 | 内容 |
|------|---------|------|
| `#region COUNTER` | 新規関数 | `Get-NextIssNumber` — ISS カウンターを採番し番号（int）を返す |
| `#region COUNTER` | 新規関数 | `Get-NextInqId` — INQ カウンターを採番し `INQ-YYYYMMDD-NN` 文字列を返す |
| `#region COMMANDS` | 新規関数 | `Invoke-TmIssueNew` — ISS-NNN 採番・フォルダ・issue.md 生成 |
| `#region COMMANDS` | 新規関数 | `Invoke-TmStartByPhase` — `ISS-NNN/PHASE-MM` 識別子でタスク作成＋開始 |
| `#region DISPATCH` | 新規ケース | `'issue'` — サブコマンド `new` を処理 |

### 変更しないもの

- `Invoke-TmStart` の `[int]$Seq` パラメータと既存ロジック
- `Invoke-TmWithCounterLock` の実装本体
- `Read-DailyFile` / `Write-DailyFile` / `Invoke-TmNew` の既存フロー（INQ 採番追加のみ）
- その他すべてのコマンド（`stop` / `done` / `list` / `log` / `open` / `report` / `fix` / `rollover`）

---

## §2 Read-Counters 実装

### 設計ポイント

- `ConvertFrom-Json` は `PSCustomObject` を返す（hashableではない）ため、`inq` フィールドを明示的に hashtable へ変換する
- ファイルが存在しない場合はデフォルト構造 `@{iss=0; inq=@{}}` を返す

### 実装コード

```powershell
function Read-Counters {
    $configDir = Join-Path (Get-TmRoot) 'config'
    $path = Join-Path $configDir 'counters.json'
    if (-not (Test-Path $path)) {
        return @{ iss = 0; inq = @{} }
    }
    $raw = Get-Content -Path $path -Raw -Encoding UTF8
    $obj = $raw | ConvertFrom-Json
    $inqHt = @{}
    if ($null -ne $obj.inq) {
        $obj.inq.PSObject.Properties | ForEach-Object {
            $inqHt[$_.Name] = [int]$_.Value
        }
    }
    return @{ iss = [int]$obj.iss; inq = $inqHt }
}
```

---

## §3 Write-Counters 実装

### 設計ポイント

- `ConvertTo-Json -Depth 3` で `inq` の入れ子 hashtable まで正しくシリアライズされる
- `Set-Content` はパイプライン出力を生成しないため、呼び出し元の出力ストリームを汚染しない
- `config/` ディレクトリが存在しない場合は作成する（`Invoke-WithCounterLock` でも作るが防御的に持つ）

### 実装コード

```powershell
function Write-Counters {
    param([hashtable]$Counters)
    $configDir = Join-Path (Get-TmRoot) 'config'
    if (-not (Test-Path $configDir)) {
        New-Item $configDir -ItemType Directory -Force | Out-Null
    }
    $path = Join-Path $configDir 'counters.json'
    $Counters | ConvertTo-Json -Depth 3 | Set-Content -Path $path -Encoding UTF8
}
```

---

## §4 COUNTER リージョン — ヘルパー関数の追加

### スコープ制約と設計方針

`tm.ps1` は `Set-StrictMode -Version Latest` を宣言している。PowerShell 5.1 では `& $Action` で呼び出したスクリプトブロックは **呼び出し元関数（`Invoke-WithCounterLock`）のスコープ**のチャイルドで実行される。定義元（`Invoke-TmNew` 等）のスコープ変数（例：`$dateKey`）は参照不可であり、StrictMode 下では例外が発生する。

**方針:** スクリプトブロック内の変数をすべてブロック内で完結させた専用ヘルパー関数 `Get-NextIssNumber` と `Get-NextInqId` を COUNTER リージョンに追加する。呼び出し元は外部スコープ変数を渡す必要がなくなる。

### Get-NextIssNumber

`& $Action` の最後の式の値は `Invoke-WithCounterLock` の出力ストリームを通じて呼び出し元へ返る。`$c` はスクリプトブロック内のローカル変数のみで完結するためスコープ問題が生じない。

```powershell
function Get-NextIssNumber {
    Invoke-WithCounterLock {
        $c = Read-Counters
        $c.iss = $c.iss + 1
        Write-Counters $c
        $c.iss
    }
}
```

### Get-NextInqId

日付キー `$dk` をスクリプトブロック内で計算することで外部スコープ参照を排除する。

```powershell
function Get-NextInqId {
    Invoke-WithCounterLock {
        $dk = (Get-Date).ToString('yyyyMMdd')
        $c  = Read-Counters
        $n  = if ($c.inq.ContainsKey($dk)) { [int]$c.inq[$dk] + 1 } else { 1 }
        $c.inq[$dk] = $n
        Write-Counters $c
        "INQ-$dk-$($n.ToString('00'))"
    }
}
```

---

## §4b Invoke-TmNew の INQ 採番拡張

### 設計ポイント

- `Get-NextInqId` を呼ぶだけで採番が完結する（スコープ問題なし）
- `-Type MTG` と `-Type ISS` は採番しない（`$Type -eq 'INQ'` 条件）

### 変更箇所（Invoke-TmNew 内）

バリデーション後（`$path = Get-DailyFilePath` の直前）に以下を追加する：

```powershell
if ($Type -eq 'INQ') {
    $Title = "$(Get-NextInqId) $Title"
}
```

タスク作成後の出力行は変更不要（`$Title` が更新済みのため `INQ-YYYYMMDD-NN タイトル` が自動的に表示される）。

---

## §5 Invoke-TmIssueNew 実装

### 設計ポイント

- `Get-NextIssNumber` を呼ぶだけで採番が完結する（スコープ問題なし）
- フォルダ重複チェックはカウンター重複（counters.json 破損時）の防御
- `issue.md` は here-string で生成（インデントなし）
- `Set-Content` の `-Value` に文字列を渡すと UTF-8 BOM なしで書き込まれる（PowerShell 5.1 での `-Encoding UTF8` は BOM 付き → `[System.IO.File]::WriteAllText` を使用）

### 実装コード

```powershell
function Invoke-TmIssueNew {
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$Title
    )
    if ([string]::IsNullOrWhiteSpace($Title)) {
        Write-TmError "tm issue new: タイトルを指定してください。"
    }

    $issNum = Get-NextIssNumber
    $issId  = "ISS-$($issNum.ToString('000'))"
    $issDir = Join-Path (Get-TmRoot) "issues\$issId"

    if (Test-Path $issDir) {
        Write-TmError "$issId のフォルダが既に存在します。"
    }

    New-Item $issDir -ItemType Directory -Force | Out-Null

    $today   = (Get-Date).ToString('yyyy-MM-dd')
    $content = @"
---
id: $issId
title: $Title
status: Open
created: $today
---

## 概要

## 工程

| Phase | 内容 | 担当 | 状態 |
|-------|------|------|------|
| PHASE-01 | 分析 | - | - |
"@

    $issuePath = Join-Path $issDir 'issue.md'
    [System.IO.File]::WriteAllText($issuePath, $content, [System.Text.Encoding]::UTF8)

    Write-TmInfo "作成しました: $issId — $Title"
}
```

### BOM 問題の補足

PowerShell 5.1 の `Set-Content -Encoding UTF8` は BOM 付き UTF-8 を書き出す。
`[System.IO.File]::WriteAllText(..., [System.Text.Encoding]::UTF8)` は BOM なしで書き出す。
`Read-DailyFile` などが `Get-Content -Encoding UTF8` で読む既存コードとの整合性から BOM なしを採用する。

---

## §6 Invoke-TmStartByPhase 実装

### 識別子バリデーション

有効パターン（正規表現）: `^ISS-\d{3}/PHASE-\d{2}$`

| 入力例 | 判定 |
|--------|------|
| `ISS-001/PHASE-01` | 有効 |
| `ISS-042/PHASE-12` | 有効 |
| `ISS-001` | 無効（PHASE部なし） |
| `ISS-1/PHASE-1` | 無効（桁数不足） |
| `abc-xxx` | 無効 |

### 設計フロー

1. 識別子を正規表現でバリデーション → 不正ならエラー終了
2. 当日の日次ファイルが存在するなら `Read-DailyFile` でロード
3. `Title -eq $PhaseId` のタスクを検索
4. **存在する場合** → そのタスクの `Seq` を取得し `Invoke-TmStart $seq $Now` を呼ぶ
5. **存在しない場合** → `Invoke-TmNew -Title $PhaseId -Type 'ISS'` で自動作成し、再ロードして Seq を取得、`Invoke-TmStart $seq $Now` を呼ぶ

### 実装コード

```powershell
function Invoke-TmStartByPhase {
    param(
        [Parameter(Mandatory=$true)] [string]$PhaseId,
        [datetime]$Now = (Get-Date)
    )

    if ($PhaseId -notmatch '^ISS-\d{3}/PHASE-\d{2}$') {
        Write-TmError "tm start: 識別子の形式が不正です。整数または ISS-NNN/PHASE-MM 形式で指定してください。"
    }

    $path = Get-DailyFilePath
    $seq  = $null

    if (Test-Path $path) {
        try { [object[]]$tasks = @(Read-DailyFile $path) } catch {
            Write-TmError "日次ファイル読込失敗: $($_.Exception.Message)"
        }
        $existing = $tasks | Where-Object { $_.Title -eq $PhaseId } | Select-Object -First 1
        if ($null -ne $existing) { $seq = $existing.Seq }
    }

    if ($null -eq $seq) {
        Invoke-TmNew -Title $PhaseId -Type 'ISS'
        try { [object[]]$tasks = @(Read-DailyFile $path) } catch {
            Write-TmError "日次ファイル読込失敗: $($_.Exception.Message)"
        }
        $created = $tasks | Where-Object { $_.Title -eq $PhaseId } | Select-Object -First 1
        $seq = $created.Seq
    }

    Invoke-TmStart -Seq $seq -Now $Now
}
```

---

## §7 DISPATCH リージョン変更

### `'start'` ケースの変更

```powershell
'start' {
    if ($Rest.Count -eq 0) { Write-TmError "tm start: 連番または ISS-NNN/PHASE-MM を指定してください。" }
    $startArg = [string]$Rest[0]
    if ($startArg -match '^\d+$') {
        Invoke-TmStart ([int]$startArg)
    } elseif ($startArg -match '^ISS-\d{3}/PHASE-\d{2}$') {
        Invoke-TmStartByPhase $startArg
    } else {
        Write-TmError "tm start: 引数が不正です。整数または ISS-NNN/PHASE-MM 形式で指定してください。"
    }
}
```

### `'issue'` ケースの追加（`# 'issue'` コメントアウトと置き換え）

```powershell
'issue' {
    if ($Rest.Count -eq 0) { Write-TmError "tm issue: サブコマンドを指定してください（new）。" }
    switch ([string]$Rest[0]) {
        'new' {
            $title = if ($Rest.Count -gt 1) { [string]$Rest[1] } else { '' }
            if ([string]::IsNullOrWhiteSpace($title)) {
                Write-TmError "tm issue new: タイトルを指定してください。"
            }
            Invoke-TmIssueNew $title
        }
        default { Write-TmError "tm issue: 不明なサブコマンド: $([string]$Rest[0])" }
    }
}
```

### `''` ケース（ヘルプ表示）の更新

```powershell
''      { Write-TmInfo "tm v$ScriptVersion - 使い方: tm <command> [options]`n  new / start / stop / done / list / log / open / report / fix / rollover / issue" }
```

---

## §8 バージョン更新

```powershell
$ScriptVersion = '1.0.0'
```

---

## §9 受け入れ条件と実装の対応

| AC | 対応箇所 |
|----|---------|
| AC-C1 | `Read-Counters` — ファイル不在時デフォルト返却 |
| AC-C2 | `Write-Counters` → `Read-Counters` ラウンドトリップ |
| AC-C3 | `Invoke-WithCounterLock` — 既存実装で対応済み |
| AC-I1 | `Get-NextInqId` + `Invoke-TmNew`（初回 `01`） |
| AC-I2 | `Get-NextInqId` + `Invoke-TmNew`（2回目 `02`） |
| AC-I3 | MTG は `$Type -eq 'INQ'` 条件をスキップ |
| AC-I4 | ISS は `$Type -eq 'INQ'` 条件をスキップ |
| AC-N1 | `Get-NextIssNumber` + `Invoke-TmIssueNew` — 採番・フォルダ・ファイル生成・出力 |
| AC-N2 | `Get-NextIssNumber` — カウンター +1 連続採番 |
| AC-N3 | `Invoke-TmIssueNew` / DISPATCH `'issue'` — タイトル空チェック |
| AC-N4 | `Invoke-TmIssueNew` — here-string テンプレート |
| AC-P1 | `Invoke-TmStartByPhase` — タスク不在時 `Invoke-TmNew` で自動作成 |
| AC-P2 | `Invoke-TmStartByPhase` — Title 照合で既存タスクを開始 |
| AC-P3 | `Invoke-TmStart` — 既存の Running 自動停止ロジックを再利用 |
| AC-P4 | `Invoke-TmStartByPhase` / DISPATCH `'start'` — 正規表現不一致でエラー |

---

## §10 テスト方針

既存の `scenario-01〜06` に加え `tests/manual/scenario-07-v10.ps1` を新規作成する。

カバーする AC：AC-C1, AC-C2, AC-I1〜I4, AC-N1〜N4, AC-P1〜P4
