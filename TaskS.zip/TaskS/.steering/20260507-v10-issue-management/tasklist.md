# tasklist.md — v1.0 Issue Management & ID Numbering

> 作業計画と進捗管理。実装・テスト・ドキュメント更新のチェックリスト。
> 仕様は `requirements.md` と `design.md`、及び `docs/functional-design-v10.md` を参照。

> 進捗凡例: `[ ]` 未着手 / `[~]` 進行中 / `[x]` 完了

---

## 1. 作業スコープ

- **追加するもの（COUNTER リージョン）:** `Get-NextIssNumber` / `Get-NextInqId`（`#region COUNTER` の `Write-Counters` 直後）
- **変更するもの（COUNTER リージョン）:** `Read-Counters`（スタブ解消）/ `Write-Counters`（スタブ解消）
- **追加するもの（COMMANDS リージョン）:** `Invoke-TmIssueNew` / `Invoke-TmStartByPhase`
- **変更するもの（COMMANDS リージョン）:** `Invoke-TmNew`（INQ採番ブロック追加）
- **変更するもの（DISPATCH リージョン）:** `'start'` ケース（ISS-NNN/PHASE-MM 分岐）/ `'issue'` ケース追加（`# 'issue'` コメントアウトを解除）/ `''` ケース（ヘルプ文言）
- **変更するもの（CONFIG リージョン）:** `$ScriptVersion`（`'0.3.0'` → `'1.0.0'`）
- **変更しないもの:** `Invoke-WithCounterLock` の実装本体 / `Invoke-TmStart` / rollover 関連 / その他すべてのコマンド
- **テスト:** `tests/manual/scenario-07-v10.ps1` を新規作成（AC-C1, AC-C2, AC-I1〜I4, AC-N1〜N4, AC-P1〜P4）
- **仕様の源泉:** `design.md`（フリーズ済み）

---

## 2. 実装タスク

### 2.1 事前準備

- [ ] `design.md §1〜§10` を通読し、実装のイメージを固める
- [ ] `tm.ps1` の `#region COUNTER` / `Invoke-TmNew` / `Invoke-TmStart` / `#region DISPATCH` の現行実装を確認し、変更箇所との整合を確認する

### 2.2 CONFIG リージョン

- [ ] **`$ScriptVersion` 更新（design.md §8）:**
  - `'0.3.0'` → `'1.0.0'` に変更する

### 2.3 COUNTER リージョン — 既存スタブの解消

- [ ] **`Read-Counters` 実装（AC-C1, AC-C2 / design.md §2）:**
  - `throw "Not implemented in v0.1"` を削除し、以下を実装する
  - `counters.json` が存在しない場合は `@{ iss = 0; inq = @{} }` を返す
  - `ConvertFrom-Json` の `inq` プロパティを `PSObject.Properties` で hashtable に変換する

- [ ] **`Write-Counters` 実装（AC-C2 / design.md §3）:**
  - `throw "Not implemented in v0.1"` を削除し、以下を実装する
  - `config/` ディレクトリが存在しない場合は作成する
  - `$Counters | ConvertTo-Json -Depth 3 | Set-Content -Path $path -Encoding UTF8` で書き込む

### 2.4 COUNTER リージョン — ヘルパー関数の追加

`Write-Counters` の直後（`#endregion COUNTER` の直前）に追加する。

- [ ] **`Get-NextIssNumber` 追加（AC-N1, AC-N2 / design.md §4）:**
  - `Invoke-WithCounterLock` に渡すスクリプトブロック内でのみ変数を使用する（外部スコープ参照なし）
  - `$c.iss + 1` して `Write-Counters`、最後の式 `$c.iss` を返す

- [ ] **`Get-NextInqId` 追加（AC-I1, AC-I2 / design.md §4）:**
  - `$dk = (Get-Date).ToString('yyyyMMdd')` をスクリプトブロック内で計算する（外部スコープ参照なし）
  - `$c.inq[$dk]` の有無で `$n` を決定し、書き込み後に `"INQ-$dk-$($n.ToString('00'))"` を返す

### 2.5 COMMANDS リージョン — Invoke-TmNew の INQ 採番拡張

- [ ] **INQ採番ブロック追加（AC-I1〜I4 / design.md §4b）:**
  - バリデーション後（`$path = Get-DailyFilePath` の直前）に以下を追加する:
    ```powershell
    if ($Type -eq 'INQ') {
        $Title = "$(Get-NextInqId) $Title"
    }
    ```
  - `-Type MTG` / `-Type ISS` では採番されないことを確認する（条件分岐で自明）

### 2.6 COMMANDS リージョン — Invoke-TmIssueNew 追加

`Invoke-TmNew` の直後に追加する。

- [ ] **関数骨格とバリデーション（AC-N3 / design.md §5）:**
  - `param([Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$Title)`
  - `[string]::IsNullOrWhiteSpace($Title)` チェック → `Write-TmError`

- [ ] **ISS採番（AC-N1, AC-N2）:**
  - `$issNum = Get-NextIssNumber`
  - `$issId = "ISS-$($issNum.ToString('000'))"`

- [ ] **フォルダ生成と重複チェック（AC-N1）:**
  - `$issDir = Join-Path (Get-TmRoot) "issues\$issId"`
  - `Test-Path $issDir` が `$true` → `Write-TmError "$issId のフォルダが既に存在します。"`
  - `New-Item $issDir -ItemType Directory -Force | Out-Null`

- [ ] **issue.md 生成（AC-N4 / design.md §5）:**
  - here-string でテンプレートを生成する（`id:` / `title:` / `status: Open` / `created:` / `## 概要` / `## 工程` / Phase 表）
  - `[System.IO.File]::WriteAllText($issuePath, $content, [System.Text.Encoding]::UTF8)` で BOM なし UTF-8 書き込み

- [ ] **完了メッセージ（AC-N1）:**
  - `Write-TmInfo "作成しました: $issId — $Title"`

### 2.7 COMMANDS リージョン — Invoke-TmStartByPhase 追加

`Invoke-TmIssueNew` の直後（`#endregion COMMANDS` の直前）に追加する。

- [ ] **識別子バリデーション（AC-P4 / design.md §6）:**
  - `$PhaseId -notmatch '^ISS-\d{3}/PHASE-\d{2}$'` → `Write-TmError`

- [ ] **既存タスク検索（AC-P2）:**
  - `Test-Path $path` が `$true` の場合のみ `Read-DailyFile` でロード
  - `$tasks | Where-Object { $_.Title -eq $PhaseId } | Select-Object -First 1` で照合
  - 見つかれば `$seq = $existing.Seq`

- [ ] **タスク自動作成（AC-P1）:**
  - `$seq -eq $null` の場合: `Invoke-TmNew -Title $PhaseId -Type 'ISS'` を呼ぶ
  - 再度 `Read-DailyFile` → `Where-Object { $_.Title -eq $PhaseId }` → `$seq = $created.Seq`

- [ ] **タスク開始（AC-P2, AC-P3）:**
  - `Invoke-TmStart -Seq $seq -Now $Now`
  - Running 自動停止は `Invoke-TmStart` の既存ロジックが処理する（AC-P3）

### 2.8 DISPATCH リージョン

- [ ] **`'start'` ケース変更（AC-P1〜P4 / design.md §7）:**
  - `$startArg = [string]$Rest[0]` で受け取る
  - `$startArg -match '^\d+$'` → `Invoke-TmStart ([int]$startArg)`
  - `$startArg -match '^ISS-\d{3}/PHASE-\d{2}$'` → `Invoke-TmStartByPhase $startArg`
  - それ以外 → `Write-TmError`

- [ ] **`'issue'` ケース追加（AC-N1〜N4 / design.md §7）:**
  - `# 'issue'   { Invoke-TmIssue  ... }   # v1.0` コメントを削除し有効化する
  - `$Rest.Count -eq 0` → `Write-TmError`
  - サブコマンド `'new'` → `$title = if ($Rest.Count -gt 1) { [string]$Rest[1] } else { '' }` → `Invoke-TmIssueNew $title`
  - それ以外のサブコマンド → `Write-TmError`

- [ ] **`''` ケース（ヘルプ）更新（design.md §7）:**
  - コマンド一覧に `issue` を追加する

---

## 3. テストタスク

### 3.1 シナリオスクリプト骨格作成

- [ ] `tests/manual/scenario-07-v10.ps1` を新規作成し、以下を `scenario-01〜06` と揃える
  - `#Requires -Version 5.1` / ヘッダコメント（対象 AC の一覧）
  - `$env:TM_ROOT` をサンドボックスディレクトリに向ける
  - `Assert` ヘルパー関数（`scenario-01〜06` と同一の定義）
  - テスト完了後の `PASS/FAIL` サマリ出力

### 3.2 COUNTER テスト

- [ ] **ケース1: Read-Counters ファイル不在（AC-C1）:**
  - `counters.json` が存在しない状態で `Read-Counters` を呼ぶ
  - 返り値が `@{iss=0; inq=@{}}` 相当であることを確認

- [ ] **ケース2: Write→Read ラウンドトリップ（AC-C2）:**
  - `Write-Counters @{iss=5; inq=@{'20260507'=3}}` を実行
  - `Read-Counters` で読み取り、`iss=5` / `inq['20260507']=3` を確認

### 3.3 INQ 採番テスト

- [ ] **ケース3: 初回採番（AC-I1）:**
  - `tm new "問い合わせ" -Type INQ` → タイトルが `INQ-YYYYMMDD-01 問い合わせ` になることを確認

- [ ] **ケース4: 同日2回目（AC-I2）:**
  - 続けて `tm new "別件" -Type INQ` → `INQ-YYYYMMDD-02 別件` になることを確認

- [ ] **ケース5: MTG は採番なし（AC-I3）:**
  - `tm new "定例" -Type MTG` → タイトルが `定例` のままで `INQ-` プレフィックスがないことを確認

- [ ] **ケース6: ISS は採番なし（AC-I4）:**
  - `tm new "バグ調査" -Type ISS` → タイトルが `バグ調査` のままであることを確認

### 3.4 tm issue new テスト

- [ ] **ケース7: 正常採番（AC-N1）:**
  - `tm issue new "バグ調査"` → `ISS-001` フォルダ・`issue.md` 生成・出力確認

- [ ] **ケース8: 連続採番（AC-N2）:**
  - 続けて `tm issue new "機能改善"` → `ISS-002` が採番されることを確認

- [ ] **ケース9: タイトル省略（AC-N3）:**
  - `tm issue new` → exit 1 ・エラーメッセージ確認

- [ ] **ケース10: issue.md フォーマット（AC-N4）:**
  - 生成された `issue.md` の `id:` / `title:` / `status:` / `created:` / `## 概要` / `## 工程` / PHASE 表を確認

### 3.5 ISS-NNN/PHASE-MM テスト

- [ ] **ケース11: 新規作成して開始（AC-P1）:**
  - `tm start ISS-001/PHASE-01` で当日タスクが存在しない場合、自動生成 + Running になることを確認

- [ ] **ケース12: 既存タスクを開始（AC-P2）:**
  - `tm stop` 後に `tm start ISS-001/PHASE-01` → 同タスクが再 Running になることを確認（タスクが重複しないこと）

- [ ] **ケース13: Running 自動停止（AC-P3）:**
  - 別タスクが Running 中の状態で `tm start ISS-001/PHASE-02` → 先のタスクが自動 Stopped になることを確認

- [ ] **ケース14: 不正識別子（AC-P4）:**
  - `tm start ISS-001` → exit 1 ・エラーメッセージ確認
  - `tm start abc-xxx` → exit 1 ・エラーメッセージ確認

### 3.6 手動テスト実行・受け入れ

- [ ] `tests/manual/scenario-07-v10.ps1` をクリーン状態で実行し、全ケースが意図通りの出力・exit code を返すことを確認
- [ ] `scenario-01` → `scenario-06` → `scenario-07` を連続実行し、相互にコンフリクトがないことを確認（全 FAIL 0）

---

## 4. ドキュメント更新タスク

- [ ] `docs/functional-design.md` の §1 コマンド一覧に `tm issue new` を追記する
- [ ] `docs/glossary.md` に `ISS-NNN` / `INQ-YYYYMMDD-NN` / `PHASE-MM` の用語定義を確認・追記する
- [ ] `docs/usage.md` に `tm issue new` と `ISS-NNN/PHASE-MM` の使い方を追記する
- [ ] `CHANGELOG.md` に `[1.0.0]` エントリを追加する（tm issue new / INQ 採番 / ISS-NNN/PHASE-MM 対応）
- [ ] 本ステアリングディレクトリ完了記録: 下記「完了日」欄に日付を記入する

**完了日:** 2026-05-07

---

## 5. リリース手順

- [ ] §3.6 の全テストグリーンを確認してから進む
- [ ] `CHANGELOG.md` の `[1.0.0]` にリリース日を記入して確定する

---

## 6. スコープ外（v1.0 でやらない）

- `tm promote` コマンド（`functional-design-v10.md §4` のスコープ見直しメモに従い実装しない）
- ISS-NNN の桁数拡張（4桁以上対応は別バージョン）
- PHASE 識別子のみ（`PHASE-01` 単体、ISS なし）での `tm start`
- `tm issue list` / `tm issue show` 等のサブコマンド追加
