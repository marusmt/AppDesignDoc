# requirements.md — v1.0 Issue Management & ID Numbering

> 今回の作業の要求内容。仕様の源泉は `docs/functional-design-v10.md`。

---

## 1. 作業の背景

v0.3 で `tm rollover` を実装し、`$ScriptVersion = '0.3.0'` に到達した。
v1.0 では「課題・工程管理」と「仮ID自動採番」を実装し、`tm` を本番運用可能な完全形にする。

---

## 2. 今回実装するスコープ

### 2.1 COUNTER リージョン（スタブ解消）

| 関数 | 現状 | 変更後 |
|------|------|--------|
| `Read-Counters` | `throw "Not implemented"` | `counters.json` を読み取り hashtable を返す |
| `Write-Counters` | `throw "Not implemented"` | hashtable を `counters.json` にJSON書き込み |

`counters.json` の初期構造：

```json
{
  "iss": 0,
  "inq": {}
}
```

- `iss`：ISS-NNN の最大採番値（整数）
- `inq`：`{"YYYYMMDD": N}` 形式の日別INQ連番

### 2.2 INQ 自動採番（`tm new -Type INQ`）

現行動作：`tm new "タイトル" -Type INQ` でタイプラベルのみ付与（連番なし）

v1.0 変更後：`-Type INQ` 時に `INQ-YYYYMMDD-NN` 形式のIDを自動採番し、タスクタイトル先頭に付与する。

**採番ルール：**
- `counters.json` の `inq.YYYYMMDD` を読み取り +1（初日は `1` から開始）
- 採番結果は `INQ-YYYYMMDD-01` 形式（2桁ゼロ埋め）
- タスクタイトル: `INQ-20260507-01 問い合わせ内容` のように先頭に採番IDを付加
- MTG は採番しない（`-Type MTG` はそのままタイプラベルのみ）

### 2.3 `tm issue new "タイトル"` コマンド

ISS-NNN を自動採番し、課題フォルダ・課題ファイルを生成する。

**動作：**
1. `counters.json` をロックして `iss` カウンターを +1 採番（3桁ゼロ埋め）
2. `$TM_ROOT/issues/ISS-NNN/` フォルダを作成
3. `$TM_ROOT/issues/ISS-NNN/issue.md` をテンプレートから生成
4. 採番結果を出力（例：`作成しました: ISS-001`）

**issue.md テンプレート：**

```markdown
---
id: ISS-001
title: タイトル
status: Open
created: YYYY-MM-DD
---

## 概要

## 工程

| Phase | 内容 | 担当 | 状態 |
|-------|------|------|------|
| PHASE-01 | 分析 | - | - |
```

**エラー：**
- タイトルが空 → エラー終了
- 既に同IDのフォルダが存在する → エラー終了（カウンター重複時の防御）

### 2.4 `ISS-NNN/PHASE-MM` 識別子対応（`tm start`）

現行動作：`tm start <連番>` は整数の当日連番のみ受け付ける

v1.0 変更後：`ISS-NNN/PHASE-MM` 形式の識別子も受け付け、タスクタイトルとして自動展開する。

**識別子判定：**

| 入力 | 解釈 |
|------|------|
| 整数のみ（例: `3`） | 当日連番（既存動作） |
| `ISS-NNN/PHASE-MM` パターン | 課題・工程タスクとして新規作成 |
| それ以外 | エラー |

**`ISS-NNN/PHASE-MM` 受け取り時の動作：**
1. 当日の日次ファイルに同識別子のタスクが既に存在する → そのタスクを `tm start <連番>` と同様に開始
2. 存在しない → `tm new` 相当でタスクを自動生成してから開始
   - タイトル: `ISS-NNN/PHASE-MM`
   - Type: `ISS`

### 2.5 `tm promote`（スコープ外）

`docs/functional-design-v10.md §4` のスコープ見直しメモに従い、v1.0 では実装しない。

---

## 3. 受け入れ条件

### COUNTER

- AC-C1: `counters.json` が存在しない状態で `Read-Counters` を呼ぶと `@{iss=0; inq=@{}}` を返す
- AC-C2: `Write-Counters` で書き込んだ内容を `Read-Counters` で再度読み取れる
- AC-C3: `Invoke-WithCounterLock` のロックが正常に動作する（ファイル破損なし）

### INQ 採番

- AC-I1: `tm new "問い合わせ" -Type INQ` で `INQ-YYYYMMDD-01` が採番される
- AC-I2: 同日2回目は `INQ-YYYYMMDD-02` になる
- AC-I3: `-Type MTG` では採番されない（タイプラベルのみ）
- AC-I4: `-Type ISS` では採番されない（従来通り）

### tm issue new

- AC-N1: `tm issue new "バグ調査"` → `ISS-001` 採番・フォルダ・ファイル生成・出力
- AC-N2: 連続実行で `ISS-002`, `ISS-003` と増える
- AC-N3: タイトル省略でエラー終了（exit 1）
- AC-N4: 生成された `issue.md` がテンプレート通りのフォーマット

### ISS-NNN/PHASE-MM

- AC-P1: `tm start ISS-001/PHASE-01` で当日タスクが存在しない場合、自動生成して開始
- AC-P2: `tm start ISS-001/PHASE-01` で同名タスクが既存の場合、そのタスクを開始
- AC-P3: `tm start ISS-001/PHASE-01` で別タスクが Running 中の場合、自動停止してから開始
- AC-P4: 不正な識別子（例: `abc-xxx`）はエラー終了

---

## 4. 制約事項

- ネットワーク・外部ライブラリ利用不可（PowerShell標準のみ）
- `counters.json` の読み書きは必ず `Invoke-WithCounterLock` 経由で行う
- `tm new`, `tm start` の既存動作（整数連番）を壊さない
- `$ScriptVersion` を `'0.3.0'` → `'1.0.0'` に更新

---

## 5. 更新するドキュメント（実装完了後）

| ドキュメント | 更新内容 |
|-------------|---------|
| `docs/functional-design.md` | コマンド一覧に `tm issue new` を追加 |
| `docs/glossary.md` | ISS-NNN / INQ-YYYYMMDD-NN / PHASE-MM の用語確認・追記 |
| `docs/usage.md` | `tm issue new` / `ISS-NNN/PHASE-MM` の使い方を追記 |
| `CHANGELOG.md` | `[1.0.0]` エントリを追加 |
