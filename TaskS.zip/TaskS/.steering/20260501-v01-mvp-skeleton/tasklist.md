# tasklist — v0.1 MVP スケルトン実装

> 進捗凡例: `[ ]` 未着手 / `[~]` 進行中 / `[x]` 完了

---

## フェーズ 1: スケルトン準備

### T-01 ディレクトリ構成の作成

- [x] `tests/manual/` ディレクトリを作成する
- [x] `tests/fixtures/` ディレクトリを作成する
- [x] `tm.ps1` を新規作成し、`#Requires -Version 5.1` と `Set-StrictMode -Version Latest` を冒頭に置く
- [x] 6つの `#region` ブロック（CONFIG / UTIL / DAILY / COUNTER / COMMANDS / DISPATCH）の骨格を作成する

---

## フェーズ 2: 基盤実装（CONFIG / UTIL / DAILY / COUNTER）

### T-02 #region CONFIG

- [x] `$ScriptVersion = '0.1.0'` を定義する
- [x] デフォルト Type 定数 `$DefaultType = 'ISS'` を定義する

### T-03 #region UTIL — パス解決・工数計算

- [x] `Get-TmRoot` を実装する（`$env:TM_ROOT` → フォールバック `$PSScriptRoot\tasks`）
- [x] `Get-DailyFilePath([datetime]$Date)` を実装する（`daily\YYYY\MM\YYYY-MM-DD.md` を返す）
- [x] `ConvertTo-RoundedMinutes([int]$TotalMinutes, [string]$Direction)` を実装する（Floor / Ceil）
- [x] `Get-RoundedHours([string]$StartHHMM, [string]$StopHHMM)` を実装する（15分丸め後工数を返す）

### T-04 #region UTIL — 出力ヘルパー

- [x] `Write-TmError([string]$Msg)` を実装する（`Write-Error` → `exit 1`）
- [x] `Write-TmWarn([string]$Msg)` を実装する（`Write-Warning` → `exit 0`）
- [x] `Write-TmInfo([string]$Msg)` を実装する（`Write-Output`）

### T-05 #region DAILY — ファイル読み書き

- [x] `Read-DailyFile([string]$Path)` を実装する
  - フロントマター（`---` 囲み）を読み飛ばす
  - `## [N] タイトル` ヘッダー行でタスクセクションを分割する
  - 各セクションから `Seq / Title / Type / Status / Hours / RunningSince / FormalId` を抽出する
  - `LineNumber`（ヘッダー行の行番号）も付与する
  - PSObject[] を返す
- [x] `Write-DailyFile([string]$Path, [object[]]$Tasks)` を実装する
  - フロントマターを先頭に書く
  - タスクオブジェクトをセクション形式で順番に書き出す
  - `Set-Content -Encoding UTF8` を使用する

### T-06 #region DAILY — タスク操作ヘルパー

- [x] `Get-TaskBySeq([object[]]$Tasks, [int]$Seq)` を実装する（対象なしは `$null` を返す）
- [x] `Get-RunningTask([object[]]$Tasks)` を実装する（対象なしは `$null` を返す）
- [x] `Get-TaskLineNumber([string]$Path, [int]$Seq)` を実装する（`## [N]` 行番号を返す）
- [x] `Add-SessionLine([object]$Task, [string]$Start, [string]$Stop, [double]$Hours, [string]$Comment)` を実装する（タスクのメモ行リストに追記）
- [x] `Update-TaskMeta([object]$Task, [hashtable]$Fields)` を実装する（指定フィールドを上書き）

### T-07 #region COUNTER

- [x] `Invoke-WithCounterLock([scriptblock]$Action)` を完全実装する（`docs/architecture.md §7` のロック機構）
  - `config/` ディレクトリを必要時に自動生成する
  - ロックファイル生成・タイムアウト待機・`finally` でのクリーンアップを実装する
- [x] `Read-Counters` をシグネチャのみで定義する（本体は `throw "Not implemented in v0.1"`）
- [x] `Write-Counters` をシグネチャのみで定義する（本体は `throw "Not implemented in v0.1"`）

---

## フェーズ 3: コマンド実装（#region COMMANDS）

### T-08 Invoke-TmNew（AC-01）

- [x] `param([Parameter(Mandatory=$true)] [string]$Title, [string]$Type = $DefaultType)` を定義する
- [x] タイトル未指定 → `Write-TmError` で終了する
- [x] `-Type` に ISS / INQ / MTG 以外 → `Write-TmError` で終了する
- [x] 日次ファイルが存在しない場合、ディレクトリ込みで生成しフロントマターを書く
- [x] 既存の `## [N]` 数をカウントして次の連番を決定する
- [x] タスクセクション（`status: Stopped` / `hours: 0.00`）を末尾に追記する
- [x] 完了メッセージを `Write-TmInfo` で出力する

### T-09 Invoke-TmStart（AC-02）

- [x] `param([Parameter(Mandatory=$true)] [int]$Seq)` を定義する
- [x] 指定連番が存在しない → `Write-TmError`
- [x] 対象タスクが Done → `Write-TmError`
- [x] 対象タスクがすでに Running → `Write-TmWarn`
- [x] 別の Running タスクがあれば stop 相当処理を実行する
- [x] `running_since` に現在時刻・`status: Running` に設定する
- [x] 開始メッセージを `Write-TmInfo` で出力する

### T-10 Invoke-TmStop（AC-03）

- [x] Running タスクなし → `Write-TmWarn`
- [x] `Get-RoundedHours` で工数を計算する
- [x] `Add-SessionLine` でセッション行を追記する
- [x] `hours` 加算・`running_since` 削除・`status: Stopped` にする
- [x] 停止メッセージを `Write-TmInfo` で出力する

### T-11 Invoke-TmDone（AC-04）

- [x] `param([int]$Seq = -1)` を定義する
- [x] 引数なし・連番指定の両ケースを実装する
- [x] 完了メッセージを `Write-TmInfo` で出力する

### T-12 Invoke-TmList（AC-06）

- [x] 日次ファイルが存在しない → 「本日の記録はありません」
- [x] 日付ヘッダー・各タスク行・フッターを出力する

### T-13 Invoke-TmLog（AC-05）

- [x] `=== YYYY-MM-DD ===` ヘッダーを出力する
- [x] 各タスクのセッション行・メモを出力する

### T-14 Invoke-TmOpen（AC-07）

- [x] `code` が PATH にない → `Write-TmWarn` + exit 0
- [x] 引数なし / 連番指定の両ケースを実装する

### T-15 Invoke-TmReport（AC-08 / AC-09）

- [x] 期間解決ロジック・集計ロジックを実装する
- [x] `-Csv` なし: 人間向け表形式を出力する
- [x] `-Csv` あり: タブ区切り5列をクリップボードへコピーする

---

## フェーズ 4: ディスパッチ（#region DISPATCH）

### T-16 コマンドディスパッチの実装

- [x] script-level `param()` を `#Requires` の直後に定義する（`$Command` + `ValueFromRemainingArguments $Rest`）
- [x] `switch ($Command)` で各 `Invoke-Tm*` 関数へ委譲する（named param を明示的に解析して渡す）
- [x] dot-source 時はディスパッチをスキップする（`$MyInvocation.InvocationName -ne '.'`）
- [x] `default`: `Write-TmError` で終了する

---

## フェーズ 5: 手動テストスクリプト作成

### T-17 scenario-01-typical-day.ps1（AC-01・AC-03〜AC-09）

- [x] 全18アサーション PASS 確認済み（2026-05-01）

### T-18 scenario-02-interrupt.ps1（AC-02）

- [x] 全9アサーション PASS 確認済み（2026-05-01）

### T-19 scenario-03-counter-lock.ps1（`Invoke-WithCounterLock` 動作確認）

- [x] 全5アサーション PASS 確認済み（2026-05-01）

---

## フェーズ 6: 動作確認と受け入れ

### T-20 受け入れ条件の確認

- [x] AC-01（new）: 連番採番・日次ファイル自動生成・Stopped 状態で作成される
- [x] AC-02（start）: Running 遷移・別 Running タスクの自動 Stopped・Done タスクはエラー
- [x] AC-03（stop）: Stopped 遷移・15分丸め工数計算・Running なしは警告
- [x] AC-04（done）: 引数なし / 連番指定ともに Done 遷移・工数確定
- [x] AC-05（log）: 当日タスクのメモ全文を時系列で表示
- [x] AC-06（list）: 連番・種別・状態・工数・タイトルの一覧表示
- [x] AC-07（open）: 日次ファイルを VS Code で開く / 連番指定でタスク行へジャンプ
- [x] AC-08（report）: 工数合計・カテゴリ別小計の表示
- [x] AC-09（report -Csv）: タブ区切りテキストをクリップボードへコピー

### T-21 エッジケース確認（手動確認済み・scenario-01/02 でカバー）

- [x] `tm stop` / `tm done`（引数なし）で Running タスクなし → 警告 + exit 0
- [x] `tm start <存在しない連番>` → エラー + exit 1
- [x] `tm done <Done タスクの連番>` → 警告 + exit 0
- [x] `tm new` でタイトル省略 → エラー + exit 1（Mandatory=$true で PowerShell が検出）
- [x] `tm new -Type INVALID` → エラー + exit 1
- [x] 日次ファイルなしで `tm list` / `tm log` → 「本日の記録はありません」+ exit 0

---

## 完了条件

- [x] `tm.ps1` がフェーズ 2〜4 のすべてのタスクを実装している
- [x] シナリオ T-17・T-18・T-19 がエラーなく完走する（PASS 18 / 9 / 5）
- [x] T-20 の AC-01〜AC-09 がすべてパスする
- [x] T-21 のエッジケースが期待通りの出力と exit コードを返す
- [x] `Set-StrictMode -Version Latest` 下で未定義変数エラーが発生しない
