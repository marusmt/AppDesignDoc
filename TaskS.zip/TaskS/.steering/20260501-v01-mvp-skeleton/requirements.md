# requirements — v0.1 MVP スケルトン実装

## 1. 作業概要

`tm.ps1` を新規作成し、v0.1 スコープの全コマンドを動作可能な状態にする。

---

## 2. 実装スコープ（コマンド一覧）

| コマンド | 機能 | 受け入れ条件 |
|---|---|---|
| `tm new "タイトル" [-Type ISS\|INQ\|MTG]`（`-Type` 省略時は **ISS**） | タスク作成 | AC-01 |
| `tm start <連番>` | 作業開始 | AC-02 |
| `tm stop` | 作業一時停止 | AC-03 |
| `tm done [<連番>]` | 作業完了 | AC-04 |
| `tm log` | 当日ログ表示 | AC-05 |
| `tm list` | タスク一覧表示 | AC-06 |
| `tm open [<連番>]` | VS Code で開く | AC-07 |
| `tm report [-Date YYYY-MM-DD] [-Month YYYY-MM]` | 工数集計表示（両指定時は `-Date` 優先） | AC-08 |
| `tm report -Csv [-Date YYYY-MM-DD] [-Month YYYY-MM]` | クリップボード TSV 出力（両指定時は `-Date` 優先） | AC-09 |

受け入れ条件の詳細は `docs/product-requirements.md` §7.1 を参照。

---

## 2.5 成果物

- `tm.ps1`（単一ファイル、全コマンド動作可能）
- `tests/manual/scenario-01-typical-day.ps1` — 標準的な1日のフロー（new → start → stop → done → list → report）
- `tests/manual/scenario-02-interrupt.ps1` — 割り込み対応フロー（start 中に別タスクへ切替、自動 Stopped を確認）
- テスト実行は `$env:TM_ROOT = Join-Path $env:TEMP 'tm-test'` でサンドボックス化する

---

## 3. ユーザーストーリー（v0.1 対象）

| # | ストーリー |
|---|---|
| US-01 | `tm new "タイトル"` で当日連番が採番され、Stopped 状態のタスクが作成される |
| US-02 | `tm new "定例朝会" -Type MTG` のように種別を指定してタスクを作成できる（v0.1 ではラベル付与のみ） |
| US-03 | `tm list` で当日タスクの連番・種別・状態・工数・タイトルを一覧確認できる |
| US-04 | `tm open` / `tm open <連番>` で日次ファイルを VS Code で開ける |
| US-05 | `tm start <連番>` でタスクが Running になる |
| US-06 | `tm stop` で Running タスクが Stopped になり、工数が確定する |
| US-07 | `tm done` / `tm done <連番>` でタスクが Done になり、工数が確定する |
| US-09 | Running 中に `tm start <別連番>` すると前のタスクが自動停止される |
| US-12 | `tm log` で当日の全タスクのメモ全文を時系列で確認できる |
| US-13 | `tm report` で工数合計とカテゴリ別小計を確認できる |
| US-14 | `tm report -Csv` でタブ区切り工数集計がクリップボードへコピーされ、Excel に貼り付けられる |

---

## 4. 制約事項

- PowerShell 5.1（Windows 標準）のみ。外部モジュール・パッケージは一切使用しない
- ネットワーク通信を行わない
- `tm.ps1` 1ファイルにすべての実装を集約する。`#region` は以下の6区画に統一する：CONFIG / UTIL / DAILY / COUNTER / COMMANDS / DISPATCH。詳細は `docs/architecture.md` §2 を参照
- 日次ファイルフォーマット（`architecture.md` §5）は**破壊的変更禁止**
- スクリプト冒頭に `#Requires -Version 5.1` を置く
- `Set-StrictMode -Version Latest` をスクリプト冒頭で有効化する
- データルートは `Get-TmRoot` で解決する。環境変数 `$env:TM_ROOT` が設定されていればそれを使用し、未設定時は `$PSScriptRoot\tasks` を使用する。詳細は `docs/architecture.md` §4 を参照
- エラー処理は専用ヘルパーを必ず経由する：ユーザーエラー／I/O 失敗 → `Write-TmError`（stderr + exit 1）、状態的に正常な「該当なし」（Running なしで `tm stop` 等）→ `Write-TmWarn`（Warning ストリーム + exit 0）
- 15分丸めロジックは `docs/architecture.md` §6 に厳密に従う（開始＝切り捨て、終了＝切り上げ、セッションごとに独立丸め）

---

## 5. スコープ外（v0.2 / v1.0 以降）

- `tm fix` — 事後修正（v0.2）
- `tm issue new` / `tm promote` — 課題管理・仮ID昇格（v1.0）
- `tm rollover` — 未完了タスクの繰越（v1.0）
- `counters.json` の実際の採番ロジック（v1.0）。ただし以下は v0.1 で実装する：
  - `Invoke-WithCounterLock` 関数（`docs/architecture.md` §7 のロック機構そのまま）
  - `config/` ディレクトリの自動生成
  - `counters.json` 読み書き関数のシグネチャのみ（中身は `throw "Not implemented in v0.1"`）
- CSV のファイル出力（v0.5 以降）
