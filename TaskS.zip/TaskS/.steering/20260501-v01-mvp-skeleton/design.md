---
sprint: v0.1-mvp-skeleton
date: 2026-05-01
status: draft
related:
  - requirements.md
  - ../../docs/functional-design.md
  - ../../docs/architecture.md
---

# design — v0.1 MVP スケルトン実装

---

## § 1 スプリント目的

v0.1 では、tm の利用者が「1日の作業を記録し、工数集計をクリップボードへコピーできる」状態を最短で実現する。
具体的には `new / start / stop / done / list / log / open / report / report -Csv` の9コマンドをすべて動作させ、
後続スプリント（v0.2 `fix`、v1.0 課題管理）で機能拡張できる **最小スケルトン** を `tm.ps1` 1ファイルとして完成させる。

詳細スコープ・受け入れ条件は `requirements.md` を参照。

---

## § 2 実装スコープ

### 含めるコマンド

| コマンド                                             | 仕様参照先                       |
| ---------------------------------------------------- | -------------------------------- |
| `tm new "タイトル" [-Type ISS\|INQ\|MTG]`            | `docs/functional-design.md §4.1` |
| `tm start <連番>`                                    | `docs/functional-design.md §4.2` |
| `tm stop`                                            | `docs/functional-design.md §4.3` |
| `tm done [<連番>]`                                   | `docs/functional-design.md §4.4` |
| `tm list`                                            | `docs/functional-design.md §4.5` |
| `tm log`                                             | `docs/functional-design.md §4.6` |
| `tm open [<連番>]`                                   | `docs/functional-design.md §4.7` |
| `tm report [-Date YYYY-MM-DD] [-Month YYYY-MM]`      | `docs/functional-design.md §4.8` |
| `tm report -Csv [-Date YYYY-MM-DD] [-Month YYYY-MM]` | `docs/functional-design.md §4.8` |

### 含めない機能（v0.2 / v1.0 以降）

- `tm issue` / `tm phase` / `tm promote` / `tm rollover`
- `INQ-*` / `MTG-*` / `ISS-*` 仮ID採番ロジック本体
- `counters.json` の実読み書き（`Read-Counters` / `Write-Counters` はシグネチャのみ）
- `config/holidays.txt` の活用
- 自動繰越・週次サマリ

---

## § 3 ファイル／モジュール構成

### tm.ps1 単一ファイル構成

`tm.ps1` 1ファイルに `#region` で以下の6区画を切る。
v1.0 での `lib/` 分割を見越したリージョン順序と関数配置に従うこと。
命名規則の詳細は `docs/repository-structure.md §4` を参照。

#### #region CONFIG

スクリプト全体の定数を定義する。

- `$ScriptVersion = '0.1.0'`
- デフォルト Type 値（`'ISS'`）

#### #region UTIL

| 関数                       | 説明                                                         |
| -------------------------- | ------------------------------------------------------------ |
| `Get-TmRoot`               | `$env:TM_ROOT` → フォールバック `$PSScriptRoot\tasks` で解決 |
| `Get-DailyFilePath`        | 指定日の日次ファイルパスを返す                               |
| `ConvertTo-RoundedMinutes` | 分単位の時刻を15分丸めする（Floor / Ceil）                   |
| `Get-RoundedHours`         | 開始・終了時刻（HH:MM）から丸め後工数（時間）を返す          |
| `Write-TmError`            | stderr へ出力 → exit 1                                       |
| `Write-TmWarn`             | Warning ストリームへ出力 → exit 0                            |
| `Write-TmInfo`             | stdout（Write-Host）へ出力                                   |

#### #region DAILY

| 関数                 | 説明                                                   |
| -------------------- | ------------------------------------------------------ |
| `Read-DailyFile`     | 日次ファイルをパースしてタスク一覧（PSObject[]）を返す |
| `Write-DailyFile`    | タスク一覧を日次ファイルへ書き出す                     |
| `Get-TaskBySeq`      | 連番でタスクを取得する                                 |
| `Get-RunningTask`    | Running 状態のタスクを返す                             |
| `Get-TaskLineNumber` | 指定タスクのファイル内行番号を返す（`tm open` 向け）   |
| `Add-SessionLine`    | タスクのメモ部にセッション行を追記する                 |
| `Update-TaskMeta`    | フロントマターフィールドを更新する                     |

#### #region COUNTER

| 関数                     | v0.1 実装範囲                                                                        |
| ------------------------ | ------------------------------------------------------------------------------------ |
| `Invoke-WithCounterLock` | **完全実装**（`docs/architecture.md §7` のロック機構そのまま）                       |
| `Read-Counters`          | シグネチャのみ（本体は v1.0 で実装）。呼び出し時は `throw "Not implemented in v0.1"` |
| `Write-Counters`         | シグネチャのみ（本体は v1.0 で実装）。呼び出し時は `throw "Not implemented in v0.1"` |

`Invoke-WithCounterLock` は v0.1 から完全実装する理由: v1.0 での `issue new` 実装時に
関数本体の修正なく即利用できる状態にするため（`docs/architecture.md §7` 参照）。

#### #region COMMANDS

| 関数              | 対応コマンド                   |
| ----------------- | ------------------------------ |
| `Invoke-TmNew`    | `tm new`                       |
| `Invoke-TmStart`  | `tm start`                     |
| `Invoke-TmStop`   | `tm stop`                      |
| `Invoke-TmDone`   | `tm done`                      |
| `Invoke-TmList`   | `tm list`                      |
| `Invoke-TmLog`    | `tm log`                       |
| `Invoke-TmOpen`   | `tm open`                      |
| `Invoke-TmReport` | `tm report` / `tm report -Csv` |

#### #region DISPATCH

`switch` によるサブコマンド振り分け（`docs/architecture.md §3` のディスパッチ構造に準拠）。

### スクリプト冒頭の必須宣言

```powershell
#Requires -Version 5.1
Set-StrictMode -Version Latest
```

---

## § 4 主要データ構造

### 日次ファイルパス

```
$TM_ROOT\daily\YYYY\MM\YYYY-MM-DD.md
```

詳細フォーマット（フロントマター・タスクセクション・セッション行）は
`docs/functional-design.md §3` を参照。

### タスクセクション例（最小例）

```markdown
## [1] ログイン修正
type: ISS
status: Running
hours: 1.50
running_since: 13:42
formal_id:

[09:00-10:30] (1.50h) 前セッションのメモ
```

### カウンターファイル

パス: `$TM_ROOT\config\counters.json`

v0.1 では `counters.json` の読み書きは行わない。`config/` ディレクトリは
`Invoke-WithCounterLock` 内で必要時に生成されるが、v0.1 ではロック関数自体が
呼ばれないため実質的には作成されない（S2 のロック動作確認テスト実行時を除く）。
フォーマットの詳細は `docs/architecture.md §7` を参照。

### タスク PSObject の主要フィールド

`Read-DailyFile` が返すタスクオブジェクトには少なくとも以下のフィールドを持たせる。

| フィールド     | 型      | 説明                                         |
| -------------- | ------- | -------------------------------------------- |
| `Seq`          | int     | 当日連番（1始まり）                          |
| `Title`        | string  | タスクタイトル                               |
| `Type`         | string  | ISS / INQ / MTG                              |
| `Status`       | string  | Stopped / Running / Done                     |
| `Hours`        | double  | 確定済みセッション工数の合算                 |
| `RunningSince` | string  | Running 状態のみ存在（HH:MM 生時刻）         |
| `FormalId`     | string  | 空文字（v0.1 では未使用）                    |
| `LineNumber`   | int     | ファイル内のヘッダー行番号（`tm open` 向け） |

---

## § 5 主要処理フロー（実装アプローチ）

コマンド仕様の詳細は `docs/functional-design.md §4.x`、状態遷移は `docs/functional-design.md §2` を参照。
以下は実装上の補足のみ記述する。

### tm new

- 検証: タイトル未指定 → `Write-TmError`。`-Type` 不正値（ISS/INQ/MTG 以外）→ `Write-TmError`
- 副作用: 日次ファイルが存在しなければディレクトリごと生成し、フロントマターを書き込む。
  既存タスク数をカウントして連番を決定し、末尾にタスクセクションを追記（status: Stopped, hours: 0.00）
- 失敗: ファイル I/O 失敗 → `Write-TmError`

### tm start

- 検証: 連番未指定 / 存在しない → `Write-TmError`。Done タスクへの start → `Write-TmError`。
  指定タスクがすでに Running → `Write-TmWarn`（自動停止は行わない）
- 副作用: 別タスクが Running なら自動 stop 処理を実行してから対象を Running へ遷移（`running_since` 設定）
- 実装ポイント: stop と start の2段階書き込みを1回の `Write-DailyFile` にまとめて原子的に書き込む

### tm stop

- 検証: Running タスクなし → `Write-TmWarn`
- 副作用: `running_since` → 終了時刻（現在時刻）で工数計算（15分丸め）→ セッション行追記 → `hours` 加算 → `running_since` 削除 → status: Stopped
- 工数計算は `Get-RoundedHours` に委譲する

### tm done

- 引数なしの場合: Running タスクなし → `Write-TmWarn`。Running タスクあり → stop 相当処理後に Done
- 連番指定の場合: 存在しない → `Write-TmError`。Done → `Write-TmWarn`。Running → stop 相当後 Done。Stopped → 直接 Done
- 副作用:
  - Running の場合: stop と同等処理（セッション記録・工数確定・`running_since` 削除）を実行した後、status を Done に更新
  - Stopped の場合: status を Done に更新するのみ（セッション処理なし）

### tm list

- 副作用なし（読み取りのみ）
- 日次ファイルが存在しない → 「本日の記録はありません」+ exit 0
- 出力: 連番・Type・Status・Hours・Title の表形式。Running タスクに `*` マーク。フッターに件数と合計工数

### tm log

- 副作用なし（読み取りのみ）
- 日次ファイルが存在しない → 「本日の記録はありません」+ exit 0
- 出力: ヘッダー・メタ・セッション行・自由メモを時系列で表示

### tm open

- 副作用: VS Code プロセスの起動
- `code` が PATH にない → `Write-TmWarn` + exit 0（エラーにしない）
- 連番指定時は `Get-TaskLineNumber` でヘッダー行番号を取得し `code -g "<path>:<line>"` を呼ぶ

### tm report / tm report -Csv

- 副作用: `-Csv` 時のみ `Set-Clipboard` でクリップボードへ書き込む
- 期間引数なし → 当日のみ。`-Date` と `-Month` 両方指定時は `-Date` 優先（`requirements.md §2` 参照）
- 集計ロジック: 期間内の日次ファイルを列挙 → 各タスクの `hours` を読み込む（Running 未確定分は含めない）→
  タスク一覧・カテゴリ別小計・総合計を算出
- `-Csv` と通常表示は集計ロジックを共通化し、出力フォーマットのみ分岐する（`docs/product-requirements.md §8 FR-09`）

---

## § 6 排他制御方針

### 日次ファイル

v0.1 は単一ユーザー前提のため排他制御なし。
将来のチーム共有対応（v1.0+）に向けた拡張点として記録しておく。

### カウンターファイル

`Invoke-WithCounterLock` でロックファイル（`config/counters.lock`）を使用して排他制御する。
詳細は `docs/architecture.md §7` を参照。v0.1 ではカウンター操作（`counters.json` の読み書き）は
発生しないが、ロック機構そのものは最小単位で動作確認しておく。
`tests/manual/scenario-03-counter-lock.ps1` を追加し、`Invoke-WithCounterLock` を空の
スクリプトブロックで呼び出して以下を確認する:

- 呼び出し前: `config/counters.lock` が存在しない
- 呼び出し中: `config/counters.lock` が生成される
- 呼び出し後: `config/counters.lock` が削除される
- 例外発生時: `finally` 節でロックファイルが確実に削除される

本シナリオは v1.0 での `issue new` 実装時に流用する。

---

## § 7 エラー処理方針

### ヘルパー関数の使い分け

| 関数            | 出力先                                | exit コード | 使用場面                                           |
| --------------- | ------------------------------------- | ----------- | -------------------------------------------------- |
| `Write-TmError` | stderr（`Write-Error`）               | 1           | 引数不正、対象不在、ファイル I/O 失敗              |
| `Write-TmWarn`  | Warning ストリーム（`Write-Warning`） | 0           | 状態的に正常な「該当なし」（Running タスクなし等） |
| `Write-TmInfo`  | stdout（`Write-Host`）                | —           | 通常の操作完了メッセージ                           |

### try/catch パターン

ファイル I/O では必ず `-ErrorAction Stop` を指定する（詳細: `docs/development-guidelines.md §4`）。
v0.1 での exit コードは 0（正常＋警告）と 1（エラー全般）の2種のみ。

### デバッグ出力

`$env:TM_DEBUG` が設定されている場合のみ `Write-Verbose` で詳細を出力する
（詳細: `docs/development-guidelines.md §7`）。`$VerbosePreference` は上書きしない。

---

## § 8 テスト方針

v0.1 は**手動シナリオテスト**のみ。自動テスト（Pester 等）は v0.2 以降で検討。

### テストスクリプト配置

| ファイル                                        | 内容                                                                                                        |
| ----------------------------------------------- | ----------------------------------------------------------------------------------------------------------- |
| `tests/manual/scenario-01-typical-day.ps1`      | 標準的な1日のフロー（new → start → stop → done → list → report）。AC-01・AC-03〜AC-09 をカバー              |
| `tests/manual/scenario-02-interrupt.ps1`        | 割り込み対応フロー（Running 中に別タスクへ切替、自動 Stopped を確認）。AC-02 をカバー                       |
| `tests/manual/scenario-03-counter-lock.ps1`     | カウンターロック機構の単体動作確認（`Invoke-WithCounterLock` のロック生成・解放・例外時クリーンアップ確認）  |

scenario-01 と scenario-02 を合わせて AC-01〜AC-09 をすべて網羅する。

### テストサンドボックス

```powershell
$env:TM_ROOT = Join-Path $env:TEMP 'tm-test'
```

テスト実行前に上記を設定し、本番の `tasks/` データへの影響を完全に遮断する。
受入れ観点は `requirements.md §2（AC-01〜AC-09）` を参照。

---

## § 9 VS Code 連携

- `tm open`（引数なし）: `code <日次ファイルパス>` を実行
- `tm open <連番>`: `Get-TaskLineNumber` でヘッダー行番号を取得し `code -g "<path>:<line>"` を実行
- `code` が PATH に存在しない場合は `Write-TmWarn` で案内して exit 0（利用者に PATH 設定を促す）
- 詳細は `docs/architecture.md §9` を参照

---

## § 10 スコープ外（v0.2 以降に持ち越し）

- `tm issue` / `tm phase` / `tm promote` / `tm rollover`
- 仮ID採番（`INQ-YYYYMMDD-NN`、`MTG-名称`、`ISS-NNN` 昇格）
- `counters.json` の実読み書き（`Read-Counters` / `Write-Counters` 本体）
- 自動繰越・週次サマリ
- `tm --version` の正式実装（`$ScriptVersion` 定数は v0.1 から用意）
- 自動テスト（Pester 等）
- CSV のファイル出力（クリップボードのみ対応が v0.1 の仕様）

---

## § 11 オープンクエスチョン

現時点で未確定事項なし。
