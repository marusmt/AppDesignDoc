# development-guidelines

# 開発ガイドライン（Development Guidelines）

> tm 開発時の実装判断基準を統一するためのコーディング規約・エラーハンドリング・テスト方針を定義します。
リポジトリ構造・関数配置・命名規則の詳細は [repository-structure.md](repository-structure.md) を参照してください。
> 

---

## 1. ドキュメント目的とスコープ

本ファイルは v0.1 実装フェーズにおける実装中の判断基準を統一することを目的とします。

- **対象環境:** PowerShell 5.1 + Windows（外部モジュール禁止）
- **対象範囲:** コーディングスタイル・エラーハンドリング・ファイル I/O・テスト方針・診断出力
- **対象外:** リポジトリ構造・関数配置 → [repository-structure.md](repository-structure.md) を参照

---

## 2. PowerShell 5.1 制約

### バージョン別機能対応表

| 機能 | 5.1 | 7.x | 採用方針 |
| --- | --- | --- | --- |
| `$null ??` 演算子 | ❌ | ✅ | `if-else` で代替 |
| `?:` 三項演算子 | ❌ | ✅ | `if-else` で代替 |
| `Set-Clipboard` | ✅ | ✅ | 採用 |
| `ConvertFrom-Json` | ✅ | ✅ | 採用 |
| クラス定義 | ✅ | ✅ | 採用可（任意） |

### バージョン確認

実行時のバージョンチェックは任意。スクリプト冒頭に `#Requires -Version 5.1` を置くことで、
5.1 未満の環境では PowerShell 自身がエラーを出力して終了します（明示的なチェック不要）。

```powershell
# 任意: 実行時警告を出したい場合
if ($PSVersionTable.PSVersion.Major -lt 5) {
    Write-Warning "tm は PowerShell 5.1 以上を必要とします"
}
```

---

## 3. コーディングスタイル

### 命名

| 対象 | 規則 | 例 |
| --- | --- | --- |
| 公開関数 | PowerShell 動詞-名詞規則（[repository-structure.md §4](repository-structure.md) 遵守） | `Invoke-TmStart`, `Get-TmRoot` |
| ローカル変数 | camelCase | `$startTime`, `$dailyFile` |
| スクリプトスコープ変数 | `$script:` 明示 | `$script:tmRoot` |
| 定数 | PascalCase | `$ScriptVersion = '0.1.0'` |

### 引数定義

- すべての公開関数に `param()` ブロックを置く
- パラメータ名は PascalCase で統一（`Csv`, `Date`, `Month`, `Type`, `Start`, `Stop`, `Session`）
- 必須引数は `[Parameter(Mandatory=$true)]` で明示
- 引数省略時のデフォルト値は `param()` 内で定義

```powershell
function Invoke-TmStart {
    param(
        [Parameter(Mandatory=$true)] [int]$Seq,
        [datetime]$Date = (Get-Date)
    )
    # ...
}
```

### コメント

- 公開関数の先頭にコメントベースヘルプ（`.SYNOPSIS`, `.PARAMETER`, `.EXAMPLE`）
- 複雑な処理にはインラインコメントで意図を補足
- 意図を示すプレフィクスを統一：

| プレフィクス | 用途 |
| --- | --- |
| `# TODO:` | 将来対応が必要な項目 |
| `# FIXME:` | 既知の問題・暫定対応 |
| `# NOTE:` | 読み手が見落としやすい前提・制約 |

### ファイル冒頭

```powershell
#Requires -Version 5.1
# tm.ps1 - Task Manager エントリポイント
# バージョン: 0.1.0
```

---

## 4. エラーハンドリング規約

### 例外処理の基本方針

| 状況 | 処理 |
| --- | --- |
| ユーザー操作に起因するエラー（引数不正・対象不在） | `Write-TmError` → exit 1 |
| 状態的に正常な「該当なし」（Running タスクなし等） | `Write-TmWarn` → exit 0 |
| ファイル I/O 失敗 | `try/catch` で捕捉 → `Write-TmError` → exit 1 |
| 想定外の例外 | `Set-StrictMode -Version Latest` で早期検出 |

詳細な出力先・exit コードは [architecture.md §10](architecture.md) を参照してください。

### Try/Catch パターン

```powershell
try {
    $content = Get-Content -Path $path -Raw -ErrorAction Stop
} catch {
    Write-TmError "日次ファイル読込失敗:$($_.Exception.Message)"
}
```

- `ErrorAction Stop` を指定しないと PowerShell の非終了エラーは `catch` に入らないため、
ファイル I/O では必ず付与してください。

### exit コードの整理

| コード | 意味 |
| --- | --- |
| `0` | 正常終了（警告のみを含む） |
| `1` | ユーザーエラー / システムエラー全般 |

v0.1 では `0` と `1` のみ使用します。細分化は v1.0 以降の検討事項です。

---

## 5. ファイル I/O 規約

### 読み込み

- `Get-Content -Raw` でファイル全体を文字列として取得
- パースは正規表現で行う（外部 YAML パーサー不使用）
- エンコーディングは UTF-8 with BOM（PowerShell 5.1 の `Get-Content` 標準）

### 書き出し

- `Set-Content -Encoding UTF8` を統一使用
- 改行コードは CRLF（`"`r`n"`）
- ファイルが存在しない場合は `New-Item -Force` で親ディレクトリも含めて作成

```powershell
$dir = Split-Path $path
if (-not (Test-Path $dir)) {
    New-Item $dir -ItemType Directory -Force | Out-Null
}
Set-Content -Path $path -Value $content -Encoding UTF8
```

### ロック

- `counters.json` への書き込みは必ず `Invoke-WithCounterLock` 経由で行う（v1.0 で使用開始）
- 日次ファイルは 1 ユーザー想定のため排他制御不要

---

## 6. テスト方針

### v0.1 テスト戦略

自動テストフレームワーク（Pester 等）は v0.1 では導入しません。
代わりに「手動テストスクリプト」を `tests/manual/` 配下に配置し、業務フローを再現して検証します。

| ファイル | 内容 |
| --- | --- |
| `tests/manual/scenario-01-typical-day.ps1` | 標準的な 1 日の作業フロー（new → start → stop → done → list → report） |
| `tests/manual/scenario-02-interrupt.ps1` | 割り込み対応フロー（start 中に別タスクへ切替） |

### テストデータ

- `tests/fixtures/` に検証用の日次ファイルサンプルを配置
- テスト実行前に `$env:TM_ROOT` を一時ディレクトリへ向けてサンドボックス化

```powershell
$env:TM_ROOT = Join-Path $env:TEMP 'tm-test'
```

### v0.2 以降の方針

- ユーザー数が増えた段階で Pester 導入を検討
- CI 環境がない前提（個人開発フェーズ）のため、手動実行可能性を最優先

---

## 7. ログ・診断

### 通常出力

- `Write-TmInfo` は `Write-Output` を使用する。
  - 採用理由: 手動テスト（scenario-*.ps1）で出力をキャプチャ・アサートする要件を優先するため。
  - 前提: `Invoke-Tm*` 関数はパイプラインに値を返さない（Info メッセージのみを出す）。返値が必要な内部関数は `Invoke-Tm*` ではなく動詞ベース関数（`Read-` / `Get-` / `ConvertTo-` 等）に限定する。
- `Write-TmWarn` は `Write-Warning`（Warning ストリーム）。
- `Write-TmError` は `Write-Error` + `exit 1`。
- 出力フォーマットは `[seq] アクション: タイトル (詳細)` に統一

```
[1] 開始: ログイン修正 (09:07)
[2] 停止: 定例朝会 (+0.50h / 計 0.50h)
[3] 完了: ログイン修正 (+1.00h / 計 2.50h)
```

開始時の詳細は `(HH:MM)` のみ（生時刻・丸めなし）。
停止・完了時の詳細は `(+今回工数h / 計 累積工数h)` とする。

### デバッグ出力

- 環境変数 `$env:TM_DEBUG` が設定されている場合のみ `Write-Verbose` で詳細を出力
- `$VerbosePreference` の上書きはしない

```powershell
if ($env:TM_DEBUG) {
    Write-Verbose "Read-DailyFile: path=$path"
}
```

---

## 8. ドキュメント更新ルール

- コード変更時は対応するドキュメントも同タイミングで更新する
- [functional-design.md](functional-design.md) と実装の挙動が乖離した場合は**コードを修正する**（仕様優先）
- 実装中の設計判断の変更は `decisions.md`（ステアリングディレクトリ内）に記録する

---

## 9. バージョン管理

### バージョン文字列

- `$ScriptVersion = '0.1.0'`（`tm.ps1` 冒頭 CONFIG リージョンの定数）
- セマンティックバージョニング準拠

| バージョン | 内容 |
| --- | --- |
| `v0.1.x` | バグ修正 |
| `v0.2.0` | `fix` コマンド追加 |
| `v0.3.0` | `rollover` コマンド追加（未完了タスクの翌稼働日繰越） |
| `v1.0.0` | 課題管理機能（ISS 採番・`tm issue new`・`tm promote` 等） |

### tm –version（将来検討）

`tm --version` で `$ScriptVersion` を表示するサブコマンドを v0.1 に含めるかは任意です。
含める場合は [repository-structure.md §3 DISPATCH](repository-structure.md) の switch 文に追記してください。