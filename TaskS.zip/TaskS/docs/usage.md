﻿# tm 使用方法ガイド

> `tm`（Task Manager）の初期セットアップから日常運用までを説明します。

---

## 1. セットアップ

### 1-1. `tm` エイリアスの登録

#### Windows（PowerShell）

毎回フルパスを指定しなくても `tm <コマンド>` と打てるよう、PowerShell プロファイルに関数を登録します。

```powershell
# プロファイルを開く（VS Code）
code $PROFILE
```

以下の1行を追加して保存：

```powershell
function tm { powershell.exe -NoProfile -File "c:\App\TaskS\tm.ps1" @args }
```

新しいターミナルを開いて `tm list` が動作すれば完了です。

> **⚠️ プロファイル読み込みエラーが出る場合**
>
> ```
> . : このシステムではスクリプトの実行が無効になっているため...
> ```
>
> PowerShell の実行ポリシーが `Restricted` になっています。以下を **一度だけ** 実行してください（管理者権限不要）：
>
> ```powershell
> Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
> ```
>
> `RemoteSigned` はローカルスクリプトを無条件で実行可、インターネットからダウンロードしたスクリプトのみ署名を要求する設定です。PowerShell を再起動すればプロファイルが正常に読み込まれます。

#### macOS（PowerShell Core）

macOS では PowerShell Core（`pwsh`）が必要です。

**① PowerShell Core のインストール（Homebrew）**

```bash
brew install --cask powershell
```

インストール確認：

```bash
pwsh --version
# PowerShell 7.x.x
```

**② `tm` 関数をシェルプロファイルに登録**

```bash
# zsh の場合（macOS デフォルト）
echo 'function tm() { pwsh -NoProfile -File "$HOME/App/Tasklist/tm.ps1" "$@" }' >> ~/.zshrc
source ~/.zshrc
```

bash を使っている場合は `~/.bash_profile` に追加してください：

```bash
echo 'function tm() { pwsh -NoProfile -File "$HOME/App/Tasklist/tm.ps1" "$@" }' >> ~/.bash_profile
source ~/.bash_profile
```

新しいターミナルを開いて `tm list` が動作すれば完了です。

---

### 1-2. データ保存先（TM_ROOT）

#### Windows

デフォルトでは `tm.ps1` と同じディレクトリ配下の `tasks\` にデータが保存されます。

```
c:\App\TaskS\tasks\daily\YYYY\MM\YYYY-MM-DD.md
```

別のフォルダに保存したい場合は、プロファイルに環境変数を追加してください：

```powershell
$env:TM_ROOT = "C:\Users\marus\tasks"
```

#### macOS

デフォルトでは `tm.ps1` と同じディレクトリ配下の `tasks/` にデータが保存されます。

```
~/App/Tasklist/tasks/daily/YYYY/MM/YYYY-MM-DD.md
```

別のフォルダに保存したい場合は、シェルプロファイルに環境変数を追加してください：

```bash
# ~/.zshrc に追加
export TM_ROOT="$HOME/tasks"
```

> **注意:** `TM_ROOT` にはスペースを含まないパスを推奨します。

---

## 2. コマンドリファレンス

| コマンド                                                                         | 説明                                                                   |
| -------------------------------------------------------------------------------- | ---------------------------------------------------------------------- |
| `tm new "タイトル" [-Type ISS\|INQ\|MTG]`                                        | タスクを作成する（INQ は `INQ-YYYYMMDD-NN` を自動採番）【v1.0 拡張】 |
| `tm start <連番>`                                                              | 作業を開始する（別タスク実行中なら自動停止）                           |
| `tm start ISS-NNN/PHASE-MM`                                                    | 課題工程タスクを開始する（なければ自動作成）【v1.0】                   |
| `tm stop`                                                                      | 実行中タスクを一時停止する                                             |
| `tm done [<連番>]`                                                             | タスクを完了する（引数なし = 実行中タスクを完了）                      |
| `tm list`                                                                      | 今日のタスク一覧を表示する                                             |
| `tm log`                                                                       | セッション詳細ログを表示する                                           |
| `tm open [<連番>]`                                                             | 日次ファイルを VS Code で開く                                          |
| `tm fix <連番> [-Session <N>] [-Start HH:MM] [-Stop HH:MM] [-Date YYYY-MM-DD]` | セッションの時刻・工数を事後修正する【v0.2】                           |
| `tm rollover`                                                                  | 直近の稼働日の Stopped タスクを当日へ全件繰り越す【v0.3】              |
| `tm issue new "タイトル"`                                                      | 課題（ISS-NNN）を作成しフォルダ・issue.md を生成する【v1.0】           |
| `tm report [-Date YYYY-MM-DD \| -Month YYYY-MM]`                                | 工数集計を表示する                                                     |
| `tm report -Csv [-Date YYYY-MM-DD \| -Month YYYY-MM]`                           | 工数をクリップボードへコピーする                                       |

### タスク種別（-Type）

| 種別                  | 用途           | 採番                                   |
| --------------------- | -------------- | -------------------------------------- |
| `ISS`（デフォルト） | 課題・保守作業 | なし                                   |
| `INQ`               | 問い合わせ対応 | `INQ-YYYYMMDD-NN` を自動付与【v1.0】 |
| `MTG`               | 会議           | なし                                   |

---

## 3. 典型的な1日の流れ

```powershell
# 朝：前日の未完タスクを当日へ繰り越す
tm rollover
# → 直近の稼働日: 2026-05-04
# → [1] ログイン修正対応  ISS
# → 1 件のタスクを繰り越しました

# 新規タスクを追加登録
tm new "定例朝会" -Type MTG
tm new "Aさんからの問い合わせ" -Type INQ

# [1] の作業を開始（rollover で繰り越したタスクをそのまま start できる）
tm start 1

# 会議が割り込んだら [2] を start（[1] は自動停止）
tm start 2

# 会議が終わったら完了
tm done

# [1] に戻る
tm start 1

# 今日の状況を確認
tm list

# 終業前：工数集計
tm report

# Excel転記用にクリップボードへコピー
tm report -Csv
```

---

## tm rollover（未完タスクの翌日繰越）【v0.3】

前日（または直近の稼働日）の Stopped タスクを当日の日次ファイルへ全件繰り越します。

```powershell
tm rollover
```

パラメータなし。実行するだけで以下が自動処理されます：

1. 直近の稼働日（日次ファイルが存在する最も近い過去日）を特定
2. その日の Stopped タスクを当日ファイルへコピー
3. 各タスクの `hours = 0.00` にリセット（二重計上防止）
4. `rolled_from: YYYY-MM-DD` フィールドを付与

```powershell
# 実行例
tm rollover
# 直近の稼働日: 2026-05-04
# [1] ログイン修正対応  ISS
# [2] 設計レビュー対応  ISS
# 2 件のタスクを繰り越しました

# そのまま start できる
tm start 1
```

**振る舞いのポイント:**

- 2回実行しても安全（二重繰越防止チェックあり）: 「本日は既に繰越実行済みです。」
- 連休明けでも土日をスキップして最直近の稼働日から繰り越す
- 繰越元ファイルは一切変更しない（履歴は原本のまま保持）
- Running タスクは警告なしでスキップ（stop し忘れても安全）
- `tm report` の工数集計に二重計上は発生しない

**警告ケース（exit 0）:**

| 状況                       | メッセージ                                                           |
| -------------------------- | -------------------------------------------------------------------- |
| 2回目の実行                | `tm: 本日は既に繰越実行済みです。`                                 |
| 過去90日以内にファイルなし | `tm: 直近の稼働日が見つかりません（過去90日以内にファイルなし）。` |
| Stopped タスクが0件        | `繰越対象なし（直近の稼働日: YYYY-MM-DD）`                         |

---

## tm issue new（課題の作成）【v1.0】

ISS-NNN を自動採番し、課題フォルダと issue.md を生成します。

```powershell
tm issue new "タイトル"
```

```powershell
# 実行例
tm issue new "ログイン障害の調査"
# 作成しました: ISS-001 — ログイン障害の調査

tm issue new "CSVエクスポートが遅い"
# 作成しました: ISS-002 — CSVエクスポートが遅い
```

生成されるファイル構成：

```
tasks/
└── issues/
    └── ISS-001/
        └── issue.md   ← フロントマター + 概要・工程テンプレート
```

`issue.md` の初期内容：

```markdown
---
id: ISS-001
title: ログイン障害の調査
status: Open
created: 2026-05-07
---

## 概要

## 工程

| Phase | 内容 | 担当 | 状態 |
|-------|------|------|------|
| PHASE-01 | 分析 | - | - |
```

---

## tm start ISS-NNN/PHASE-MM（課題工程の作業開始）【v1.0】

`ISS-NNN/PHASE-MM` 形式の識別子を `tm start` に渡すと、当日の日次ファイルに同名タスクが自動作成されて作業が開始されます。

```powershell
tm start ISS-001/PHASE-01
```

```powershell
# 当日タスクに ISS-001/PHASE-01 がない場合 → 自動作成して開始
tm start ISS-001/PHASE-01
# [3] ISS を作成しました: ISS-001/PHASE-01
# [3] 開始: ISS-001/PHASE-01 (09:15)

# 同じタスクを再度 start → 既存タスクをそのまま開始（重複しない）
tm stop
tm start ISS-001/PHASE-01
# [3] 開始: ISS-001/PHASE-01 (10:00)
```

識別子の形式：

| 形式                 | 例                            | 動作                       |
| -------------------- | ----------------------------- | -------------------------- |
| 整数                 | `tm start 3`                | 従来通り当日連番で開始     |
| `ISS-NNN/PHASE-MM` | `tm start ISS-001/PHASE-02` | 課題工程タスクを作成＋開始 |
| それ以外             | `tm start abc`              | エラー（exit 1）           |

---

## tm new -Type INQ（問い合わせの自動採番）【v1.0】

`-Type INQ` でタスクを作成すると、タイトル先頭に `INQ-YYYYMMDD-NN` が自動付与されます。

```powershell
tm new "Aさんからの問い合わせ" -Type INQ
# [2] INQ を作成しました: INQ-20260507-01 Aさんからの問い合わせ

tm new "Bさんからの問い合わせ" -Type INQ
# [3] INQ を作成しました: INQ-20260507-02 Bさんからの問い合わせ
```

同日に採番した INQ は `tasks/config/counters.json` で管理されます。

---

## tm fix（作業記録の事後修正）【v0.2】

切り替え忘れや入力ミスなどでセッション時刻がずれた場合に事後修正できます。

```powershell
tm fix <連番> [-Session <N>] [-Start HH:MM] [-Stop HH:MM] [-Date YYYY-MM-DD]
```

| パラメータ           | 必須 | 説明                                                |
| -------------------- | ---- | --------------------------------------------------- |
| `<連番>`           | ✅   | 修正対象タスクの連番                                |
| `-Session <N>`     |      | セッション番号（1始まり）。省略時は最終セッション   |
| `-Start HH:MM`     | △   | 新しい開始時刻（`-Stop` と少なくとも一方が必須）  |
| `-Stop HH:MM`      | △   | 新しい終了時刻（`-Start` と少なくとも一方が必須） |
| `-Date YYYY-MM-DD` |      | 対象日付。省略時は当日                              |

```powershell
# ケース1: stop 後に終了時刻を修正（14:30 に止めたが実際は 14:00 に終わっていた）
tm fix 1 -Stop 14:00
# [1] 修正: ログイン修正対応 (S2: 13:30-14:30 → 13:30-14:00 / 計 1.75h)

# ケース2: 開始時刻のみ修正（09:30 に start したが実際は 09:00 から作業していた）
tm fix 1 -Start 09:00
# [1] 修正: ログイン修正対応 (S1: 09:30-10:00 → 09:00-10:00 / 計 1.00h)

# ケース3: -Session N で特定のセッションを修正（最後以外のセッション）
tm fix 1 -Session 2 -Start 13:00 -Stop 14:30
# [1] 修正: ログイン修正対応 (S2: 13:00-15:00 → 13:00-14:30 / 計 3.00h)

# ケース4: 過去日（2026-05-03）のセッションを修正
tm fix 1 -Session 1 -Start 09:00 -Stop 10:30 -Date 2026-05-03
# [1] 修正: ログイン修正対応 (S1: 09:00-10:00 → 09:00-10:30 / 計 2.50h)

# ケース5: Running 中タスクの開始時刻を修正（running_since のみ更新）
tm fix 2 -Start 10:00
# [2] 修正: Aさんからの問い合わせ (Running: 10:07 → 10:00)
```

**振る舞いのポイント:**

- `status` は変更されない（Stopped は Stopped、Running は Running のまま）
- 時刻は15分単位に丸めてから記録・表示される（入力値は生時刻でよい）
- 工数（hours）は全セッションを独立に再計算した合算値へ更新される
- Running タスクに `-Session` 省略で `-Start` のみ指定した場合は `running_since` だけを更新する（`hours`・セッション行は変更しない）
- Done タスクは修正不可

```powershell
# エラー例
tm fix 3 -Stop 15:00          # Done タスクを指定
# tm: [3] は完了（Done）済みのため修正できません。

tm fix 1 -Session 2           # -Start/-Stop 両方省略
# tm: -Start または -Stop を少なくとも一方指定してください。

tm fix 1 -Start 11:00 -Stop 10:00   # 修正後に開始 ≧ 終了
# tm: 修正後の開始時刻が終了時刻以降になっています: 11:00 >= 10:00
```

エラーケース一覧は [functional-design-v02.md §2.8](functional-design-v02.md) を参照してください。

---

## 4. タスク状態とルール

```
[*] ──tm new──> Stopped
Stopped ──tm start <連番>──> Running
Running ──tm stop──> Stopped
Running ──tm start <別連番>──> Stopped（自動）→ 新タスク Running
Running ──tm done──> Done
Stopped ──tm done <連番>──> Done
```

| 状態        | 説明                    |
| ----------- | ----------------------- |
| `Stopped` | 作成済み・一時停止中    |
| `Running` | 計測中（同時に1件のみ） |
| `Done`    | 完了（以後操作不可）    |

---

## 5. エラー・警告の見方

| メッセージ例       | 意味                 | 対処             |
| ------------------ | -------------------- | ---------------- |
| `WARNING: ...`   | 問題なし（exit 0）   | 操作は不要       |
| `tm: ...` (赤字) | 操作エラー（exit 1） | 連番・引数を確認 |

**警告になるケース（exit 0）:**

- `tm stop` / `tm done`（引数なし）で実行中タスクがない
- `tm done <連番>` で対象が既に Done

**エラーになるケース（exit 1）:**

- `tm start` で連番を指定しない
- `tm start 999` など存在しない連番を指定
- `tm new` でタイトルを省略
- `tm new -Type INVALID` など不正な種別を指定

---

## 6. データファイルの場所と直接編集

記録は Markdown ファイルで保存されるため、必要に応じて直接編集できます。

```powershell
# 今日の日次ファイルを VS Code で開く
tm open

# 特定タスクの行へジャンプ
tm open 2
```

ファイルパス: `$TM_ROOT\daily\YYYY\MM\YYYY-MM-DD.md`

---

## 7. 関連ドキュメント

| 目的                                             | ファイル                                            |
| ------------------------------------------------ | --------------------------------------------------- |
| コマンド詳細仕様・状態遷移・ファイルフォーマット | [functional-design.md](functional-design.md)           |
| ファイルレイアウト・15分丸め仕様・技術仕様       | [architecture.md](architecture.md)                     |
| コーディング規約・エラーハンドリング方針         | [development-guidelines.md](development-guidelines.md) |
| 用語定義（ISS / INQ / MTG / Running 等）         | [glossary.md](glossary.md)                             |
