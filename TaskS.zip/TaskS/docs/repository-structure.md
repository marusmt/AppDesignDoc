# repository-structure

# リポジトリ構造定義書（Repository Structure）

> v0.1 実装フェーズ向けのリポジトリ構成・関数配置ルールを定義します。
詳細なコーディング規約・テスト方針は [development-guidelines.md](development-guidelines.md) を参照してください。
> 

---

## 1. ドキュメント目的とスコープ

本ファイルは v0.1 実装着手時点のリポジトリ構成を定義します。対象は以下のとおりです。

- トップレベルのファイル・フォルダ構成と各ディレクトリの役割
- `tm.ps1` 内部のリージョン構成と関数配置
- 関数命名規則
- ステアリングディレクトリの命名規則と内部構成
- v1.0 でのファイル分割方針（将来）

コーディング規約・Markdown フォーマット規約・テスト方針は [development-guidelines.md](development-guidelines.md) に分離します。

---

## 2. リポジトリトップ構成

`C:\APP\TaskS\` 直下の構成：

| パス | 役割 |
| --- | --- |
| `tm.ps1` | エントリポイント（v0.1 は単一スクリプト） |
| `docs/` | 仕様書・設計書 |
| `docs/product-requirements.md` | プロダクト要求定義書（PRD） |
| `docs/architecture.md` | 技術仕様書 |
| `docs/glossary.md` | ユビキタス言語定義 |
| `docs/functional-design.md` | 機能設計書 v0.1 |
| `docs/functional-design-v02.md` | v0.2 機能設計 |
| `docs/functional-design-v03.md` | v0.3 機能設計（rollover コマンド） |
| `docs/functional-design-v10.md` | v1.0 機能設計 |
| `docs/repository-structure.md` | 本ファイル |
| `docs/development-guidelines.md` | 実装規約 |
| `docs/ideas/` | アイデアメモ置き場（自由形式） |
| `.steering/` | ステアリングファイル群（タスクごと） |
| `tasks/` | `$TM_ROOT` 既定値（実データ。.gitignore 対象） |
| `tests/` | 手動テストスクリプトとフィクスチャ |
| `tests/manual/` | 業務フロー再現スクリプト（scenario-01〜06） |
| `tests/fixtures/` | 検証用日次ファイルサンプル |
| `CLAUDE.md` | Claude Code 用プロジェクト指示 |

---

## 3. tm.ps1 のリージョン構成

`tm.ps1` は `#region` ディレクティブで6つの論理ブロックに分割します（[architecture.md §2](architecture.md) を踏襲）。
ファイル内のリージョンは CONFIG → UTIL → DAILY → COUNTER → COMMANDS → DISPATCH の順で配置する。

### #region CONFIG

スクリプト全体の定数。

- バージョン番号
- デフォルト Type 値など

### #region UTIL

汎用ユーティリティ関数。

| 関数 | 説明 |
| --- | --- |
| `Get-TmRoot` | `$TM_ROOT` の解決（環境変数 → フォールバック） |
| `Get-DailyFilePath` | 指定日の日次ファイルパスを返す |
| `ConvertTo-RoundedMinutes` | 分単位の時刻を15分丸めする |
| `Get-RoundedHours` | 丸め後の工数（時間）を返す |
| `Write-TmError` | エラー出力 → exit 1 |
| `Write-TmWarn` | 警告出力 → exit 0 |
| `Write-TmInfo` | 通常情報出力 |

### #region DAILY

日次ファイルの読み書き・タスク操作。

| 関数 | 説明 |
| --- | --- |
| `Read-DailyFile` | 日次ファイルをパースしてタスク一覧を返す |
| `Write-DailyFile` | タスク一覧を日次ファイルへ書き出す |
| `Get-TaskBySeq` | 連番でタスクを取得する |
| `Get-RunningTask` | Running 状態のタスクを返す |
| `Get-TaskLineNumber` | 指定タスクのファイル内行番号を返す |
| `Add-SessionLine` | タスクのメモ部にセッション行を追記する |
| `Update-TaskMeta` | フロントマターフィールドを更新する |
| `Find-LatestWorkingDayPath` | 当日の前日から最大90日遡り、日次ファイルが存在する最初のパスを返す 【v0.3】 |
| `Test-RolloverAlreadyDone` | 当日ファイルに rolled_from 付きタスクが1件以上あれば $true を返す 【v0.3】 |
| `Get-StoppedTasks` | タスク配列から Stopped タスクのみを抽出して返す 【v0.3】 |
| `New-RolledTask` | 繰越元タスクから当日用の繰越タスクオブジェクトを生成する 【v0.3】 |

### #region COUNTER

採番カウンター管理。

| 関数 | 説明 |
| --- | --- |
| `Invoke-WithCounterLock` | カウンターファイルをロックしてブロックを実行する（v0.1 から完全実装） |
| `Read-Counters` | `counters.json` を読み込む（v0.1 では関数定義のみ、本体は v1.0 で実装） |
| `Write-Counters` | `counters.json` を書き出す（v0.1 では関数定義のみ、本体は v1.0 で実装） |

### #region COMMANDS

コマンド実装関数。

| 関数 | 対応コマンド |
| --- | --- |
| `Invoke-TmNew` | `tm new` |
| `Invoke-TmStart` | `tm start` |
| `Invoke-TmStop` | `tm stop` |
| `Invoke-TmDone` | `tm done` |
| `Invoke-TmList` | `tm list` |
| `Invoke-TmLog` | `tm log` |
| `Invoke-TmOpen` | `tm open` |
| `Invoke-TmReport` | `tm report` |
| `Invoke-TmFix` | `tm fix` 【v0.2】 |
| `Invoke-TmRollover` | `tm rollover` 【v0.3】 |

### #region DISPATCH

エントリポイント。`switch` によるサブコマンド振り分け（[architecture.md §3](architecture.md) 参照）。

---

## 4. 関数命名規則

### 公開関数（PowerShell 動詞-名詞規則）

| プレフィクス | 用途 | 例 |
| --- | --- | --- |
| `Invoke-Tm*` | コマンド実装関数 | `Invoke-TmNew`, `Invoke-TmStart` |
| `Get-Tm*` / `Get-*` | 取得系 | `Get-TmRoot`, `Get-DailyFilePath`, `Get-RunningTask` |
| `Read-*` / `Write-*` | ファイル I/O | `Read-DailyFile`, `Write-DailyFile` |
| `Add-*` / `Update-*` / `Remove-*` | 状態変更 | `Add-SessionLine`, `Update-TaskMeta` |
| `Test-*` | 真偽判定 | `Test-IsBusinessDay` |
| `ConvertTo-*` | 変換 | `ConvertTo-RoundedMinutes` |

### 出力ヘルパー（Tm プレフィクス必須）

| 関数 | 出力先 | 用途 |
| --- | --- | --- |
| `Write-TmError` | コンソール赤文字（`Write-Host`） | エラー → exit 1 |
| `Write-TmWarn` | Warning ストリーム | 警告 → exit 0 |
| `Write-TmInfo` | コンソール（`Write-Output`） | 通常情報 |

### プライベート関数

- アンダースコア接頭辞は採用しない（PowerShell 慣習にない）
- 公開しない内部関数も `Get-*` / `Set-*` 等の標準動詞を使用し、関数冒頭のコメントで内部用途を明記する

---

## 5. ステアリングディレクトリ命名規則

### 形式

```
.steering/YYYYMMDD-vXX-task-name/
```

### 例

| ディレクトリ | 対象作業 |
| --- | --- |
| `.steering/20260428-v01-foundation/` | v0.1 基盤実装 |
| `.steering/20260505-v01-report-csv/` | v0.1 report 機能 |
| `.steering/20260512-v02-fix-command/` | v0.2 fix コマンド |

### 各ディレクトリの構成

| ファイル | 内容 |
| --- | --- |
| `tasks.md` | 実装タスク一覧と進捗状況 |
| `decisions.md` | 実装中の判断記録（設計上の決定理由） |
| （必要に応じてサブドキュメント） | 仕様詳細・影響範囲メモなど |

---

## 6. v1.0 でのファイル分割方針（将来）

[architecture.md §2](architecture.md) のドットソーシング構成へ段階的に移行します。

### v0.1 単一ファイルから lib/ 分割への移行手順

1. v1.0 着手時に `lib/` ディレクトリを新設
2. リージョン単位で別ファイル化：
    - `lib/util.ps1`（UTIL リージョン）
    - `lib/daily.ps1`（DAILY リージョン）
    - `lib/counter.ps1`（COUNTER リージョン）
    - `lib/issue.ps1`（v1.0 新設、課題管理）
    - `lib/commands/<command>.ps1`（コマンドごとに分割）
3. `tm.ps1` はディスパッチ層のみ残し、各ファイルをドットソースで読み込む
4. **公開関数の名前・引数・戻り値は変更禁止**（破壊的変更は行わない）

---

## 7. .gitignore 方針（参考）

> 本プロジェクトは現在 Git を使用しませんが、将来 Git 管理へ移行する場合の参考として記載します。
> 

| 対象 | 方針 | 理由 |
| --- | --- | --- |
| `tasks/` | 除外する | 実作業データ（個人記録）はリポジトリに含めない |
| `.steering/` | 追跡する（推奨） | 作業履歴・設計判断の記録として保持する |
| `docs/ideas/` | 追跡する | ブレインストーミング成果物として保持する |
| `*.lock` | 除外する | カウンターロックファイルは一時ファイル |