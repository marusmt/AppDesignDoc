# architecture

# 技術仕様書（Architecture）

> tm の実装における技術判断・データフォーマット・アルゴリズムを定義します。
**日次ファイルフォーマットとタスク行フォーマットは破壊的変更禁止**。v1.0 追加機能はフィールド追加で吸収します。
> 

---

## 1. テクノロジースタック

| 区分 | 採用技術 | 備考 |
| --- | --- | --- |
| 実行環境 | PowerShell 5.1（Windows標準） | 外部モジュール禁止。`$PSVersionTable.PSVersion` で確認 |
| エントリポイント | `tm.ps1`（単一スクリプト） | v0.1はすべてこのファイルに集約 |
| データ形式 | Markdown（`.md`）＋ JSON | タスクデータは Markdown、採番カウンターは JSON |
| エディタ連携 | VS Code（`code` コマンド） | `code -g <file>:<line>` でタスク行へジャンプ |
| クリップボード | `Set-Clipboard`（PowerShell 5.1標準） | 外部ツール不要 |

---

## 2. スクリプト構成

### v0.1: 単一ファイル構成

```
tm.ps1          ← エントリポイント＋全コマンド実装
```

v0.1 では `tm.ps1` 1ファイルにすべての関数を配置します。
ファイル内は以下のリージョンで構造化し、v1.0 でのファイル分割（ドットソーシング）を見越します。

```
#region CONFIG      ← パス定数・設定値
#region UTIL        ← 共通ユーティリティ（15分丸め、日付操作、ファイルパス生成）
#region DAILY       ← 日次ファイルの読み書き
#region COUNTER     ← 採番カウンター管理（v1.0 で使用開始、v0.1 では関数のみ用意）
#region COMMANDS    ← サブコマンド実装（new / start / stop / done / log / list / open / report）
#region DISPATCH    ← コマンドディスパッチ（エントリポイント）
```

### v1.0: ドットソーシング構成（将来）

```
tm.ps1
lib/
  util.ps1
  daily.ps1
  issue.ps1
  counter.ps1
  commands/
    new.ps1  start.ps1  stop.ps1  done.ps1
    fix.ps1  log.ps1  list.ps1  open.ps1
    report.ps1  promote.ps1  rollover.ps1
```

ドットソーシング例: `. "$PSScriptRoot\lib\util.ps1"`

---

## 3. コマンドディスパッチ

`tm.ps1` は第1引数をサブコマンドとして受け取り、対応する関数へ委譲します。

```powershell
param(
    [Parameter(Position=0)] [string]$Command,
    [Parameter(ValueFromRemainingArguments)] [string[]]$Rest
)

switch ($Command) {
    'new'    { Invoke-TmNew    @Rest }
    'start'  { Invoke-TmStart  @Rest }
    'stop'   { Invoke-TmStop   @Rest }
    'done'   { Invoke-TmDone   @Rest }
    'log'    { Invoke-TmLog    @Rest }
    'list'   { Invoke-TmList   @Rest }
    'open'   { Invoke-TmOpen   @Rest }
    'report' { Invoke-TmReport @Rest }
    'fix'    { Invoke-TmFix    @Rest }       # v0.2
    'issue'  { Invoke-TmIssue  @Rest }       # v1.0
    'promote'{ Invoke-TmPromote @Rest }      # v1.0
    default  { Write-Error "Unknown command:$Command"; exit 1 }
}
```

PowerShell のパラメータ解析（`-Title`, `-Type`, `-Date` 等）は各コマンド関数内の `param()` ブロックで行います。

---

## 4. ファイルレイアウト

```
$TM_ROOT/                          ← Get-TmRoot で解決されるデータルート
  daily/
    YYYY/
      MM/
        YYYY-MM-DD.md              ← 日次ファイル
  issues/
    ISS-NNN/
      issue.md                     ← 課題ファイル（v1.0）
  config/
    counters.json                  ← ISS採番カウンター（v1.0で使用開始）
    counters.lock                  ← 排他制御用ロックファイル（一時的）

tm.ps1                             ← TM_ROOT とは独立（スクリプト本体）
```

`config/` を含む**すべてのデータは `TM_ROOT` 配下に集約**されます。
チーム共有時は `$env:TM_ROOT` を共有フォルダに向けるだけで、
`counters.json` が自動的に共有され、ISS採番の重複・衝突を防ぎます。

### データルート決定ロジック

データの保存先は環境変数 `$env:TM_ROOT` で上書き可能です。
未設定の場合は `tm.ps1` と同じディレクトリ配下の `tasks\` を使用します。
これにより、個人ローカル運用→共有フォルダ運用への切替が環境変数1つで完結します。

```powershell
function Get-TmRoot {
    if ($env:TM_ROOT) { return $env:TM_ROOT }
    return Join-Path $PSScriptRoot 'tasks'
}
```

### パス生成関数

```powershell
function Get-DailyFilePath([datetime]$Date = (Get-Date)) {
    $yyyy = $Date.ToString('yyyy')
    $mm   = $Date.ToString('MM')
    $file = $Date.ToString('yyyy-MM-dd')
    return Join-Path (Get-TmRoot) "daily\$yyyy\$mm\$file.md"
}
```

---

## 5. 日次ファイルフォーマット（破壊的変更禁止）

日次ファイルはYAMLフロントマター＋タスクセクションで構成されます。

### 5.1 全体構造

```
---
date: YYYY-MM-DD
---

[タスクセクション × N]
```

`total_hours` はフロントマターに持たず、`tm report` 実行時に全セッション行から動的に集計します（派生値の二重管理を避けるため）。

### 5.2 タスクセクション形式

タスクは `stop → start 再開` を繰り返すため、開始・終了時刻はセッション単位でメモ部に追記します。
メタ行には集計済み工数（`hours`）のみを保持します。

```markdown
## [seq] タイトル
type:      ISS
status:    Stopped
hours:     2.50
formal_id:

[09:00-10:30] (1.50h) セッション判定ロジックを修正
[11:00-12:00] (1.00h) ユニットテスト追加

---
```

| フィールド | 型 | 説明 | v0.1 | v1.0 |
| --- | --- | --- | --- | --- |
| `seq` | 整数 | 当日連番（1始まり）。ヘッダー行 `## [N]` から取得 | ✅ | ✅ |
| `type` | ISS / INQ / MTG | カテゴリラベル | ✅ | ✅ |
| `status` | Stopped / Running / Done | タスク状態 | ✅ | ✅ |
| `hours` | 小数（0.25刻み） | 全セッション工数の合算値 | ✅ | ✅ |
| `running_since` | HH:MM（生時刻・丸めなし） | 現セッション開始時刻。Running 状態のみ存在し、stop/done で削除される | ✅ | ✅ |
| `formal_id` | 文字列または空 | 正式ID（ISS-NNN等）v1.0で昇格後に記入 | 空 | ✅ |
| `rolled_from` | YYYY-MM-DD または不在 | 繰越元の日付。`tm rollover` でコピーされたタスクのみ存在する。二重繰越チェックのフラグを兼ねる | — | v0.3 |
| セッション行 | `[HH:MM-HH:MM] (X.XXh) コメント` | メモ部に追記。`start` / `stop` ごとに1行追加 | ✅ | ✅ |

### 5.3 パース方針

PowerShell でのタスクセクション読み込み：

```powershell
# ヘッダー行
# ^## \[(\d+)\] (.+)$              → $Matches[1]=seq, $Matches[2]=title

# メタデータ行（ASCII小文字とアンダースコアのみ。日本語メモ行を誤検出しないよう限定）
# ^([a-z_]+):\s*(.*)$              → $Matches[1]=key, $Matches[2]=value

# セッション行（メモ部に記録）
# ^\[(\d{2}:\d{2})-(\d{2}:\d{2})\]\s*\(([\d.]+)h\)(.*)$
#   → $Matches[1]=start, $Matches[2]=stop, $Matches[3]=hours, $Matches[4]=comment
```

フロントマター（`---` 囲み）はキー行の正規表現で読み込みます。
外部YAMLパーサーは使用しません。

**セクション境界:** タスクセクションの開始は `## [N]` ヘッダー行のみで判定します。
末尾の `---` は人間が読む際の視覚区切りであり、パーサーはこれに依存しません。

### 5.4 v0.3 / v1.0 での拡張方針

**v0.3 追加フィールド:** `rolled_from: YYYY-MM-DD`。`formal_id:` の直後に配置する。繰越タスクのみ存在し、存在しない場合はパーサーが `RolledFrom = ''` として扱う（後方互換）。

v1.0 で追加されるフィールド（例: `phase_id`）は新規フィールドとして末尾に追加します。
v0.1 形式のファイルは `formal_id` が空のまま有効なファイルとして扱われます。

---

## 6. 15分丸めアルゴリズム

### 仕様

| 対象 | 丸め方向 | 例 |
| --- | --- | --- |
| 開始時刻 | 直前の15分境界へ**切り捨て** | 09:07 → 09:00 |
| 終了時刻 | 直後の15分境界へ**切り上げ** | 10:23 → 10:30 |
| 境界ピッタリ | そのまま | 10:30 → 10:30 |

工数 = (丸め後終了 − 丸め後開始) ÷ 60 [時間]

### 実装

```powershell
function ConvertTo-RoundedMinutes([int]$TotalMinutes, [string]$Direction) {
    if ($Direction -eq 'Floor') {
        return [Math]::Floor($TotalMinutes / 15) * 15
    } else {
        return [Math]::Ceiling($TotalMinutes / 15) * 15
    }
}

function Get-RoundedHours([string]$StartHHMM, [string]$StopHHMM) {
    $s = [datetime]::ParseExact($StartHHMM, 'HH:mm', $null)
    $e = [datetime]::ParseExact($StopHHMM,  'HH:mm', $null)
    $sMin = ConvertTo-RoundedMinutes ($s.Hour * 60 + $s.Minute) 'Floor'
    $eMin = ConvertTo-RoundedMinutes ($e.Hour * 60 + $e.Minute) 'Ceil'
    return [Math]::Round(($eMin - $sMin) / 60, 2)
}
```

**最小工数:** 開始・終了が同分でも丸め後は最低 0.25h（15分）になります。

**複数セッション時:** セッションごとに独立して丸めを適用し、工数を合算します。
セッションをまたいだ一括丸めは行いません。

```
セッション1: 09:07-10:23 → 09:00-10:30 = 1.50h
セッション2: 11:02-11:48 → 11:00-12:00 = 1.00h
合算: 1.50 + 1.00 = 2.50h  (hours フィールドに書き込む値)
```

---

## 7. カウンターと排他制御

### counters.json 形式

```json
{
  "iss": 5,
  "inq": {
    "20260428": 2,
    "20260505": 1
  }
}
```

### ロック機構（ファイルロック方式）

PowerShell 5.1 にはネイティブなファイルロックAPIがないため、
ロックファイル（`config/counters.lock`）の存在有無で排他制御します。

```powershell
function Invoke-WithCounterLock([scriptblock]$Action) {
    $configDir = Join-Path (Get-TmRoot) 'config'
    if (-not (Test-Path $configDir)) {
        New-Item $configDir -ItemType Directory -Force | Out-Null
    }
    $lock    = Join-Path $configDir 'counters.lock'
    $timeout = 5000   # ms
    $elapsed = 0
    while (Test-Path $lock) {
        Start-Sleep -Milliseconds 100
        $elapsed += 100
        if ($elapsed -ge $timeout) {
            Write-Error 'Counter lock timeout.'; exit 1
        }
    }
    New-Item $lock -ItemType File -Force | Out-Null
    try   { & $Action }
    finally { Remove-Item $lock -Force -ErrorAction SilentlyContinue }
}
```

v0.1 では `counters.json` は使用しませんが、ファイルとロック関数は初期から用意し、
v1.0 での `issue new` 実装時にそのまま利用します。

---

## 8. クリップボード出力（report -Csv）

`Set-Clipboard` は PowerShell 5.1 で標準利用可能です。

```powershell
function Export-ReportToClipboard([object[]]$Rows) {
    $header = "日付`tID`tタイトル`t工数`tカテゴリ"
    $lines  = $Rows | ForEach-Object {
        "$($_.Date)`t$($_.Id)`t$($_.Title)`t$($_.Hours)`t$($_.Type)"
    }
    $text = ($header, ($lines -join "`r`n")) -join "`r`n"
    Set-Clipboard -Value $text
    Write-Host "クリップボードにコピーしました（$($Rows.Count) 件）"
}
```

出力はタブ区切り（TSV）。Excelに貼り付けた際に列が分割されます。
ファイル保存は v0.5 以降の検討事項（FR-07）。

---

## 9. VS Code 連携（open コマンド）

```powershell
function Invoke-TmOpen([string[]]$Args) {
    $path = Get-DailyFilePath
    if (-not $Args -or $Args.Count -eq 0) {
        # 引数なし: 日次ファイルを開く
        & code $path
    } else {
        $seq  = [int]$Args[0]
        $line = Get-TaskLineNumber $path $seq   # タスクヘッダー行番号を取得
        & code -g "${path}:${line}"
    }
}
```

**前提条件:** `code` コマンドが PATH に存在すること。
VS Code の標準インストール後、コマンドパレット「Shell Command: Install ‘code’ command in PATH」を実行することで設定されます。
`code` が見つからない場合は警告メッセージを出力して終了します（exit 0）。

---

## 10. エラー処理方針

| 状況 | 処理 |
| --- | --- |
| 不明なサブコマンド | stderr へメッセージ出力 → exit 1 |
| 必須引数の欠落（タイトルなし等） | stderr へメッセージ出力 → exit 1 |
| Running タスクなし（stop / done 引数なし） | Warning ストリームへ警告メッセージ → exit 0 |
| ファイル読み書き失敗 | stderr へメッセージ出力 → exit 1 |
| カウンターロックタイムアウト | stderr へメッセージ出力 → exit 1 |
| rollover: 当日ファイルに rolled_from 付きタスクあり | Warning ストリームへ「繰越実行済み」メッセージ → exit 0 |
| rollover: 過去90日以内に日次ファイルなし | Warning ストリームへ警告メッセージ → exit 0 |
| rollover: Stopped タスク 0 件 | `Write-TmInfo` で「繰越対象なし」を出力 → exit 0 |
| rollover: 不正な引数あり | stderr へメッセージ出力 → exit 1 |

```powershell
# エラー出力ヘルパー
function Write-TmError([string]$Msg) {
    Write-Error "tm:$Msg"   # stderr へ出力
    exit 1
}

function Write-TmWarn([string]$Msg) {
    Write-Warning "tm:$Msg" # Warning ストリームへ出力（コンソール黄色表示）
}
```

---

## 11. v0.1 → v1.0 互換性設計まとめ

| 設計判断 | v0.1 での実装 | v1.0 での拡張 | 互換性 |
| --- | --- | --- | --- |
| 日次ファイル形式 | `formal_id:` フィールドを空で持つ | 昇格後に値を書き込む | ✅ フィールド追加なし |
| セッション記録 | メモ部に `[HH:MM-HH:MM] (Xh)` 形式で追記 | 形式は変更なし | ✅ 行追加のみ |
| タスク識別子 | 当日連番のみ | ISS-NNN/PHASE-MM も受け付ける | ✅ 連番は継続利用 |
| `-Type` オプション | ラベルのみ（ISS/INQ/MTG） | INQ-YYYYMMDD-NN を自動採番 | ✅ ラベル仕様は不変 |
| データルート | `$PSScriptRoot\tasks` | `$env:TM_ROOT` で上書き可能 | ✅ 既存パスは不変 |
| `config/` ディレクトリ | TM_ROOT 配下に統合 | チーム共有時も同一パスを参照 | ✅ ISS採番が自動共有 |
| カウンターファイル | ファイルと関数を用意するが未使用 | issue new / promote で使用開始 | ✅ 形式は固定済み |
| コマンドディスパッチ | switch 文に v1.0 コマンドをコメントで予約 | 関数を実装して有効化 | ✅ 構造変更なし |
| スクリプト構成 | 単一 tm.ps1（リージョン分割） | lib/ へ分割してドットソーシング | ✅ 外部インターフェース不変 |